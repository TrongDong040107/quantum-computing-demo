# S5 frozen full-training protocol

## Status

This document freezes the final training candidate before any S5 full-training seed is executed.  S4.5 selected terminal-quality-prioritized replay as the proposed learner variant; uniform replay remains the matched ablation/control.  No S5 result may be used to alter the configuration below while retaining the same campaign identity.

## Scientific system

- Target: parameterized two-qutrit family `U_target(xi)=exp[-i xi (lambda3 ⊗ lambda3)]`.
- Discrete actions: `U3(q0), U3(q1), CX, CX†`.
- Maximum topology length: 5 actions.
- Inner continuous optimizer: deterministic L-BFGS-B, `maxiter=4`, no random starts, parent warm start + canonical zero restart.
- Training family grid: 9 periodic xi values.
- Held-out grid: 73 periodic half-shifted xi values.  It is never used by the inner optimizer, replay priority, reward, curriculum, or model selection.
- Final audit grid: 721 periodic half-shifted xi values, audit only after training.
- Robust objective: mean + smooth-max surrogate, `rho=0.6`, `tau=0.08`.
- Final-success threshold: robust training objective <= `1e-2`.

## Proposed learner

Corrected two-layer PS-LSTM + terminal objective credit + terminal-quality-prioritized replay:

- LSTM: 2 layers, hidden size 128.
- Adam learning rate: `1e-2`.
- batch size: 8; replay capacity: 5000; minimum replay: 8.
- train every 20 environment interactions; target sync every 20 interactions.
- PS damping gamma: `1e-3`; glow eta: `0.1`.
- beta: `1e-3 -> 1.0` linearly over 120 episodes, then fixed at 1.
- terminal objective credit: temperature 0.25, scale 2.0, minimum 0.05.
- replay sampling weight: `(terminal_credit + 0.05)^1.0`.

The matched control changes exactly one learner factor: replay sampling is uniform.

## Full campaign identity

- 32 new frozen seeds, listed in `S5_PROTOCOL_PREDECLARED.json` and `qutrit_synthesis/final_training.py`.
- 300 episodes per seed per learner arm.
- Primary arm: `terminal_priority`.
- Matched learner control: `uniform`.
- Matched search baseline: `random` (same seed list and 300 episode budget), treated as a search baseline rather than a learned-policy convergence baseline.
- Probe cadence: every 10 completed episodes; the probe is read-only and consumes no training RNG.
- Transaction checkpoint: after every completed episode.
- Archival snapshot: every 25 completed episodes.

## Predeclared endpoints

The convergence endpoint is the final policy probability mass assigned to the two independently validated depth-5 exact sequences, reported both absolutely and relative to the uniform-policy mass `2/4^5`.  Supporting endpoints are final policy entropy along the exact prefixes, known-exact discovery count, final-success seed rate, first-success episode, best robust objective, held-out worst infidelity, and best/greedy topology.  The 721-point grid is audit-only and must not influence training or selection.

The final paper must report all 32 seeds, including failed/wrong-attractor seeds.  No seed may be removed for poor scientific performance.  A run may be retried only for execution failure using the exact episode-transaction checkpoint.

## Freeze rule

Any change to physics, target, xi grids, objective, optimizer budget, action space, curriculum, TOC, PS-LSTM, replay formula, seed list, or 300-episode budget creates a new protocol version and cannot be pooled silently with this campaign.
