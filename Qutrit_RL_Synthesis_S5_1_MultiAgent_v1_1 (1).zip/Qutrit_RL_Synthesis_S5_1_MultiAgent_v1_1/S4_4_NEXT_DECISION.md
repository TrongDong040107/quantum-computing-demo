# Decision after S4.4

Do **not** increase training length again as the first intervention.

S4.4 completed the original beta schedule (beta=1 at episode 120) and still found
no stable policy concentration in four new diagnostic seeds. The next controlled
change should therefore be one learner-side factor at a time:

1. Keep physics, objective, optimizer, action space, success threshold, TOC,
   network architecture, beta schedule, and episode horizon fixed.
2. Change only replay sampling / elite retention.
3. Predeclare the new seeds and comparison before running.
4. Compare current uniform replay with credit-prioritized replay using:
   final-success rate, known-exact hits, exact-sequence probability mass,
   policy entropy, and held-out family fidelity.

This isolates whether replay dilution is the primary reason PS-LSTM fails to turn
rare useful trajectories into a persistent topology preference.
