"""Deterministic structured discrete-search baselines for qutrit synthesis.

S4/S4.1 showed that the pointwise/robust objective along a correct circuit prefix
can be non-monotone.  This module therefore does *not* claim beam search is an
admissible or optimal search algorithm.  It is a controlled structured-search
baseline that uses exactly the same inner optimizer semantics as the RL
environment: parent warm start, canonical zero restart safeguard, and the same
robust family objective.

One child topology optimization counts as one ``node_evaluation``.  Because the
RL environment performs one inner optimization after each action, node
evaluations are directly comparable to agent-environment interactions when the
same optimizer configuration is used.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from typing import Any, Sequence
import time

import numpy as np
from numpy.typing import ArrayLike

from .circuit import ActionKind, Operation
from .environment import ACTION_KINDS
from .metrics import evaluate_family
from .optimizer import OptimizerConfig, optimize_topology
from .topology import number_of_entanglers, warm_start_after_append


@dataclass(frozen=True)
class BeamSearchConfig:
    max_depth: int = 5
    beam_width: int = 8
    success_threshold: float = 1e-2
    include_zero_restart: bool = True
    stop_on_validated_success: bool = True
    max_node_evaluations: int | None = None
    seed: int = 0

    def validate(self) -> None:
        if self.max_depth <= 0:
            raise ValueError("max_depth must be positive")
        if self.beam_width <= 0:
            raise ValueError("beam_width must be positive")
        if self.success_threshold <= 0:
            raise ValueError("success_threshold must be positive")
        if self.max_node_evaluations is not None and self.max_node_evaluations <= 0:
            raise ValueError("max_node_evaluations must be positive or None")


@dataclass(frozen=True)
class BeamCandidate:
    actions: tuple[int, ...]
    kinds: tuple[ActionKind, ...]
    operations: tuple[Operation, ...]
    parameters: tuple[float, ...]
    objective: float
    mean_train_infidelity: float
    worst_train_infidelity: float
    worst_test_infidelity: float | None
    n_entanglers: int
    train_success: bool
    validated_success: bool
    best_start_kind: str
    optimizer_n_starts: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "actions": list(self.actions),
            "kinds": list(self.kinds),
            "parameters": list(self.parameters),
            "objective": self.objective,
            "mean_train_infidelity": self.mean_train_infidelity,
            "worst_train_infidelity": self.worst_train_infidelity,
            "worst_test_infidelity": self.worst_test_infidelity,
            "n_entanglers": self.n_entanglers,
            "train_success": self.train_success,
            "validated_success": self.validated_success,
            "best_start_kind": self.best_start_kind,
            "optimizer_n_starts": self.optimizer_n_starts,
        }


@dataclass(frozen=True)
class BeamDepthRecord:
    depth: int
    evaluated_children: int
    cumulative_node_evaluations: int
    retained: int
    best_objective: float
    best_worst_train_infidelity: float
    best_actions: tuple[int, ...]
    oracle_prefix_retained: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["best_actions"] = list(self.best_actions)
        return d


@dataclass(frozen=True)
class BeamSearchResult:
    config: BeamSearchConfig
    node_evaluations: int
    expanded_depth: int
    best_candidate: BeamCandidate
    first_validated_success: BeamCandidate | None
    depth_records: tuple[BeamDepthRecord, ...]
    wall_seconds: float
    budget_exhausted: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "config": asdict(self.config),
            "node_evaluations": self.node_evaluations,
            "expanded_depth": self.expanded_depth,
            "best_candidate": self.best_candidate.to_dict(),
            "first_validated_success": None if self.first_validated_success is None else self.first_validated_success.to_dict(),
            "depth_records": [x.to_dict() for x in self.depth_records],
            "wall_seconds": self.wall_seconds,
            "budget_exhausted": self.budget_exhausted,
        }


def _rank_key(c: BeamCandidate) -> tuple[Any, ...]:
    """Deterministic ranking; no hidden oracle-specific heuristic."""
    return (
        float(c.objective),
        float(c.worst_train_infidelity),
        int(c.n_entanglers),
        len(c.actions),
        c.actions,
    )


def _validated_test_worst(operations: Sequence[Operation], test_xis: ArrayLike | None) -> float | None:
    if test_xis is None:
        return None
    return float(evaluate_family(tuple(operations), test_xis).worst_infidelity)


def beam_search(
    train_xis: ArrayLike,
    *,
    test_xis: ArrayLike | None = None,
    optimizer_config: OptimizerConfig = OptimizerConfig(maxiter=4),
    search_config: BeamSearchConfig = BeamSearchConfig(),
    action_kinds: Sequence[ActionKind] = ACTION_KINDS,
    oracle_actions_for_diagnostics: Sequence[int] | None = None,
) -> BeamSearchResult:
    """Run deterministic objective-ranked beam search.

    ``oracle_actions_for_diagnostics`` is never used for ranking or pruning.  It
    only records whether a known prefix survived the ordinary beam, which helps
    diagnose the non-monotone-prefix failure mode discovered in S4.
    """
    search_config.validate()
    kinds = tuple(action_kinds)
    if not kinds or len(set(kinds)) != len(kinds):
        raise ValueError("action_kinds must be non-empty and unique")
    kind_to_action = {k: i for i, k in enumerate(kinds)}

    train = np.asarray(train_xis, dtype=float)
    if train.ndim != 1 or train.size == 0 or not np.all(np.isfinite(train)):
        raise ValueError("train_xis must be a finite non-empty 1D array")
    test = None if test_xis is None else np.asarray(test_xis, dtype=float)
    if test is not None and (test.ndim != 1 or test.size == 0 or not np.all(np.isfinite(test))):
        raise ValueError("test_xis must be a finite non-empty 1D array or None")

    # Root has no gates.  Its score is not used for ranking against non-root
    # candidates, so avoid an unnecessary target-family evaluation here.
    root = BeamCandidate(
        actions=(), kinds=(), operations=(), parameters=(), objective=float("inf"),
        mean_train_infidelity=float("inf"), worst_train_infidelity=float("inf"),
        worst_test_infidelity=None, n_entanglers=0, train_success=False,
        validated_success=False, best_start_kind="root", optimizer_n_starts=0,
    )
    beam: list[BeamCandidate] = [root]
    global_best: BeamCandidate | None = None
    first_success: BeamCandidate | None = None
    records: list[BeamDepthRecord] = []
    node_evals = 0
    budget_exhausted = False
    start_time = time.perf_counter()
    expanded_depth = 0

    for depth in range(1, search_config.max_depth + 1):
        children: list[BeamCandidate] = []
        evaluated_this_depth = 0
        for parent in beam:
            for kind in kinds:
                if search_config.max_node_evaluations is not None and node_evals >= search_config.max_node_evaluations:
                    budget_exhausted = True
                    break
                child_ops, x0 = warm_start_after_append(parent.operations, parent.parameters, kind)
                extra: tuple[np.ndarray, ...] = ()
                if search_config.include_zero_restart and x0.size and not np.allclose(x0, 0.0, rtol=0.0, atol=0.0):
                    extra = (np.zeros_like(x0),)
                cfg = replace(optimizer_config, seed=int(search_config.seed + node_evals))
                result = optimize_topology(
                    child_ops,
                    train,
                    test_xis=None,  # held-out set never enters the inner solve
                    initial_parameters=x0,
                    additional_initial_parameters=extra,
                    config=cfg,
                )
                node_evals += 1
                evaluated_this_depth += 1
                objective = float(result.objective_reported)
                train_success = bool(objective <= search_config.success_threshold)
                test_worst = _validated_test_worst(result.operations, test) if train_success else None
                validated = bool(train_success and (test_worst is None or test_worst <= search_config.success_threshold))
                action = kind_to_action[kind]
                c = BeamCandidate(
                    actions=parent.actions + (action,),
                    kinds=parent.kinds + (kind,),
                    operations=result.operations,
                    parameters=tuple(float(v) for v in result.parameters),
                    objective=objective,
                    mean_train_infidelity=float(result.train_metrics.mean_infidelity),
                    worst_train_infidelity=float(result.train_metrics.worst_infidelity),
                    worst_test_infidelity=test_worst,
                    n_entanglers=number_of_entanglers(result.operations),
                    train_success=train_success,
                    validated_success=validated,
                    best_start_kind=result.best_start_kind,
                    optimizer_n_starts=len(result.starts),
                )
                children.append(c)
                if global_best is None or _rank_key(c) < _rank_key(global_best):
                    global_best = c
                if validated and first_success is None:
                    first_success = c
                if validated and search_config.stop_on_validated_success:
                    break
            if budget_exhausted or (first_success is not None and search_config.stop_on_validated_success):
                break

        if not children:
            break
        children.sort(key=_rank_key)
        beam = children[: search_config.beam_width]
        expanded_depth = depth
        oracle_retained: bool | None = None
        if oracle_actions_for_diagnostics is not None:
            pref = tuple(int(a) for a in oracle_actions_for_diagnostics[:depth])
            oracle_retained = any(c.actions == pref for c in beam)
        best_depth = beam[0]
        records.append(BeamDepthRecord(
            depth=depth,
            evaluated_children=evaluated_this_depth,
            cumulative_node_evaluations=node_evals,
            retained=len(beam),
            best_objective=float(best_depth.objective),
            best_worst_train_infidelity=float(best_depth.worst_train_infidelity),
            best_actions=best_depth.actions,
            oracle_prefix_retained=oracle_retained,
        ))
        if budget_exhausted or (first_success is not None and search_config.stop_on_validated_success):
            break

    if global_best is None:
        raise RuntimeError("search evaluated no child topology")
    return BeamSearchResult(
        config=search_config,
        node_evaluations=node_evals,
        expanded_depth=expanded_depth,
        best_candidate=global_best,
        first_validated_success=first_success,
        depth_records=tuple(records),
        wall_seconds=float(time.perf_counter() - start_time),
        budget_exhausted=budget_exhausted,
    )

@dataclass(frozen=True)
class StratifiedBeamSearchConfig:
    """Diversity-preserving beam configuration.

    Candidates are stratified by ``(number_of_entanglers, last_action)`` and up
    to ``per_stratum`` candidates are retained from each stratum.  This uses no
    oracle sequence information.  The rationale is hardware-agnostic enough for
    the present gate library: prefixes with different entangler counts and last
    gate classes should not be forced to compete solely by a non-monotone
    prefix objective.
    """
    max_depth: int = 5
    per_stratum: int = 2
    max_beam_width: int = 64
    success_threshold: float = 1e-2
    include_zero_restart: bool = True
    stop_on_validated_success: bool = True
    max_node_evaluations: int | None = None
    seed: int = 0

    def validate(self) -> None:
        if self.max_depth <= 0 or self.per_stratum <= 0 or self.max_beam_width <= 0:
            raise ValueError("depth/stratum/beam sizes must be positive")
        if self.success_threshold <= 0:
            raise ValueError("success_threshold must be positive")
        if self.max_node_evaluations is not None and self.max_node_evaluations <= 0:
            raise ValueError("max_node_evaluations must be positive or None")


def _stratified_select(children: Sequence[BeamCandidate], *, per_stratum: int, max_beam_width: int) -> list[BeamCandidate]:
    ordered = sorted(children, key=_rank_key)
    buckets: dict[tuple[int, int], list[BeamCandidate]] = {}
    for c in ordered:
        last_action = int(c.actions[-1])
        key = (int(c.n_entanglers), last_action)
        bucket = buckets.setdefault(key, [])
        if len(bucket) < per_stratum:
            bucket.append(c)
    retained = [c for bucket in buckets.values() for c in bucket]
    retained.sort(key=_rank_key)
    return retained[:max_beam_width]


def stratified_beam_search(
    train_xis: ArrayLike,
    *,
    test_xis: ArrayLike | None = None,
    optimizer_config: OptimizerConfig = OptimizerConfig(maxiter=4),
    search_config: StratifiedBeamSearchConfig = StratifiedBeamSearchConfig(),
    action_kinds: Sequence[ActionKind] = ACTION_KINDS,
    oracle_actions_for_diagnostics: Sequence[int] | None = None,
) -> BeamSearchResult:
    """Run diversity-preserving beam search under the same inner optimizer.

    The oracle sequence is optional diagnostic metadata only and is never used
    by the selector.
    """
    search_config.validate()
    kinds = tuple(action_kinds)
    if not kinds or len(set(kinds)) != len(kinds):
        raise ValueError("action_kinds must be non-empty and unique")
    kind_to_action = {k: i for i, k in enumerate(kinds)}
    train = np.asarray(train_xis, dtype=float)
    if train.ndim != 1 or train.size == 0 or not np.all(np.isfinite(train)):
        raise ValueError("train_xis must be a finite non-empty 1D array")
    test = None if test_xis is None else np.asarray(test_xis, dtype=float)
    if test is not None and (test.ndim != 1 or test.size == 0 or not np.all(np.isfinite(test))):
        raise ValueError("test_xis must be a finite non-empty 1D array or None")

    root = BeamCandidate(
        actions=(), kinds=(), operations=(), parameters=(), objective=float("inf"),
        mean_train_infidelity=float("inf"), worst_train_infidelity=float("inf"),
        worst_test_infidelity=None, n_entanglers=0, train_success=False,
        validated_success=False, best_start_kind="root", optimizer_n_starts=0,
    )
    beam: list[BeamCandidate] = [root]
    global_best: BeamCandidate | None = None
    first_success: BeamCandidate | None = None
    records: list[BeamDepthRecord] = []
    node_evals = 0
    budget_exhausted = False
    start_time = time.perf_counter()
    expanded_depth = 0

    for depth in range(1, search_config.max_depth + 1):
        children: list[BeamCandidate] = []
        evaluated_this_depth = 0
        for parent in beam:
            for kind in kinds:
                if search_config.max_node_evaluations is not None and node_evals >= search_config.max_node_evaluations:
                    budget_exhausted = True
                    break
                child_ops, x0 = warm_start_after_append(parent.operations, parent.parameters, kind)
                extra: tuple[np.ndarray, ...] = ()
                if search_config.include_zero_restart and x0.size and not np.allclose(x0, 0.0, rtol=0.0, atol=0.0):
                    extra = (np.zeros_like(x0),)
                cfg = replace(optimizer_config, seed=int(search_config.seed + node_evals))
                result = optimize_topology(
                    child_ops, train, test_xis=None, initial_parameters=x0,
                    additional_initial_parameters=extra, config=cfg,
                )
                node_evals += 1
                evaluated_this_depth += 1
                objective = float(result.objective_reported)
                train_success = bool(objective <= search_config.success_threshold)
                test_worst = _validated_test_worst(result.operations, test) if train_success else None
                validated = bool(train_success and (test_worst is None or test_worst <= search_config.success_threshold))
                action = kind_to_action[kind]
                c = BeamCandidate(
                    actions=parent.actions + (action,), kinds=parent.kinds + (kind,),
                    operations=result.operations, parameters=tuple(float(v) for v in result.parameters),
                    objective=objective, mean_train_infidelity=float(result.train_metrics.mean_infidelity),
                    worst_train_infidelity=float(result.train_metrics.worst_infidelity),
                    worst_test_infidelity=test_worst, n_entanglers=number_of_entanglers(result.operations),
                    train_success=train_success, validated_success=validated,
                    best_start_kind=result.best_start_kind, optimizer_n_starts=len(result.starts),
                )
                children.append(c)
                if global_best is None or _rank_key(c) < _rank_key(global_best):
                    global_best = c
                if validated and first_success is None:
                    first_success = c
                if validated and search_config.stop_on_validated_success:
                    break
            if budget_exhausted or (first_success is not None and search_config.stop_on_validated_success):
                break
        if not children:
            break
        beam = _stratified_select(children, per_stratum=search_config.per_stratum, max_beam_width=search_config.max_beam_width)
        expanded_depth = depth
        oracle_retained: bool | None = None
        if oracle_actions_for_diagnostics is not None:
            pref = tuple(int(a) for a in oracle_actions_for_diagnostics[:depth])
            oracle_retained = any(c.actions == pref for c in beam)
        best_depth = min(beam, key=_rank_key)
        records.append(BeamDepthRecord(
            depth=depth, evaluated_children=evaluated_this_depth,
            cumulative_node_evaluations=node_evals, retained=len(beam),
            best_objective=float(best_depth.objective),
            best_worst_train_infidelity=float(best_depth.worst_train_infidelity),
            best_actions=best_depth.actions, oracle_prefix_retained=oracle_retained,
        ))
        if budget_exhausted or (first_success is not None and search_config.stop_on_validated_success):
            break

    if global_best is None:
        raise RuntimeError("search evaluated no child topology")
    # Reuse result container; config field is serialized manually here to retain
    # compatibility.  BeamSearchResult's config annotation is not enforced at runtime.
    result = BeamSearchResult(
        config=BeamSearchConfig(
            max_depth=search_config.max_depth,
            beam_width=search_config.max_beam_width,
            success_threshold=search_config.success_threshold,
            include_zero_restart=search_config.include_zero_restart,
            stop_on_validated_success=search_config.stop_on_validated_success,
            max_node_evaluations=search_config.max_node_evaluations,
            seed=search_config.seed,
        ),
        node_evaluations=node_evals, expanded_depth=expanded_depth,
        best_candidate=global_best, first_validated_success=first_success,
        depth_records=tuple(records), wall_seconds=float(time.perf_counter()-start_time),
        budget_exhausted=budget_exhausted,
    )
    return result
