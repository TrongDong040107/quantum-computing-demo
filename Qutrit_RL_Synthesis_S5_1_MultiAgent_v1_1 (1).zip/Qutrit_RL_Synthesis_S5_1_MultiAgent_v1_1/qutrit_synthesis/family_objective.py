"""Robust family objectives for parameterized two-qutrit synthesis.

S4 exposed a scientific failure mode: optimizing a mean over only three xi
points can hide large errors between sampled target parameters.  This module
adds a deterministic smooth worst-case surrogate while preserving the exact
family solution as a zero-cost global optimum.

For pointwise infidelities c_i = 1-F_i, the robust objective is

    C = (1-rho) mean(c_i) + rho * tau * log(mean(exp(c_i/tau))).

The log-mean-exp term is a smooth maximum: it is >= mean(c_i), <= max(c_i),
and is exactly zero when all c_i are zero.  Its gradient is the softmax-weighted
average of pointwise cost gradients, so it can be used directly by L-BFGS-B.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .circuit import Operation, circuit_unitary
from .fidelity import gate_fidelity
from .gradients import point_fidelity_and_packed_gradient
from .target import target_unitary

RealVector = NDArray[np.float64]
ObjectiveMode = Literal["mean", "mean_softmax"]


@dataclass(frozen=True)
class FamilyObjectiveConfig:
    mode: ObjectiveMode = "mean"
    robust_weight: float = 0.5
    temperature: float = 0.05

    def validate(self) -> None:
        if self.mode not in ("mean", "mean_softmax"):
            raise ValueError("unsupported family objective mode")
        if not (0.0 <= self.robust_weight <= 1.0):
            raise ValueError("robust_weight must be in [0,1]")
        if self.temperature <= 0.0:
            raise ValueError("temperature must be positive")

    def to_dict(self) -> dict[str, float | str]:
        return asdict(self)


@dataclass(frozen=True)
class ObjectiveComponents:
    mean_infidelity: float
    smoothmax_infidelity: float
    worst_infidelity: float
    objective: float
    n_points: int

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


def _validate_xis(xis: ArrayLike) -> RealVector:
    x = np.asarray(xis, dtype=np.float64)
    if x.ndim != 1 or x.size == 0 or not np.all(np.isfinite(x)):
        raise ValueError("xis must be a finite non-empty 1D array")
    return x


def _combine(costs: RealVector, config: FamilyObjectiveConfig) -> tuple[float, RealVector, ObjectiveComponents]:
    config.validate()
    if costs.ndim != 1 or costs.size == 0 or not np.all(np.isfinite(costs)):
        raise ValueError("costs must be a finite non-empty 1D array")
    mean = float(np.mean(costs))
    worst = float(np.max(costs))
    if config.mode == "mean":
        weights = np.full(costs.size, 1.0 / costs.size, dtype=np.float64)
        smoothmax = mean
        objective = mean
    else:
        tau = float(config.temperature)
        shifted = (costs - worst) / tau
        exp_shifted = np.exp(shifted)
        z = float(np.sum(exp_shifted))
        soft_weights = exp_shifted / z
        smoothmax = float(worst + tau * np.log(z / costs.size))
        rho = float(config.robust_weight)
        weights = (1.0 - rho) / costs.size + rho * soft_weights
        objective = float((1.0 - rho) * mean + rho * smoothmax)
    return objective, np.asarray(weights, dtype=np.float64), ObjectiveComponents(
        mean_infidelity=mean,
        smoothmax_infidelity=smoothmax,
        worst_infidelity=worst,
        objective=objective,
        n_points=int(costs.size),
    )


def family_objective_cost_and_gradient(
    operations: tuple[Operation, ...] | list[Operation],
    xis: ArrayLike,
    config: FamilyObjectiveConfig = FamilyObjectiveConfig(),
) -> tuple[float, RealVector, ObjectiveComponents]:
    x = _validate_xis(xis)
    costs: list[float] = []
    grads: list[RealVector] = []
    for xi in x:
        fidelity, df = point_fidelity_and_packed_gradient(operations, float(xi))
        costs.append(1.0 - fidelity)
        grads.append(-np.asarray(df, dtype=np.float64))
    c = np.asarray(costs, dtype=np.float64)
    objective, weights, components = _combine(c, config)
    if grads:
        G = np.stack(grads, axis=0)
        grad = np.sum(weights[:, None] * G, axis=0)
    else:
        grad = np.empty(0, dtype=np.float64)
    return float(objective), np.asarray(grad, dtype=np.float64), components


def _point_costs_no_gradient(
    operations: tuple[Operation, ...] | list[Operation], xis: ArrayLike
) -> RealVector:
    x = _validate_xis(xis)
    costs = np.empty(x.size, dtype=np.float64)
    for i, xi in enumerate(x):
        fidelity = gate_fidelity(target_unitary(float(xi)), circuit_unitary(operations, float(xi)))
        costs[i] = 1.0 - fidelity
    return costs


def family_objective_cost(
    operations: tuple[Operation, ...] | list[Operation],
    xis: ArrayLike,
    config: FamilyObjectiveConfig = FamilyObjectiveConfig(),
) -> float:
    costs = _point_costs_no_gradient(operations, xis)
    value, _, _ = _combine(costs, config)
    return float(value)


def family_objective_components(
    operations: tuple[Operation, ...] | list[Operation],
    xis: ArrayLike,
    config: FamilyObjectiveConfig = FamilyObjectiveConfig(),
) -> ObjectiveComponents:
    costs = _point_costs_no_gradient(operations, xis)
    _, _, components = _combine(costs, config)
    return components
