"""Depth-complete coarse-to-fine structured search.

The S4 pilot showed that a correct prefix may have worse objective than an
incorrect prefix.  Prefix-ranked beam search can therefore prune the exact
solution.  This module provides a complementary baseline that scores only
*complete* circuits at a fixed depth.  It enumerates each discrete topology
exactly once (no replacement), uses a small deterministic L-BFGS-B budget for
coarse screening, and optionally refines only the best candidates.

This is not intended as a scalable compiler.  For the present four-action,
depth-five diagnostic there are only 4^5=1024 terminal topologies, making the
baseline useful as a ground-truth structured-search diagnostic.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from itertools import islice, product
from typing import Any, Sequence

import numpy as np
from numpy.typing import ArrayLike

from .circuit import ActionKind
from .environment import ACTION_KINDS
from .metrics import evaluate_family
from .optimizer import OptimizerConfig, optimize_topology
from .topology import number_of_entanglers, operations_from_kinds


@dataclass(frozen=True)
class TerminalCandidate:
    index: int
    actions: tuple[int, ...]
    kinds: tuple[ActionKind, ...]
    objective: float
    mean_train_infidelity: float
    worst_train_infidelity: float
    n_entanglers: int
    parameters: tuple[float, ...]
    best_start_kind: str
    optimizer_n_starts: int
    worst_test_infidelity: float | None = None
    validated_success: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {
            "actions": list(self.actions),
            "kinds": list(self.kinds),
            "parameters": list(self.parameters),
        }


def terminal_topology_count(depth: int, n_actions: int = 4) -> int:
    if depth < 0 or n_actions <= 0:
        raise ValueError("depth must be nonnegative and n_actions positive")
    return int(n_actions**depth)


def enumerate_terminal_topologies(
    depth: int,
    *,
    action_kinds: Sequence[ActionKind] = ACTION_KINDS,
    start_index: int = 0,
    end_index: int | None = None,
):
    kinds = tuple(action_kinds)
    if depth <= 0:
        raise ValueError("depth must be positive")
    if not kinds or len(set(kinds)) != len(kinds):
        raise ValueError("action_kinds must be non-empty and unique")
    total = len(kinds) ** depth
    stop = total if end_index is None else int(end_index)
    if not 0 <= int(start_index) <= stop <= total:
        raise ValueError("require 0 <= start_index <= end_index <= total")
    yield from enumerate(islice(product(kinds, repeat=depth), int(start_index), stop), start=int(start_index))


def _rank_key(c: TerminalCandidate) -> tuple[Any, ...]:
    return (c.objective, c.worst_train_infidelity, c.n_entanglers, c.actions)


def coarse_terminal_search(
    depth: int,
    train_xis: ArrayLike,
    *,
    optimizer_config: OptimizerConfig,
    action_kinds: Sequence[ActionKind] = ACTION_KINDS,
    start_index: int = 0,
    end_index: int | None = None,
    seed_offset: int = 0,
) -> tuple[TerminalCandidate, ...]:
    """Evaluate each terminal topology in the selected lexicographic range once."""
    train = np.asarray(train_xis, dtype=float)
    if train.ndim != 1 or train.size == 0 or not np.all(np.isfinite(train)):
        raise ValueError("train_xis must be a finite non-empty 1D array")
    kinds = tuple(action_kinds)
    kind_to_action = {k: i for i, k in enumerate(kinds)}
    out: list[TerminalCandidate] = []
    for index, seq in enumerate_terminal_topologies(
        depth, action_kinds=kinds, start_index=start_index, end_index=end_index
    ):
        cfg = replace(optimizer_config, seed=int(optimizer_config.seed + seed_offset + index))
        ops = operations_from_kinds(seq)
        result = optimize_topology(ops, train, test_xis=None, config=cfg)
        out.append(TerminalCandidate(
            index=index,
            actions=tuple(kind_to_action[k] for k in seq),
            kinds=tuple(seq),
            objective=float(result.objective_reported),
            mean_train_infidelity=float(result.train_metrics.mean_infidelity),
            worst_train_infidelity=float(result.train_metrics.worst_infidelity),
            n_entanglers=number_of_entanglers(result.operations),
            parameters=tuple(float(x) for x in result.parameters),
            best_start_kind=result.best_start_kind,
            optimizer_n_starts=len(result.starts),
        ))
    return tuple(sorted(out, key=_rank_key))


def refine_terminal_candidates(
    candidates: Sequence[TerminalCandidate],
    train_xis: ArrayLike,
    *,
    test_xis: ArrayLike | None,
    optimizer_config: OptimizerConfig,
    success_threshold: float = 1e-2,
    top_k: int = 32,
    include_zero_restart: bool = True,
) -> tuple[TerminalCandidate, ...]:
    if top_k <= 0:
        raise ValueError("top_k must be positive")
    train = np.asarray(train_xis, dtype=float)
    test = None if test_xis is None else np.asarray(test_xis, dtype=float)
    refined: list[TerminalCandidate] = []
    for rank, c in enumerate(sorted(candidates, key=_rank_key)[:top_k]):
        ops = operations_from_kinds(c.kinds)
        x0 = np.asarray(c.parameters, dtype=float)
        extra = ()
        if include_zero_restart and x0.size and not np.allclose(x0, 0.0, rtol=0.0, atol=0.0):
            extra = (np.zeros_like(x0),)
        cfg = replace(optimizer_config, seed=int(optimizer_config.seed + rank))
        result = optimize_topology(
            ops, train, test_xis=None, initial_parameters=x0,
            additional_initial_parameters=extra, config=cfg,
        )
        train_success = bool(result.objective_reported <= success_threshold)
        test_worst = None
        validated = False
        if train_success:
            if test is None:
                validated = True
            else:
                test_worst = float(evaluate_family(result.operations, test).worst_infidelity)
                validated = bool(test_worst <= success_threshold)
        refined.append(TerminalCandidate(
            index=c.index,
            actions=c.actions,
            kinds=c.kinds,
            objective=float(result.objective_reported),
            mean_train_infidelity=float(result.train_metrics.mean_infidelity),
            worst_train_infidelity=float(result.train_metrics.worst_infidelity),
            n_entanglers=number_of_entanglers(result.operations),
            parameters=tuple(float(x) for x in result.parameters),
            best_start_kind=result.best_start_kind,
            optimizer_n_starts=len(result.starts),
            worst_test_infidelity=test_worst,
            validated_success=validated,
        ))
    return tuple(sorted(refined, key=_rank_key))

def terminal_sequence_from_index(index: int, depth: int, action_kinds: Sequence[ActionKind] = ACTION_KINDS) -> tuple[ActionKind, ...]:
    kinds = tuple(action_kinds)
    total = len(kinds) ** depth
    if depth <= 0 or not (0 <= int(index) < total):
        raise ValueError("index/depth out of range")
    x = int(index)
    digits = [0] * depth
    for pos in range(depth - 1, -1, -1):
        digits[pos] = x % len(kinds)
        x //= len(kinds)
    return tuple(kinds[d] for d in digits)


def _parallel_terminal_worker(args):
    index, depth, train, optimizer_config, action_kinds, seed_offset = args
    kinds = tuple(action_kinds)
    seq = terminal_sequence_from_index(index, depth, kinds)
    kind_to_action = {k: i for i, k in enumerate(kinds)}
    cfg = replace(optimizer_config, seed=int(optimizer_config.seed + seed_offset + index))
    ops = operations_from_kinds(seq)
    result = optimize_topology(ops, np.asarray(train, dtype=float), test_xis=None, config=cfg)
    return TerminalCandidate(
        index=index,
        actions=tuple(kind_to_action[k] for k in seq),
        kinds=tuple(seq),
        objective=float(result.objective_reported),
        mean_train_infidelity=float(result.train_metrics.mean_infidelity),
        worst_train_infidelity=float(result.train_metrics.worst_infidelity),
        n_entanglers=number_of_entanglers(result.operations),
        parameters=tuple(float(x) for x in result.parameters),
        best_start_kind=result.best_start_kind,
        optimizer_n_starts=len(result.starts),
    )


def coarse_terminal_search_parallel(
    depth: int,
    train_xis: ArrayLike,
    *,
    optimizer_config: OptimizerConfig,
    action_kinds: Sequence[ActionKind] = ACTION_KINDS,
    start_index: int = 0,
    end_index: int | None = None,
    seed_offset: int = 0,
    max_workers: int = 4,
) -> tuple[TerminalCandidate, ...]:
    """Parallel version of :func:`coarse_terminal_search` using processes."""
    from concurrent.futures import ProcessPoolExecutor
    if max_workers <= 0:
        raise ValueError("max_workers must be positive")
    kinds = tuple(action_kinds)
    total = len(kinds) ** depth
    stop = total if end_index is None else int(end_index)
    if not 0 <= int(start_index) <= stop <= total:
        raise ValueError("invalid index range")
    train = np.asarray(train_xis, dtype=float)
    if train.ndim != 1 or train.size == 0 or not np.all(np.isfinite(train)):
        raise ValueError("train_xis must be a finite non-empty 1D array")
    payloads = [
        (i, depth, tuple(float(x) for x in train), optimizer_config, kinds, seed_offset)
        for i in range(int(start_index), stop)
    ]
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        out = list(ex.map(_parallel_terminal_worker, payloads, chunksize=1))
    return tuple(sorted(out, key=_rank_key))
