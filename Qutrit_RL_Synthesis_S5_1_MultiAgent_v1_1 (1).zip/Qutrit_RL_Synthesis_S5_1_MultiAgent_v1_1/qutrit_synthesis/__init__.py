"""Exact qutrit synthesis core with PS-LSTM and discrete PPO-family learners."""

from .circuit import ActionKind, Operation, circuit_unitary
from .curriculum import Curriculum, CurriculumConfig
from .environment import (
    ACTION_KINDS,
    ACTION_TO_KIND,
    KIND_TO_ACTION,
    EnvironmentConfig,
    QutritSynthesisEnv,
)
from .fidelity import gate_fidelity
from .gates import cx3, cx3_dagger, cz3, u3
from .metrics import FamilyMetrics, evaluate_family
from .family_objective import FamilyObjectiveConfig, ObjectiveComponents, family_objective_cost_and_gradient
from .family_grid import periodic_uniform_grid, minimum_periodic_separation
from .terminal_credit import TerminalCreditConfig, terminal_objective_credit
from .optimizer import OptimizationResult, OptimizerConfig, optimize_topology
from .target import LAMBDA3, target_unitary
from .ps_lstm import (
    ActionEvaluation,
    CorrectedPSLSTMAgent,
    PSLSTMConfig,
    PSLSTMNetwork,
    ReplayBuffer,
    ReplayItem,
)
from .trainer import EpisodeResult, run_episode

from .ppo_family import (
    AlgorithmName,
    PPOFamilyConfig,
    PPOActionEvaluation,
    DiscretePPOAgent,
    make_ppo_agent,
)
from .ppo_trainer import PPOEpisodeResult, run_ppo_episode

__all__ = [
    "ActionKind", "Operation", "circuit_unitary",
    "Curriculum", "CurriculumConfig",
    "ACTION_KINDS", "ACTION_TO_KIND", "KIND_TO_ACTION",
    "EnvironmentConfig", "QutritSynthesisEnv",
    "gate_fidelity", "cx3", "cx3_dagger", "cz3", "u3",
    "FamilyMetrics", "evaluate_family",
    "FamilyObjectiveConfig", "ObjectiveComponents", "family_objective_cost_and_gradient",
    "periodic_uniform_grid", "minimum_periodic_separation",
    "TerminalCreditConfig", "terminal_objective_credit",
    "OptimizationResult", "OptimizerConfig", "optimize_topology",
    "LAMBDA3", "target_unitary",
    "ActionEvaluation", "CorrectedPSLSTMAgent", "PSLSTMConfig",
    "PSLSTMNetwork", "ReplayBuffer", "ReplayItem",
    "EpisodeResult", "run_episode",
    "AlgorithmName", "PPOFamilyConfig", "PPOActionEvaluation",
    "DiscretePPOAgent", "make_ppo_agent",
    "PPOEpisodeResult", "run_ppo_episode",
]
