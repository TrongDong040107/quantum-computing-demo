"""Circuit representation and exact matrix/parameter derivatives."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .gates import I3, cx3, cx3_dagger, u3, u3_parameter_derivative

ComplexMatrix = NDArray[np.complex128]
ActionKind = Literal["u3_q0", "u3_q1", "cx", "cx_dg"]


@dataclass(frozen=True)
class Operation:
    """One chronological circuit operation.

    `params` is required only for u3_q0/u3_q1 and must contain eight real
    synthesis coefficients.
    """

    kind: ActionKind
    params: tuple[float, ...] | None = None

    @staticmethod
    def local(kind: Literal["u3_q0", "u3_q1"], params: ArrayLike) -> "Operation":
        arr = np.asarray(params, dtype=np.float64)
        if arr.shape != (8,):
            raise ValueError(f"local operation expects 8 parameters, got {arr.shape}")
        if not np.all(np.isfinite(arr)):
            raise ValueError("operation parameters must be finite")
        return Operation(kind=kind, params=tuple(float(x) for x in arr))

    @staticmethod
    def fixed(kind: Literal["cx", "cx_dg"]) -> "Operation":
        return Operation(kind=kind, params=None)


def operation_unitary(op: Operation, xi: float) -> ComplexMatrix:
    if op.kind == "cx":
        if op.params is not None:
            raise ValueError("cx must not carry parameters")
        return cx3()
    if op.kind == "cx_dg":
        if op.params is not None:
            raise ValueError("cx_dg must not carry parameters")
        return cx3_dagger()
    if op.params is None:
        raise ValueError(f"{op.kind} requires 8 parameters")
    local = u3(xi, op.params)
    if op.kind == "u3_q0":
        return np.kron(local, I3)
    if op.kind == "u3_q1":
        return np.kron(I3, local)
    raise ValueError(f"unknown operation kind: {op.kind}")


def operation_parameter_derivative(op: Operation, xi: float, k: int) -> ComplexMatrix:
    if op.kind in ("cx", "cx_dg"):
        raise ValueError("fixed entangling operations have no trainable parameters")
    if op.params is None:
        raise ValueError(f"{op.kind} requires parameters")
    dlocal = u3_parameter_derivative(xi, op.params, k)
    if op.kind == "u3_q0":
        return np.kron(dlocal, I3)
    if op.kind == "u3_q1":
        return np.kron(I3, dlocal)
    raise ValueError(f"unknown operation kind: {op.kind}")


def circuit_unitary(operations: Sequence[Operation], xi: float) -> ComplexMatrix:
    """Build V = G_L ... G_1 for operations listed in chronological order."""
    v = np.eye(9, dtype=np.complex128)
    for op in operations:
        v = operation_unitary(op, xi) @ v
    return v


def circuit_parameter_derivative(
    operations: Sequence[Operation], xi: float, op_index: int, param_index: int
) -> ComplexMatrix:
    """Exact dV/dp_(op_index,param_index) for V=G_L...G_1."""
    if not 0 <= op_index < len(operations):
        raise IndexError("op_index out of range")
    gates = [operation_unitary(op, xi) for op in operations]
    dg = operation_parameter_derivative(operations[op_index], xi, param_index)

    # left = G_L ... G_{op_index+1}
    left = np.eye(9, dtype=np.complex128)
    for j in range(len(gates) - 1, op_index, -1):
        left = left @ gates[j]

    # right = G_{op_index-1} ... G_1
    right = np.eye(9, dtype=np.complex128)
    for j in range(op_index - 1, -1, -1):
        right = right @ gates[j]

    return left @ dg @ right
