"""Training-loop glue for the discrete PPO family on QutritSynthesisEnv."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .environment import QutritSynthesisEnv
from .ppo_family import DiscretePPOAgent


@dataclass(frozen=True)
class PPOEpisodeResult:
    episode_index: int
    episode_seed: int
    actions: tuple[int, ...]
    action_kinds: tuple[str, ...]
    rewards: tuple[float, ...]
    final_objective: float
    final_worst_test_infidelity: float | None
    terminated: bool
    truncated: bool
    final_success: bool
    interactions: int
    ppo_updates: int
    gradient_updates: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "episode_index": self.episode_index,
            "episode_seed": self.episode_seed,
            "actions": list(self.actions),
            "action_kinds": list(self.action_kinds),
            "rewards": list(self.rewards),
            "final_objective": self.final_objective,
            "final_worst_test_infidelity": self.final_worst_test_infidelity,
            "terminated": self.terminated,
            "truncated": self.truncated,
            "final_success": self.final_success,
            "interactions": self.interactions,
            "ppo_updates": self.ppo_updates,
            "gradient_updates": self.gradient_updates,
        }


def run_ppo_episode(
    env: QutritSynthesisEnv,
    agent: DiscretePPOAgent,
    *,
    seed: int,
    deterministic_policy: bool = False,
) -> PPOEpisodeResult:
    if env.config.observation_mode != "last_action":
        raise ValueError("PPO-family baselines expect last_action observations")
    if env.action_space_n != agent.config.action_dim:
        raise ValueError("environment/agent action dimension mismatch")
    if env.observation_shape != (agent.config.obs_dim,):
        raise ValueError("environment/agent observation dimension mismatch")

    obs, reset_info = env.reset(seed=seed)
    agent.reset_episode()
    actions: list[int] = []
    kinds: list[str] = []
    rewards: list[float] = []
    final_info: dict[str, Any] | None = None
    terminated = truncated = False
    interactions0 = agent.interactions

    while not (terminated or truncated):
        obs_before = np.asarray(obs, dtype=np.float64).copy()
        action, evaluation = agent.act(obs_before, deterministic=deterministic_policy)
        next_obs, reward, terminated, truncated, info = env.step(action)
        agent.observe(
            obs_before,
            action,
            reward,
            next_obs,
            terminated=terminated,
            truncated=truncated,
            evaluation=evaluation,
        )
        obs = next_obs
        actions.append(int(action))
        kinds.append(str(info["action_kind"]))
        rewards.append(float(reward))
        final_info = info

    assert final_info is not None
    test_metrics = final_info.get("test_metrics")
    worst_test = None if test_metrics is None else float(test_metrics["worst_infidelity"])
    return PPOEpisodeResult(
        episode_index=int(reset_info["episode_index"]),
        episode_seed=int(reset_info["episode_seed"]),
        actions=tuple(actions),
        action_kinds=tuple(kinds),
        rewards=tuple(rewards),
        final_objective=float(final_info["objective"]),
        final_worst_test_infidelity=worst_test,
        terminated=bool(terminated),
        truncated=bool(truncated),
        final_success=bool(final_info["final_success"]),
        interactions=agent.interactions - interactions0,
        ppo_updates=agent.ppo_updates,
        gradient_updates=agent.gradient_updates,
    )
