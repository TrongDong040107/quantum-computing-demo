"""Global-phase-insensitive unitary fidelity utilities."""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike


def _square_matrix(a: ArrayLike) -> np.ndarray:
    x = np.asarray(a, dtype=np.complex128)
    if x.ndim != 2 or x.shape[0] != x.shape[1]:
        raise ValueError(f"expected a square matrix, got shape {x.shape}")
    return x


def gate_fidelity(target: ArrayLike, trial: ArrayLike) -> float:
    """F(U,V)=|Tr(U^†V)|^2/d^2 for equal-size square matrices."""
    u = _square_matrix(target)
    v = _square_matrix(trial)
    if u.shape != v.shape:
        raise ValueError(f"shape mismatch: {u.shape} != {v.shape}")
    d = u.shape[0]
    overlap = np.trace(u.conj().T @ v)
    return float((abs(overlap) ** 2) / (d * d))


def infidelity(target: ArrayLike, trial: ArrayLike) -> float:
    """1 - gate_fidelity, clipped only for tiny floating-point overshoot."""
    value = 1.0 - gate_fidelity(target, trial)
    if -1e-14 < value < 0.0:
        return 0.0
    return float(value)
