"""S5.1 multi-agent training configuration for the qutrit synthesis study.

This module does *not* mutate the frozen S5 PS-LSTM protocol.  It defines a new
comparison protocol that reuses exactly the same quantum environment/physics and
adds discrete PPO, PPO-TrXL and CAD-SF-TrPPO learners.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal
import hashlib
import json

from .final_training import FINAL_SEEDS, environment_for, terminal_credit, agent_for as ps_lstm_agent_for
from .ppo_family import AlgorithmName, DiscretePPOAgent, PPOFamilyConfig

MultiAlgorithm = Literal["ps_lstm", "ppo", "ppo_trxl", "cad_sf_trppo"]
MULTI_AGENT_ALGORITHMS: tuple[MultiAlgorithm, ...] = (
    "ps_lstm", "ppo", "ppo_trxl", "cad_sf_trppo"
)
# User-requested light pilot: common random seeds across all algorithms.
PILOT_SEEDS: tuple[int, ...] = tuple(FINAL_SEEDS[:5])
DEFAULT_EPISODES = 300


@dataclass(frozen=True)
class MultiAgentProtocol:
    schema_version: int = 1
    name: str = "S5.1-qutrit-multi-agent"
    n_seeds: int = 5
    episodes_per_seed: int = DEFAULT_EPISODES
    max_steps: int = 5
    common_environment: str = "S5-final-qutrit-environment"
    ppo_rollout_steps: int = 100
    ppo_update_epochs: int = 4
    ppo_num_minibatches: int = 4
    ppo_gamma: float = 0.99
    ppo_gae_lambda: float = 0.95
    ppo_clip_coef: float = 0.2
    ppo_vf_coef: float = 0.5
    ppo_entropy_start: float = 0.01
    ppo_entropy_end: float = 0.001
    cad_alpha_init: float = 0.01
    cad_kappa: float = 5.0
    cad_residual_eps: float = 1e-5
    cad_fisher_damping: float = 1e-8
    cad_fisher_eps: float = 1e-4
    cad_fisher_beta: float = 0.95

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["seeds"] = list(PILOT_SEEDS)
        d["algorithms"] = list(MULTI_AGENT_ALGORITHMS)
        return d


PROTOCOL = MultiAgentProtocol()


def protocol_sha256() -> str:
    raw = json.dumps(PROTOCOL.to_dict(), sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def ppo_agent_for(
    algorithm: AlgorithmName,
    seed: int,
    *,
    episodes: int = DEFAULT_EPISODES,
    device: str = "cpu",
) -> DiscretePPOAgent:
    if episodes <= 0:
        raise ValueError("episodes must be positive")
    interaction_budget = int(episodes) * PROTOCOL.max_steps
    return DiscretePPOAgent(PPOFamilyConfig(
        algorithm=algorithm,
        obs_dim=4, action_dim=4,
        hidden_dim=128, encoder_dim=256,
        trxl_num_layers=2, trxl_num_heads=4,
        trxl_memory_length=PROTOCOL.max_steps,
        rollout_steps=PROTOCOL.ppo_rollout_steps,
        update_epochs=PROTOCOL.ppo_update_epochs,
        num_minibatches=PROTOCOL.ppo_num_minibatches,
        learning_rate=3e-4, final_learning_rate=5e-5,
        lr_anneal_interactions=max(1, int(0.9 * interaction_budget)),
        gamma=PROTOCOL.ppo_gamma, gae_lambda=PROTOCOL.ppo_gae_lambda,
        clip_coef=PROTOCOL.ppo_clip_coef, vf_coef=PROTOCOL.ppo_vf_coef,
        ent_coef_start=PROTOCOL.ppo_entropy_start,
        ent_coef_end=PROTOCOL.ppo_entropy_end,
        entropy_anneal_interactions=max(1, interaction_budget),
        max_grad_norm=0.5, adam_weight_decay=1e-2, adam_eps=1e-5,
        residual_coef=0.5,
        cad_alpha_init=PROTOCOL.cad_alpha_init, cad_kappa=PROTOCOL.cad_kappa,
        residual_eps=PROTOCOL.cad_residual_eps,
        fisher_damping=PROTOCOL.cad_fisher_damping,
        fisher_eps=PROTOCOL.cad_fisher_eps, fisher_beta=PROTOCOL.cad_fisher_beta,
        seed=int(seed), device=device,
    ))


def validate_multi_agent_protocol() -> dict[str, Any]:
    if len(PILOT_SEEDS) != PROTOCOL.n_seeds or len(set(PILOT_SEEDS)) != PROTOCOL.n_seeds:
        raise RuntimeError("pilot seeds must be exactly five unique values")
    if PROTOCOL.episodes_per_seed <= 0:
        raise RuntimeError("episodes_per_seed must be positive")
    # Reuse the exact same S5 environment for all agents.
    env = environment_for(PILOT_SEEDS[0])
    if env.action_space_n != 4 or env.observation_shape != (4,):
        raise RuntimeError("unexpected qutrit environment interface")
    # Construct all learners as a structural gate.
    _ = ps_lstm_agent_for(PILOT_SEEDS[0], replay_sampling="terminal_priority")
    for algo in ("ppo", "ppo_trxl", "cad_sf_trppo"):
        _ = ppo_agent_for(algo, PILOT_SEEDS[0])
    return {
        "protocol_sha256": protocol_sha256(),
        "n_seeds": len(PILOT_SEEDS),
        "episodes_per_seed": PROTOCOL.episodes_per_seed,
        "algorithms": list(MULTI_AGENT_ALGORITHMS),
        "observation_dim": 4,
        "action_dim": 4,
    }
