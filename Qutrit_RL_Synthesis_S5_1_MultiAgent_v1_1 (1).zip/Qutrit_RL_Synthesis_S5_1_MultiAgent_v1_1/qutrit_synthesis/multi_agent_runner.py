"""Exact episode-transaction runner for S5.1 qutrit multi-agent comparisons."""
from __future__ import annotations

import copy
import hashlib
from pathlib import Path
from typing import Any

from .campaign import KNOWN_EXACT_ACTIONS, ORACLE_ACTIONS
from .final_training import environment_for, terminal_credit, agent_for as ps_lstm_agent_for
from .multi_agent_training import MULTI_AGENT_ALGORITHMS, protocol_sha256, ppo_agent_for
from .policy_probe import probe_agent_state
from .ppo_probe import probe_ppo_agent_state
from .ppo_trainer import run_ppo_episode
from .trainer import run_episode

FORMAT_VERSION = 1
PROBE_INTERVAL = 10


def core_python_tree_sha256(root: Path) -> str:
    h = hashlib.sha256()
    for p in sorted((root / "qutrit_synthesis").rglob("*.py")):
        h.update(p.relative_to(root).as_posix().encode() + b"\0")
        h.update(hashlib.sha256(p.read_bytes()).digest())
    return h.hexdigest()


def _empty_stats() -> dict[str, Any]:
    return {
        "episodes_completed": 0,
        "interactions": 0,
        "final_success_episodes": 0,
        "first_final_success_episode": None,
        "best_objective": float("inf"),
        "best_worst_test_infidelity": None,
        "known_exact_hits": 0,
        "oracle_exact_hits": 0,
        "best_actions": [],
        "best_action_kinds": [],
        "action_counts": [0, 0, 0, 0],
        "episode_records": [],
        "probe_history": [],
    }


def initialize_state(root: Path, *, algorithm: str, seed: int, episodes_total: int) -> dict[str, Any]:
    if algorithm not in MULTI_AGENT_ALGORITHMS:
        raise ValueError(f"algorithm must be one of {MULTI_AGENT_ALGORITHMS}")
    if episodes_total <= 0:
        raise ValueError("episodes_total must be positive")
    env = environment_for(int(seed))
    if algorithm == "ps_lstm":
        agent = ps_lstm_agent_for(int(seed), replay_sampling="terminal_priority")
    else:
        agent = ppo_agent_for(algorithm, int(seed), episodes=episodes_total)
    return {
        "format_version": FORMAT_VERSION,
        "algorithm": algorithm,
        "seed": int(seed),
        "episodes_total": int(episodes_total),
        "next_episode": 0,
        "protocol_sha256": protocol_sha256(),
        "core_python_tree_sha256": core_python_tree_sha256(root),
        "env_state": env.state_dict(),
        "agent_state": agent.state_dict(),
        "stats": _empty_stats(),
    }


def validate_state(root: Path, state: dict[str, Any]) -> None:
    if int(state["format_version"]) != FORMAT_VERSION:
        raise ValueError("unsupported state format")
    if state["algorithm"] not in MULTI_AGENT_ALGORITHMS:
        raise ValueError("invalid algorithm")
    if state["protocol_sha256"] != protocol_sha256():
        raise ValueError("S5.1 protocol hash mismatch")
    if state["core_python_tree_sha256"] != core_python_tree_sha256(root):
        raise ValueError("scientific Python tree hash mismatch")
    if not (0 <= int(state["next_episode"]) <= int(state["episodes_total"])):
        raise ValueError("invalid next_episode")


def _update_stats(stats: dict[str, Any], rec: dict[str, Any]) -> None:
    ep = int(rec["episode"])
    actions = tuple(int(a) for a in rec["actions"])
    for a in actions:
        stats["action_counts"][a] += 1
    stats["interactions"] += len(actions)
    if actions == ORACLE_ACTIONS:
        stats["oracle_exact_hits"] += 1
    if actions in KNOWN_EXACT_ACTIONS:
        stats["known_exact_hits"] += 1
    objective = float(rec["objective"])
    if objective < float(stats["best_objective"]):
        stats["best_objective"] = objective
        stats["best_worst_test_infidelity"] = rec["worst_test_infidelity"]
        stats["best_actions"] = list(actions)
        stats["best_action_kinds"] = list(rec["action_kinds"])
    if bool(rec["final_success"]):
        stats["final_success_episodes"] += 1
        if stats["first_final_success_episode"] is None:
            stats["first_final_success_episode"] = ep
    stats["episodes_completed"] += 1
    stats["episode_records"].append(copy.deepcopy(rec))


def execute_one_episode(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    validate_state(root, state)
    ep = int(state["next_episode"])
    if ep >= int(state["episodes_total"]):
        return state
    seed = int(state["seed"])
    episode_seed = seed * 100_000 + ep + 1
    env = environment_for(seed)
    env.load_state_dict(state["env_state"])
    algorithm = str(state["algorithm"])
    new_state = copy.deepcopy(state)

    if algorithm == "ps_lstm":
        agent = ps_lstm_agent_for(seed, replay_sampling="terminal_priority")
        agent.load_state_dict(state["agent_state"])
        out = run_episode(env, agent, seed=episode_seed, terminal_credit=terminal_credit())
        rec = {
            "episode": ep,
            "actions": list(out.actions),
            "action_kinds": list(out.action_kinds),
            "objective": float(out.final_objective),
            "worst_test_infidelity": out.final_worst_test_infidelity,
            "final_success": bool(out.final_success),
        }
        new_state["agent_state"] = agent.state_dict()
    else:
        agent = ppo_agent_for(algorithm, seed, episodes=int(state["episodes_total"]))
        agent.load_state_dict(state["agent_state"])
        out = run_ppo_episode(env, agent, seed=episode_seed)
        # Train the final incomplete on-policy rollout at campaign end.
        if ep + 1 == int(state["episodes_total"]):
            agent.flush()
        rec = {
            "episode": ep,
            "actions": list(out.actions),
            "action_kinds": list(out.action_kinds),
            "objective": float(out.final_objective),
            "worst_test_infidelity": out.final_worst_test_infidelity,
            "final_success": bool(out.final_success),
        }
        new_state["agent_state"] = agent.state_dict()

    new_state["env_state"] = env.state_dict()
    _update_stats(new_state["stats"], rec)
    new_state["next_episode"] = ep + 1
    if new_state["next_episode"] % PROBE_INTERVAL == 0 or new_state["next_episode"] == int(state["episodes_total"]):
        if algorithm == "ps_lstm":
            probe = probe_agent_state(new_state["agent_state"])
        else:
            probe = probe_ppo_agent_state(new_state["agent_state"])
        probe["episode"] = int(new_state["next_episode"])
        new_state["stats"]["probe_history"].append(probe)
    return new_state


def scientific_result(state: dict[str, Any]) -> dict[str, Any]:
    s = state["stats"]
    a = state["agent_state"]
    algorithm = str(state["algorithm"])
    if algorithm == "ps_lstm":
        final_probe = probe_agent_state(a)
        extra = {
            "gradient_updates": int(a["gradient_updates"]),
            "replay_size": len(a["replay"]["items"]),
            "target_syncs": int(a["target_syncs"]),
        }
    else:
        final_probe = probe_ppo_agent_state(a)
        extra = {
            "gradient_updates": int(a["gradient_updates"]),
            "ppo_updates": int(a["ppo_updates"]),
            "rollout_pending": len(a["rollout"]),
            "last_metrics": copy.deepcopy(a["last_metrics"]),
        }
    return {
        "algorithm": algorithm,
        "seed": int(state["seed"]),
        "episodes": int(state["episodes_total"]),
        "episodes_completed": int(s["episodes_completed"]),
        "interactions": int(s["interactions"]),
        "final_success_episodes": int(s["final_success_episodes"]),
        "first_final_success_episode": s["first_final_success_episode"],
        "best_objective": float(s["best_objective"]),
        "best_worst_test_infidelity": s["best_worst_test_infidelity"],
        "known_exact_hits": int(s["known_exact_hits"]),
        "oracle_exact_hits": int(s["oracle_exact_hits"]),
        "best_actions": list(s["best_actions"]),
        "best_action_kinds": list(s["best_action_kinds"]),
        "action_counts": list(s["action_counts"]),
        "probe_history": copy.deepcopy(s["probe_history"]),
        "final_policy_probe": final_probe,
        **extra,
    }
