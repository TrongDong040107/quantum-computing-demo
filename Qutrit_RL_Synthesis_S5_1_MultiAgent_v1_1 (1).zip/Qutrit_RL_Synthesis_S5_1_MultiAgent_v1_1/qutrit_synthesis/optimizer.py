"""Deterministic L-BFGS-B inner optimizer for the parameterized qutrit family."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from collections.abc import Sequence
from typing import Any

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.optimize import minimize

from .circuit import Operation
from .gradients import pack_local_parameters, with_packed_local_parameters
from .family_objective import (
    FamilyObjectiveConfig,
    ObjectiveComponents,
    family_objective_cost,
    family_objective_cost_and_gradient,
    family_objective_components,
)
from .metrics import FamilyMetrics, evaluate_family

RealVector = NDArray[np.float64]


def _validate_xis(xis: ArrayLike, name: str) -> RealVector:
    x = np.asarray(xis, dtype=np.float64)
    if x.ndim != 1 or x.size == 0:
        raise ValueError(f"{name} must be a non-empty 1D array")
    if not np.all(np.isfinite(x)):
        raise ValueError(f"{name} must be finite")
    return x


@dataclass(frozen=True)
class OptimizerConfig:
    """Configuration for one deterministic multistart L-BFGS-B solve."""

    maxiter: int = 100
    ftol: float = 1e-15
    gtol: float = 1e-9
    maxls: int = 40
    coefficient_bound: float | None = None
    random_start_scale: float = 0.75
    n_random_starts: int = 0
    seed: int = 0
    family_objective: FamilyObjectiveConfig = FamilyObjectiveConfig()

    def validate(self) -> None:
        if self.maxiter <= 0:
            raise ValueError("maxiter must be positive")
        if self.ftol <= 0 or self.gtol <= 0:
            raise ValueError("ftol and gtol must be positive")
        if self.maxls <= 0:
            raise ValueError("maxls must be positive")
        if self.coefficient_bound is not None and self.coefficient_bound <= 0:
            raise ValueError("coefficient_bound must be positive or None")
        if self.random_start_scale < 0:
            raise ValueError("random_start_scale must be non-negative")
        if self.n_random_starts < 0:
            raise ValueError("n_random_starts must be non-negative")
        self.family_objective.validate()


@dataclass(frozen=True)
class StartResult:
    start_index: int
    start_kind: str
    initial_cost: float
    final_cost_raw: float
    success: bool
    status: int
    message: str
    nit: int
    nfev: int
    njev: int
    gradient_inf_norm: float
    parameters: tuple[float, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class OptimizationResult:
    """Best solution plus complete deterministic multistart diagnostics."""

    operations: tuple[Operation, ...]
    parameters: tuple[float, ...]
    objective_raw: float
    objective_reported: float
    best_start_index: int
    best_start_kind: str
    train_metrics: FamilyMetrics
    test_metrics: FamilyMetrics | None
    starts: tuple[StartResult, ...]
    config: OptimizerConfig
    objective_components: ObjectiveComponents

    def to_dict(self) -> dict[str, Any]:
        return {
            "parameters": list(self.parameters),
            "objective_raw": self.objective_raw,
            "objective_reported": self.objective_reported,
            "best_start_index": self.best_start_index,
            "best_start_kind": self.best_start_kind,
            "train_metrics": self.train_metrics.to_dict(),
            "test_metrics": None if self.test_metrics is None else self.test_metrics.to_dict(),
            "starts": [s.to_dict() for s in self.starts],
            "config": asdict(self.config),
            "objective_components": self.objective_components.to_dict(),
            "operation_kinds": [op.kind for op in self.operations],
        }


def _reported_cost(value: float) -> float:
    # Preserve real optimization failures, but hide only roundoff-scale negative infidelity.
    if -1e-12 < value < 0.0:
        return 0.0
    return float(value)


def _bounds(n: int, coefficient_bound: float | None):
    if coefficient_bound is None:
        return None
    b = float(coefficient_bound)
    return [(-b, b)] * n


def optimize_topology(
    operations: Sequence[Operation],
    train_xis: ArrayLike,
    *,
    test_xis: ArrayLike | None = None,
    initial_parameters: ArrayLike | None = None,
    additional_initial_parameters: Sequence[ArrayLike] = (),
    config: OptimizerConfig = OptimizerConfig(),
) -> OptimizationResult:
    """Optimize all local U3 coefficients for one fixed discrete topology.

    Start order is deterministic:
      1. `initial_parameters` (or the coefficients already stored in operations),
      2. explicit `additional_initial_parameters`,
      3. seeded Gaussian random starts.

    The objective is selected by ``config.family_objective``.  The legacy
    default remains mean family infidelity; S4.1 may use a mean+smoothmax robust
    objective. Reporting clips only tiny floating-point negative roundoff.
    """
    config.validate()
    ops = tuple(operations)
    train = _validate_xis(train_xis, "train_xis")
    test = None if test_xis is None else _validate_xis(test_xis, "test_xis")

    stored = pack_local_parameters(ops)
    n_params = int(stored.size)
    if initial_parameters is None:
        primary = stored.copy()
    else:
        primary = np.asarray(initial_parameters, dtype=np.float64)
        if primary.shape != (n_params,):
            raise ValueError(f"initial_parameters must have shape {(n_params,)}, got {primary.shape}")
        if not np.all(np.isfinite(primary)):
            raise ValueError("initial_parameters must be finite")

    explicit: list[RealVector] = []
    for item in additional_initial_parameters:
        arr = np.asarray(item, dtype=np.float64)
        if arr.shape != (n_params,):
            raise ValueError(f"additional initial vector must have shape {(n_params,)}, got {arr.shape}")
        if not np.all(np.isfinite(arr)):
            raise ValueError("additional initial vectors must be finite")
        explicit.append(arr.copy())

    if n_params == 0:
        solved = ops
        raw = family_objective_cost(solved, train, config.family_objective)
        metrics_train = evaluate_family(solved, train)
        metrics_test = None if test is None else evaluate_family(solved, test)
        start = StartResult(
            start_index=0,
            start_kind="fixed_only",
            initial_cost=raw,
            final_cost_raw=raw,
            success=True,
            status=0,
            message="No trainable local U3 coefficients.",
            nit=0,
            nfev=1,
            njev=0,
            gradient_inf_norm=0.0,
            parameters=(),
        )
        return OptimizationResult(
            operations=solved,
            parameters=(),
            objective_raw=raw,
            objective_reported=_reported_cost(raw),
            best_start_index=0,
            best_start_kind="fixed_only",
            train_metrics=metrics_train,
            test_metrics=metrics_test,
            starts=(start,),
            config=config,
            objective_components=family_objective_components(solved, train, config.family_objective),
        )

    starts: list[tuple[str, RealVector]] = [("primary", primary)]
    starts.extend(("explicit", x) for x in explicit)
    rng = np.random.default_rng(config.seed)
    for _ in range(config.n_random_starts):
        starts.append(("random", rng.normal(scale=config.random_start_scale, size=n_params)))

    bnds = _bounds(n_params, config.coefficient_bound)
    if bnds is not None:
        lo, hi = -float(config.coefficient_bound), float(config.coefficient_bound)
        starts = [(kind, np.clip(x, lo, hi)) for kind, x in starts]

    diagnostics: list[StartResult] = []
    best_fun = np.inf
    best_x: RealVector | None = None
    best_index = -1
    best_kind = ""

    def objective_and_gradient(x: RealVector) -> tuple[float, RealVector]:
        candidate = with_packed_local_parameters(ops, x)
        value, grad, _ = family_objective_cost_and_gradient(candidate, train, config.family_objective)
        if not np.isfinite(value) or not np.all(np.isfinite(grad)):
            raise FloatingPointError("non-finite objective/gradient in continuous optimizer")
        return float(value), np.asarray(grad, dtype=np.float64)

    for idx, (kind, x0) in enumerate(starts):
        initial_cost = float(family_objective_cost(with_packed_local_parameters(ops, x0), train, config.family_objective))
        res = minimize(
            objective_and_gradient,
            np.asarray(x0, dtype=np.float64),
            method="L-BFGS-B",
            jac=True,
            bounds=bnds,
            options={
                "maxiter": int(config.maxiter),
                "ftol": float(config.ftol),
                "gtol": float(config.gtol),
                "maxls": int(config.maxls),
            },
        )
        final_grad = np.asarray(res.jac, dtype=np.float64)
        diag = StartResult(
            start_index=idx,
            start_kind=kind,
            initial_cost=initial_cost,
            final_cost_raw=float(res.fun),
            success=bool(res.success),
            status=int(res.status),
            message=str(res.message),
            nit=int(res.nit),
            nfev=int(res.nfev),
            njev=int(getattr(res, "njev", 0)),
            gradient_inf_norm=float(np.max(np.abs(final_grad))) if final_grad.size else 0.0,
            parameters=tuple(float(v) for v in res.x),
        )
        diagnostics.append(diag)
        if np.isfinite(res.fun) and float(res.fun) < best_fun:
            best_fun = float(res.fun)
            best_x = np.asarray(res.x, dtype=np.float64).copy()
            best_index = idx
            best_kind = kind

    if best_x is None:
        raise RuntimeError("all L-BFGS-B starts failed to produce a finite objective")

    solved = with_packed_local_parameters(ops, best_x)
    metrics_train = evaluate_family(solved, train)
    metrics_test = None if test is None else evaluate_family(solved, test)
    return OptimizationResult(
        operations=solved,
        parameters=tuple(float(v) for v in best_x),
        objective_raw=best_fun,
        objective_reported=_reported_cost(best_fun),
        best_start_index=best_index,
        best_start_kind=best_kind,
        train_metrics=metrics_train,
        test_metrics=metrics_test,
        starts=tuple(diagnostics),
        config=config,
        objective_components=family_objective_components(solved, train, config.family_objective),
    )
