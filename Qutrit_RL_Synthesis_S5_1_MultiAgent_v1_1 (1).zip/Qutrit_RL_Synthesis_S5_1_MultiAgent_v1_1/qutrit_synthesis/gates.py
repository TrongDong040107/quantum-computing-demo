"""Exact logical single- and two-qutrit gates for the S0 model.

Conventions
-----------
* Basis ordering for one qutrit is |0>, |1>, |2>.
* Basis ordering for two qutrits is |00>, |01>, |02>, |10>, ... |22>.
* The qutrit Fourier transform is chosen so that F3^† Z3 F3 = X3.
* U3(xi, p) uses internal angles lambda_k = p_k * xi.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike, NDArray

ComplexMatrix = NDArray[np.complex128]
RealVector = NDArray[np.float64]

I3: ComplexMatrix = np.eye(3, dtype=np.complex128)
OMEGA3: complex = np.exp(2j * np.pi / 3.0)

X3: ComplexMatrix = np.zeros((3, 3), dtype=np.complex128)
for _j in range(3):
    X3[(_j + 1) % 3, _j] = 1.0

Z3: ComplexMatrix = np.diag([1.0, OMEGA3, OMEGA3**2]).astype(np.complex128)
F3: ComplexMatrix = np.array(
    [[OMEGA3 ** (j * k) for k in range(3)] for j in range(3)],
    dtype=np.complex128,
) / np.sqrt(3.0)


def _as_real8(values: ArrayLike) -> RealVector:
    arr = np.asarray(values, dtype=np.float64)
    if arr.shape != (8,):
        raise ValueError(f"expected an 8-vector, got shape {arr.shape}")
    if not np.all(np.isfinite(arr)):
        raise ValueError("parameters must be finite")
    return arr


def p0(phi: float) -> ComplexMatrix:
    """P0(phi) = exp(-i phi |0><0|)."""
    return np.diag([np.exp(-1j * phi), 1.0, 1.0]).astype(np.complex128)


def p2(phi: float) -> ComplexMatrix:
    """P2(phi) = exp(+i phi |2><2|)."""
    return np.diag([1.0, 1.0, np.exp(1j * phi)]).astype(np.complex128)


def rx01(theta: float) -> ComplexMatrix:
    """exp[-i theta sigma_x^(01)] in the qutrit basis."""
    c, s = np.cos(theta), np.sin(theta)
    return np.array(
        [[c, -1j * s, 0.0], [-1j * s, c, 0.0], [0.0, 0.0, 1.0]],
        dtype=np.complex128,
    )


def rx12(theta: float) -> ComplexMatrix:
    """exp[-i theta sigma_x^(12)] in the qutrit basis."""
    c, s = np.cos(theta), np.sin(theta)
    return np.array(
        [[1.0, 0.0, 0.0], [0.0, c, -1j * s], [0.0, -1j * s, c]],
        dtype=np.complex128,
    )


def r01(theta: float, phi: float) -> ComplexMatrix:
    """Phase-oriented 0-1 selective rotation."""
    return p0(phi) @ rx01(theta) @ p0(-phi)


def r12(theta: float, phi: float) -> ComplexMatrix:
    """Phase-oriented 1-2 selective rotation."""
    return p2(phi) @ rx12(theta) @ p2(-phi)


def ud(alpha: float, beta: float) -> ComplexMatrix:
    """Diagonal two-relative-phase block."""
    return p0(-alpha) @ p2(beta)


def u3_from_internal_angles(lam: ArrayLike) -> ComplexMatrix:
    """Build U3 from internal angles lambda_1,...,lambda_8."""
    x = _as_real8(lam)
    return (
        ud(x[0], x[1])
        @ r01(x[2], x[3])
        @ r12(x[4], x[5])
        @ r01(x[6], x[7])
    )


def u3(xi: float, p: ArrayLike) -> ComplexMatrix:
    """Parameterized local block U3(xi; p) with lambda_k = p_k xi."""
    params = _as_real8(p)
    if not np.isfinite(xi):
        raise ValueError("xi must be finite")
    return u3_from_internal_angles(float(xi) * params)


def u3_parameter_derivative(xi: float, p: ArrayLike, k: int) -> ComplexMatrix:
    """Exact derivative d U3(xi;p) / d p_k via internal-angle shift.

    The canonical identity is
        dU3/dp_k = xi/2 [U3(lambda_k+pi/2)-U3(lambda_k-pi/2)].
    """
    if not 0 <= k < 8:
        raise IndexError("k must be in {0,...,7}")
    params = _as_real8(p)
    if not np.isfinite(xi):
        raise ValueError("xi must be finite")
    lam = float(xi) * params
    plus = lam.copy()
    minus = lam.copy()
    plus[k] += np.pi / 2.0
    minus[k] -= np.pi / 2.0
    return (float(xi) / 2.0) * (
        u3_from_internal_angles(plus) - u3_from_internal_angles(minus)
    )


def cx3() -> ComplexMatrix:
    """Ternary controlled shift: sum_n |n><n| tensor X3^n."""
    out = np.zeros((9, 9), dtype=np.complex128)
    for control in range(3):
        for target in range(3):
            src = 3 * control + target
            dst = 3 * control + ((target + control) % 3)
            out[dst, src] = 1.0
    return out


def cx3_dagger() -> ComplexMatrix:
    """Inverse/adjoint ternary controlled shift."""
    return cx3().conj().T


def cz3() -> ComplexMatrix:
    """Ternary controlled-Z: diag(omega^(control*target))."""
    out = np.zeros((9, 9), dtype=np.complex128)
    for control in range(3):
        for target in range(3):
            idx = 3 * control + target
            out[idx, idx] = OMEGA3 ** (control * target)
    return out
