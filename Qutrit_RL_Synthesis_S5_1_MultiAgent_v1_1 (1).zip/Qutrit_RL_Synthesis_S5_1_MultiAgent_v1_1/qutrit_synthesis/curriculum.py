"""Curriculum reward/state for qutrit circuit synthesis.

The reference implementation uses a sparse reward: reward 2 for beating the
current curriculum threshold and reward 10 for reaching the final threshold.
The manuscript prints a threshold update with an apparent sign inconsistency;
this module intentionally uses the convex-combination behavior of the released
source code: new = best + delta * (old - best).
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class CurriculumConfig:
    min_threshold: float = 1e-2
    initial_threshold: float = 1.0
    delta: float = 0.5
    update_window: int = 500
    success_reward: float = 2.0
    final_reward: float = 10.0

    def validate(self) -> None:
        if not (0.0 < self.min_threshold <= 1.0):
            raise ValueError("min_threshold must be in (0, 1]")
        if not (self.min_threshold <= self.initial_threshold <= 1.0):
            raise ValueError("initial_threshold must be in [min_threshold, 1]")
        if not (0.0 <= self.delta <= 1.0):
            raise ValueError("delta must be in [0, 1]")
        if self.update_window <= 0:
            raise ValueError("update_window must be positive")
        if self.success_reward < 0 or self.final_reward < 0:
            raise ValueError("rewards must be non-negative")
        if self.final_reward < self.success_reward:
            raise ValueError("final_reward must be >= success_reward")


class Curriculum:
    """Persistent curriculum state shared across episodes.

    Threshold updates happen after a complete window of episode-ending costs.
    The best cost in that window is clipped to `min_threshold`, then the current
    threshold is moved halfway (delta=0.5 by default) toward that best value.
    """

    def __init__(self, config: CurriculumConfig = CurriculumConfig()):
        config.validate()
        self.config = config
        self.threshold = float(config.initial_threshold)
        self.episode_costs: deque[float] = deque(maxlen=config.update_window)
        self.total_episodes = 0
        self.total_updates = 0

    def reward(self, cost: float) -> float:
        c = float(cost)
        if not np.isfinite(c):
            raise ValueError("cost must be finite")
        if c <= self.config.min_threshold:
            return float(self.config.final_reward)
        if c <= self.threshold:
            return float(self.config.success_reward)
        return 0.0

    def is_success(self, cost: float) -> bool:
        return float(cost) <= self.threshold

    def is_final_success(self, cost: float) -> bool:
        return float(cost) <= self.config.min_threshold

    def observe_episode(self, final_cost: float) -> bool:
        """Record one episode and update threshold at the end of each window.

        Returns True only when a threshold update was performed.
        """
        c = float(final_cost)
        if not np.isfinite(c):
            raise ValueError("final_cost must be finite")
        self.episode_costs.append(c)
        self.total_episodes += 1
        if len(self.episode_costs) < self.config.update_window:
            return False

        best = float(np.clip(min(self.episode_costs), self.config.min_threshold, 1.0))
        old = self.threshold
        if best < old:
            new = best + self.config.delta * (old - best)
        elif np.isclose(best, old, rtol=0.0, atol=1e-15) and old > self.config.min_threshold:
            # Mirrors the source-code fallback that continues tightening even
            # when the best observed error equals the threshold numerically.
            new = 0.99 * old
        else:
            new = old
        self.threshold = float(np.clip(new, self.config.min_threshold, 1.0))
        self.episode_costs.clear()
        self.total_updates += 1
        return True

    def reset(self) -> None:
        self.threshold = float(self.config.initial_threshold)
        self.episode_costs.clear()
        self.total_episodes = 0
        self.total_updates = 0

    def state_dict(self) -> dict[str, Any]:
        return {
            "config": asdict(self.config),
            "threshold": self.threshold,
            "episode_costs": list(self.episode_costs),
            "total_episodes": self.total_episodes,
            "total_updates": self.total_updates,
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        cfg = CurriculumConfig(**state["config"])
        if cfg != self.config:
            raise ValueError("curriculum config mismatch")
        threshold = float(state["threshold"])
        if not (self.config.min_threshold <= threshold <= 1.0):
            raise ValueError("invalid stored threshold")
        costs = [float(v) for v in state["episode_costs"]]
        if len(costs) >= self.config.update_window:
            raise ValueError("stored episode_costs must be smaller than update_window")
        if not np.all(np.isfinite(costs)):
            raise ValueError("stored episode costs must be finite")
        self.threshold = threshold
        self.episode_costs.clear()
        self.episode_costs.extend(costs)
        self.total_episodes = int(state["total_episodes"])
        self.total_updates = int(state["total_updates"])
