"""Family-level evaluation metrics for parameterized qutrit circuit synthesis."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from collections.abc import Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .circuit import Operation, circuit_unitary
from .fidelity import gate_fidelity
from .target import target_unitary

RealVector = NDArray[np.float64]


def _validate_xis(xis: ArrayLike) -> RealVector:
    x = np.asarray(xis, dtype=np.float64)
    if x.ndim != 1 or x.size == 0:
        raise ValueError("xis must be a non-empty 1D array")
    if not np.all(np.isfinite(x)):
        raise ValueError("xis must be finite")
    return x


@dataclass(frozen=True)
class FamilyMetrics:
    """Pointwise and aggregate ideal-unitary metrics for one topology."""

    n_points: int
    mean_fidelity: float
    min_fidelity: float
    max_fidelity: float
    mean_infidelity: float
    worst_infidelity: float

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


def family_fidelities(operations: Sequence[Operation], xis: ArrayLike) -> RealVector:
    """Return F_xi for every supplied target-family parameter."""
    x = _validate_xis(xis)
    vals = np.empty(x.size, dtype=np.float64)
    for i, xi in enumerate(x):
        vals[i] = gate_fidelity(target_unitary(float(xi)), circuit_unitary(operations, float(xi)))
    return vals


def evaluate_family(operations: Sequence[Operation], xis: ArrayLike) -> FamilyMetrics:
    """Evaluate mean and worst-case family fidelity/infidelity.

    Tiny floating-point overshoots above one are clipped only for reporting.
    The continuous optimizer itself uses the smooth un-clipped overlap objective.
    """
    vals = np.clip(family_fidelities(operations, xis), 0.0, 1.0)
    infs = 1.0 - vals
    return FamilyMetrics(
        n_points=int(vals.size),
        mean_fidelity=float(np.mean(vals)),
        min_fidelity=float(np.min(vals)),
        max_fidelity=float(np.max(vals)),
        mean_infidelity=float(np.mean(infs)),
        worst_infidelity=float(np.max(infs)),
    )
