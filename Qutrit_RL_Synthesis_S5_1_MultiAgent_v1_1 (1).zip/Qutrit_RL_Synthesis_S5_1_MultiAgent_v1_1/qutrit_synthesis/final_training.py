"""Frozen S5 configuration for the paper-scale qutrit synthesis campaign.

This module is the single source of truth for the final training candidate.
Scientific hyperparameters are intentionally centralized so the runner, tests,
protocol manifest and analysis scripts cannot silently drift apart.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal
import hashlib
import json

import numpy as np

from .curriculum import CurriculumConfig
from .environment import EnvironmentConfig, QutritSynthesisEnv
from .family_grid import periodic_uniform_grid, minimum_periodic_separation
from .family_objective import FamilyObjectiveConfig
from .optimizer import OptimizerConfig
from .ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig
from .terminal_credit import TerminalCreditConfig

PolicyArm = Literal["terminal_priority", "uniform", "random"]

S5_SCHEMA_VERSION = 1
MASTER_SEED = 20260911
FINAL_EPISODES_PER_SEED = 300
PROBE_INTERVAL_EPISODES = 10
SNAPSHOT_INTERVAL_EPISODES = 25
N_FINAL_SEEDS = 32

# Generated once from np.random.default_rng(MASTER_SEED), rejecting every seed
# used in S4.2--S4.5.  This literal list is frozen for the final campaign.
FINAL_SEEDS: tuple[int, ...] = (
    2848563236, 3136500928, 664763853, 2415822092,
    1456147837, 3470723316, 615595808, 3126019679,
    4003367978, 2366640083, 2038635434, 3249556869,
    3295871951, 1297074383, 3215563386, 1307110350,
    610128800, 264955536, 1585617532, 3523706143,
    3021360989, 2605615080, 1117262688, 1982082694,
    725104755, 2017918316, 2512306137, 3734087973,
    2031677800, 1529033995, 1054904214, 3770052636,
)

# Audit only: never used by the optimizer, curriculum, replay priority or model
# selection.  Evaluated after training for the final selected topology/state.
DENSE_AUDIT_N = 721
DENSE_AUDIT_PHASE_FRACTION = 0.5


@dataclass(frozen=True)
class FinalTrainingProtocol:
    schema_version: int = S5_SCHEMA_VERSION
    master_seed: int = MASTER_SEED
    n_seeds: int = N_FINAL_SEEDS
    episodes_per_seed: int = FINAL_EPISODES_PER_SEED
    probe_interval_episodes: int = PROBE_INTERVAL_EPISODES
    snapshot_interval_episodes: int = SNAPSHOT_INTERVAL_EPISODES
    primary_arm: str = "terminal_priority"
    control_arm: str = "uniform"
    random_baseline_arm: str = "random"
    train_grid_n: int = 9
    heldout_grid_n: int = 73
    heldout_phase_fraction: float = 0.5
    dense_audit_grid_n: int = DENSE_AUDIT_N
    dense_audit_phase_fraction: float = DENSE_AUDIT_PHASE_FRACTION
    max_steps: int = 5
    optimizer_maxiter: int = 4
    optimizer_random_starts: int = 0
    robust_weight: float = 0.6
    robust_temperature: float = 0.08
    curriculum_min_threshold: float = 1e-2
    curriculum_initial_threshold: float = 0.55
    curriculum_delta: float = 0.5
    curriculum_update_window: int = 8
    terminal_credit_temperature: float = 0.25
    terminal_credit_scale: float = 2.0
    terminal_credit_minimum: float = 0.05
    lstm_hidden_size: int = 128
    lstm_num_layers: int = 2
    learning_rate: float = 1e-2
    batch_size: int = 8
    replay_capacity: int = 5000
    min_replay_size: int = 8
    train_every_interactions: int = 20
    target_update_interactions: int = 20
    gamma_damping: float = 1e-3
    eta_glow: float = 0.1
    beta_start: float = 1e-3
    beta_end: float = 1.0
    beta_anneal_episodes: int = 120
    priority_alpha: float = 1.0
    priority_epsilon: float = 0.05
    final_success_threshold: float = 1e-2

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["seeds"] = list(FINAL_SEEDS)
        return d


PROTOCOL = FinalTrainingProtocol()


def train_xis() -> np.ndarray:
    return periodic_uniform_grid(PROTOCOL.train_grid_n)


def heldout_xis() -> np.ndarray:
    return periodic_uniform_grid(PROTOCOL.heldout_grid_n, phase_fraction=PROTOCOL.heldout_phase_fraction)


def dense_audit_xis() -> np.ndarray:
    return periodic_uniform_grid(PROTOCOL.dense_audit_grid_n, phase_fraction=PROTOCOL.dense_audit_phase_fraction)


def robust_objective() -> FamilyObjectiveConfig:
    return FamilyObjectiveConfig(
        mode="mean_softmax",
        robust_weight=PROTOCOL.robust_weight,
        temperature=PROTOCOL.robust_temperature,
    )


def terminal_credit() -> TerminalCreditConfig:
    return TerminalCreditConfig(
        enabled=True,
        temperature=PROTOCOL.terminal_credit_temperature,
        scale=PROTOCOL.terminal_credit_scale,
        minimum_credit=PROTOCOL.terminal_credit_minimum,
    )


def environment_for(seed: int) -> QutritSynthesisEnv:
    if not isinstance(seed, int):
        raise TypeError("seed must be int")
    return QutritSynthesisEnv(
        train_xis(),
        test_xis=heldout_xis(),
        config=EnvironmentConfig(
            max_steps=PROTOCOL.max_steps,
            optimizer=OptimizerConfig(
                maxiter=PROTOCOL.optimizer_maxiter,
                n_random_starts=PROTOCOL.optimizer_random_starts,
                seed=seed,
                family_objective=robust_objective(),
            ),
            curriculum=CurriculumConfig(
                min_threshold=PROTOCOL.curriculum_min_threshold,
                initial_threshold=PROTOCOL.curriculum_initial_threshold,
                delta=PROTOCOL.curriculum_delta,
                update_window=PROTOCOL.curriculum_update_window,
                success_reward=2.0,
                final_reward=10.0,
            ),
            include_zero_restart=True,
            defer_test_evaluation=True,
        ),
    )


def agent_for(seed: int, *, replay_sampling: Literal["terminal_priority", "uniform"] = "terminal_priority") -> CorrectedPSLSTMAgent:
    if replay_sampling not in ("terminal_priority", "uniform"):
        raise ValueError("replay_sampling must be terminal_priority or uniform")
    return CorrectedPSLSTMAgent(
        PSLSTMConfig(
            hidden_size=PROTOCOL.lstm_hidden_size,
            num_layers=PROTOCOL.lstm_num_layers,
            learning_rate=PROTOCOL.learning_rate,
            batch_size=PROTOCOL.batch_size,
            replay_capacity=PROTOCOL.replay_capacity,
            min_replay_size=PROTOCOL.min_replay_size,
            train_every_interactions=PROTOCOL.train_every_interactions,
            target_update_interactions=PROTOCOL.target_update_interactions,
            gamma_damping=PROTOCOL.gamma_damping,
            eta_glow=PROTOCOL.eta_glow,
            beta_start=PROTOCOL.beta_start,
            beta_end=PROTOCOL.beta_end,
            beta_anneal_episodes=PROTOCOL.beta_anneal_episodes,
            store_successes_only=True,
            replay_sampling=replay_sampling,
            replay_priority_alpha=PROTOCOL.priority_alpha,
            replay_priority_epsilon=PROTOCOL.priority_epsilon,
            seed=seed,
            device="cpu",
        )
    )


def protocol_json_bytes() -> bytes:
    return json.dumps(PROTOCOL.to_dict(), sort_keys=True, separators=(",", ":")).encode("utf-8")


def protocol_sha256() -> str:
    return hashlib.sha256(protocol_json_bytes()).hexdigest()


def validate_final_protocol() -> dict[str, Any]:
    if len(FINAL_SEEDS) != N_FINAL_SEEDS or len(set(FINAL_SEEDS)) != N_FINAL_SEEDS:
        raise RuntimeError("final seed list must contain exactly 32 unique seeds")
    if not all(0 < s < 2**32 for s in FINAL_SEEDS):
        raise RuntimeError("final seeds must be uint32-compatible positive integers")
    tr, te, dense = train_xis(), heldout_xis(), dense_audit_xis()
    sep_train_test = minimum_periodic_separation(tr, te)
    sep_train_dense = minimum_periodic_separation(tr, dense)
    if sep_train_test <= 1e-12:
        raise RuntimeError("train and held-out grids overlap")
    if sep_train_dense <= 1e-12:
        raise RuntimeError("train and dense-audit grids overlap")
    robust_objective().validate()
    terminal_credit().validate()
    # Constructing these objects validates nested configs and dimensions.
    _ = environment_for(FINAL_SEEDS[0])
    _ = agent_for(FINAL_SEEDS[0], replay_sampling="terminal_priority")
    _ = agent_for(FINAL_SEEDS[0], replay_sampling="uniform")
    return {
        "protocol_sha256": protocol_sha256(),
        "n_seeds": len(FINAL_SEEDS),
        "episodes_per_seed": FINAL_EPISODES_PER_SEED,
        "train_grid_n": int(tr.size),
        "heldout_grid_n": int(te.size),
        "dense_audit_grid_n": int(dense.size),
        "min_train_heldout_periodic_separation": float(sep_train_test),
        "min_train_dense_periodic_separation": float(sep_train_dense),
    }
