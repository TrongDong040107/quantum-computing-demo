"""Terminal-objective credit for sparse-reward PS-LSTM training.

The environment reward and success criterion are left unchanged.  For episodes
that do not reach the curriculum threshold, the learner may nevertheless store
the complete trajectory using a monotone transform of the *terminal robust
family objective*:

    r_aux(C) = scale * exp(-C / temperature).

This addresses delayed credit without assuming that fidelity must improve
monotonically along a good circuit prefix.  Because r_aux is strictly decreasing
in C, it does not invert the ordering of terminal circuit quality; exact C=0
remains maximally credited.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import numpy as np


@dataclass(frozen=True)
class TerminalCreditConfig:
    enabled: bool = False
    temperature: float = 0.20
    scale: float = 1.0
    minimum_credit: float = 0.0

    def validate(self) -> None:
        if self.temperature <= 0:
            raise ValueError("temperature must be positive")
        if self.scale < 0:
            raise ValueError("scale must be non-negative")
        if self.minimum_credit < 0:
            raise ValueError("minimum_credit must be non-negative")

    def to_dict(self):
        return asdict(self)


def terminal_objective_credit(cost: float, config: TerminalCreditConfig) -> float:
    config.validate()
    c = float(cost)
    if not np.isfinite(c) or c < -1e-12:
        raise ValueError("cost must be finite and non-negative up to roundoff")
    c = max(c, 0.0)
    value = float(config.scale * np.exp(-c / config.temperature))
    if value < config.minimum_credit:
        return 0.0
    return value
