"""RL-compatible environment for hybrid qutrit circuit synthesis.

This module deliberately does not depend on Gymnasium yet.  Its API follows the
modern reset/step signatures so an adapter can be added later without changing
scientific semantics:

    obs, info = env.reset(seed=...)
    obs, reward, terminated, truncated, info = env.step(action)

One action appends exactly one logical gate.  No automatic gate merging is
performed because same-type qutrit composite gates are not generally mergeable.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from typing import Any, Literal
import copy

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .circuit import ActionKind, Operation
from .curriculum import Curriculum, CurriculumConfig
from .metrics import evaluate_family
from .optimizer import OptimizationResult, OptimizerConfig, optimize_topology
from .topology import warm_start_after_append

RealVector = NDArray[np.float64]
ObservationMode = Literal["last_action", "history_padded"]

ACTION_KINDS: tuple[ActionKind, ...] = ("u3_q0", "u3_q1", "cx", "cx_dg")
ACTION_TO_KIND: dict[int, ActionKind] = {i: k for i, k in enumerate(ACTION_KINDS)}
KIND_TO_ACTION: dict[ActionKind, int] = {k: i for i, k in ACTION_TO_KIND.items()}


@dataclass(frozen=True)
class EnvironmentConfig:
    max_steps: int = 12
    observation_mode: ObservationMode = "last_action"
    optimizer: OptimizerConfig = OptimizerConfig()
    curriculum: CurriculumConfig = CurriculumConfig()
    optimizer_seed_stride: int = 1009
    terminate_on_curriculum_success: bool = True
    include_zero_restart: bool = True
    defer_test_evaluation: bool = False

    def validate(self) -> None:
        if self.max_steps <= 0:
            raise ValueError("max_steps must be positive")
        if self.observation_mode not in ("last_action", "history_padded"):
            raise ValueError("unsupported observation_mode")
        if self.optimizer_seed_stride <= 0:
            raise ValueError("optimizer_seed_stride must be positive")
        self.optimizer.validate()
        self.curriculum.validate()


class QutritSynthesisEnv:
    """Hybrid discrete-topology / continuous-parameter synthesis environment."""

    action_space_n = len(ACTION_KINDS)

    def __init__(
        self,
        train_xis: ArrayLike,
        *,
        test_xis: ArrayLike | None = None,
        config: EnvironmentConfig = EnvironmentConfig(),
        curriculum: Curriculum | None = None,
    ) -> None:
        config.validate()
        self.config = config
        self.train_xis = self._validate_xis(train_xis, "train_xis")
        self.test_xis = None if test_xis is None else self._validate_xis(test_xis, "test_xis")
        self.curriculum = curriculum if curriculum is not None else Curriculum(config.curriculum)
        if self.curriculum.config != config.curriculum:
            raise ValueError("provided curriculum config does not match environment config")

        self._rng = np.random.default_rng(0)
        self._episode_seed = 0
        self._episode_index = -1
        self._step_count = 0
        self._actions: list[int] = []
        self._operations: tuple[Operation, ...] = ()
        self._parameters = np.empty(0, dtype=np.float64)
        self._last_result: OptimizationResult | None = None
        self._terminated = False
        self._truncated = False
        self._episode_recorded = False

    @staticmethod
    def _validate_xis(xis: ArrayLike, name: str) -> RealVector:
        x = np.asarray(xis, dtype=np.float64)
        if x.ndim != 1 or x.size == 0 or not np.all(np.isfinite(x)):
            raise ValueError(f"{name} must be a finite non-empty 1D array")
        return x.copy()

    @property
    def observation_shape(self) -> tuple[int, ...]:
        if self.config.observation_mode == "last_action":
            return (self.action_space_n,)
        return (self.config.max_steps, self.action_space_n)

    @property
    def actions(self) -> tuple[int, ...]:
        return tuple(self._actions)

    @property
    def operation_kinds(self) -> tuple[ActionKind, ...]:
        return tuple(op.kind for op in self._operations)

    @property
    def parameters(self) -> RealVector:
        return self._parameters.copy()

    @property
    def step_count(self) -> int:
        return self._step_count

    def _observation(self) -> RealVector:
        if self.config.observation_mode == "last_action":
            obs = np.zeros(self.action_space_n, dtype=np.float64)
            if self._actions:
                obs[self._actions[-1]] = 1.0
            return obs

        obs = np.zeros((self.config.max_steps, self.action_space_n), dtype=np.float64)
        for t, a in enumerate(self._actions):
            obs[t, a] = 1.0
        return obs

    def _optimizer_config_for_step(self) -> OptimizerConfig:
        # Deterministic across exact replay from the same reset seed.  We avoid
        # mutating global NumPy/Python random state.
        seed = int((self.config.optimizer.seed + self._episode_seed + self.config.optimizer_seed_stride * self._step_count) % (2**31 - 1))
        return replace(self.config.optimizer, seed=seed)

    def _base_info(self) -> dict[str, Any]:
        if self._last_result is None:
            train_metrics = evaluate_family(self._operations, self.train_xis).to_dict()
            test_metrics = None if self.test_xis is None else evaluate_family(self._operations, self.test_xis).to_dict()
            objective = float(train_metrics["mean_infidelity"])
            best_start_kind = None
            optimizer_starts = 0
        else:
            train_metrics = self._last_result.train_metrics.to_dict()
            test_metrics = None if self._last_result.test_metrics is None else self._last_result.test_metrics.to_dict()
            objective = float(self._last_result.objective_reported)
            best_start_kind = self._last_result.best_start_kind
            optimizer_starts = len(self._last_result.starts)
        return {
            "episode_index": self._episode_index,
            "episode_seed": self._episode_seed,
            "step_count": self._step_count,
            "topology": list(self.operation_kinds),
            "actions": list(self._actions),
            "n_parameters": int(self._parameters.size),
            "objective": objective,
            "train_metrics": train_metrics,
            "test_metrics": test_metrics,
            "curriculum_threshold": float(self.curriculum.threshold),
            "curriculum_min_threshold": float(self.curriculum.config.min_threshold),
            "optimizer_best_start_kind": best_start_kind,
            "optimizer_n_starts": optimizer_starts,
        }

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[RealVector, dict[str, Any]]:
        opts = {} if options is None else dict(options)
        if opts.get("reset_curriculum", False):
            self.curriculum.reset()
        if seed is None:
            # Draw from the environment-local generator only.  This permits a
            # training loop to call reset() repeatedly while retaining replayable
            # per-episode seeds in the info dictionary.
            seed = int(self._rng.integers(0, 2**31 - 1))
        if not isinstance(seed, (int, np.integer)):
            raise TypeError("seed must be an integer or None")
        self._episode_seed = int(seed)
        self._rng = np.random.default_rng(self._episode_seed)
        self._episode_index += 1
        self._step_count = 0
        self._actions = []
        self._operations = ()
        self._parameters = np.empty(0, dtype=np.float64)
        self._last_result = None
        self._terminated = False
        self._truncated = False
        self._episode_recorded = False
        info = self._base_info()
        info["reset"] = True
        return self._observation(), info

    def step(self, action: int) -> tuple[RealVector, float, bool, bool, dict[str, Any]]:
        if self._terminated or self._truncated:
            raise RuntimeError("step() called after episode end; call reset()")
        if isinstance(action, np.integer):
            action = int(action)
        if not isinstance(action, int) or action not in ACTION_TO_KIND:
            raise ValueError(f"action must be an integer in [0,{self.action_space_n - 1}]")

        kind = ACTION_TO_KIND[action]
        child_ops, x0 = warm_start_after_append(self._operations, self._parameters, kind)
        self._step_count += 1

        # Parent-solution warm starts can be scientifically useful but also create
        # path-dependent local-minimum trapping.  S1 showed that the five-gate
        # oracle topology is exactly solvable from zero, while a sequential warm
        # start can converge to a poor basin.  Therefore the baseline keeps the
        # warm start as primary and, when it differs from zero, adds a canonical
        # zero restart.  Seeded random restarts from OptimizerConfig remain
        # additional starts.
        extra_starts = ()
        if self.config.include_zero_restart and x0.size and not np.allclose(x0, 0.0, rtol=0.0, atol=0.0):
            extra_starts = (np.zeros_like(x0),)

        result = optimize_topology(
            child_ops,
            self.train_xis,
            test_xis=(None if self.config.defer_test_evaluation else self.test_xis),
            initial_parameters=x0,
            additional_initial_parameters=extra_starts,
            config=self._optimizer_config_for_step(),
        )
        self._last_result = result
        self._operations = result.operations
        self._parameters = np.asarray(result.parameters, dtype=np.float64)
        self._actions.append(action)

        cost = float(result.objective_reported)
        threshold_before = float(self.curriculum.threshold)
        reward = self.curriculum.reward(cost)
        success = self.curriculum.is_success(cost)
        final_success = self.curriculum.is_final_success(cost)
        self._terminated = bool(self.config.terminate_on_curriculum_success and success)
        self._truncated = bool((self._step_count >= self.config.max_steps) and not self._terminated)

        terminal_test_metrics = None
        if (self._terminated or self._truncated) and self.config.defer_test_evaluation and self.test_xis is not None:
            terminal_test_metrics = evaluate_family(self._operations, self.test_xis).to_dict()

        threshold_updated = False
        if (self._terminated or self._truncated) and not self._episode_recorded:
            threshold_updated = self.curriculum.observe_episode(cost)
            self._episode_recorded = True

        info = self._base_info()
        if terminal_test_metrics is not None:
            info["test_metrics"] = terminal_test_metrics
        info.update(
            {
                "action": action,
                "action_kind": kind,
                "reward": reward,
                "success": success,
                "final_success": final_success,
                "terminated": self._terminated,
                "truncated": self._truncated,
                "curriculum_updated": threshold_updated,
                "curriculum_threshold_before": threshold_before,
                "curriculum_threshold_after": float(self.curriculum.threshold),
                "zero_restart_used": bool(extra_starts),
                "optimizer": result.to_dict(),
            }
        )
        return self._observation(), reward, self._terminated, self._truncated, info

    def state_dict(self) -> dict[str, Any]:
        """Exact environment state for future learner/checkpoint resume tests."""
        return {
            "config": {
                "max_steps": self.config.max_steps,
                "observation_mode": self.config.observation_mode,
                "optimizer": asdict(self.config.optimizer),
                "curriculum": asdict(self.config.curriculum),
                "optimizer_seed_stride": self.config.optimizer_seed_stride,
                "terminate_on_curriculum_success": self.config.terminate_on_curriculum_success,
                "include_zero_restart": self.config.include_zero_restart,
                "defer_test_evaluation": self.config.defer_test_evaluation,
            },
            "train_xis": self.train_xis.tolist(),
            "test_xis": None if self.test_xis is None else self.test_xis.tolist(),
            "episode_seed": self._episode_seed,
            "episode_index": self._episode_index,
            "step_count": self._step_count,
            "actions": list(self._actions),
            "operation_kinds": list(self.operation_kinds),
            "parameters": self._parameters.tolist(),
            "terminated": self._terminated,
            "truncated": self._truncated,
            "episode_recorded": self._episode_recorded,
            "rng_state": copy.deepcopy(self._rng.bit_generator.state),
            "curriculum_state": self.curriculum.state_dict(),
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        expected_cfg = self.state_dict()["config"]
        if state["config"] != expected_cfg:
            raise ValueError("environment config mismatch")
        if not np.array_equal(np.asarray(state["train_xis"], dtype=float), self.train_xis):
            raise ValueError("train_xis mismatch")
        stest = state["test_xis"]
        if self.test_xis is None:
            if stest is not None:
                raise ValueError("test_xis mismatch")
        elif stest is None or not np.array_equal(np.asarray(stest, dtype=float), self.test_xis):
            raise ValueError("test_xis mismatch")

        kinds = tuple(state["operation_kinds"])
        actions = [int(a) for a in state["actions"]]
        if tuple(ACTION_TO_KIND[a] for a in actions) != kinds:
            raise ValueError("stored actions/topology mismatch")

        # Reconstruct operation templates and load packed optimized parameters.
        ops: list[Operation] = []
        x = np.asarray(state["parameters"], dtype=np.float64)
        offset = 0
        for kind in kinds:
            if kind in ("u3_q0", "u3_q1"):
                if offset + 8 > x.size:
                    raise ValueError("stored parameter vector is too short")
                ops.append(Operation.local(kind, x[offset:offset+8]))
                offset += 8
            elif kind in ("cx", "cx_dg"):
                ops.append(Operation.fixed(kind))
            else:
                raise ValueError("unknown stored action kind")
        if offset != x.size:
            raise ValueError("stored parameter vector is too long")

        self._episode_seed = int(state["episode_seed"])
        self._episode_index = int(state["episode_index"])
        self._step_count = int(state["step_count"])
        if self._step_count != len(actions):
            raise ValueError("stored step_count/actions mismatch")
        self._actions = actions
        self._operations = tuple(ops)
        self._parameters = x.copy()
        self._terminated = bool(state["terminated"])
        self._truncated = bool(state["truncated"])
        self._episode_recorded = bool(state["episode_recorded"])
        self._last_result = None  # Recomputed on the next step; state semantics are exact.
        self._rng = np.random.default_rng()
        self._rng.bit_generator.state = copy.deepcopy(state["rng_state"])
        self.curriculum.load_state_dict(state["curriculum_state"])

    def close(self) -> None:
        pass
