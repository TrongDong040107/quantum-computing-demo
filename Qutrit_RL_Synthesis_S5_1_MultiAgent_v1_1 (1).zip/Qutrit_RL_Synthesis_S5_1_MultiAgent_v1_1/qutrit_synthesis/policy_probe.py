"""Read-only diagnostics for a saved PS-LSTM state.

The probe reconstructs a private copy of the learner, deterministically forces
specified action prefixes, and never consumes the training agent's RNG state.
"""
from __future__ import annotations
from typing import Any, Sequence

import numpy as np
import torch

from .ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig

EXACT_SEQUENCES = ((2, 1, 2, 1, 2), (3, 1, 3, 1, 3))


def _agent_from_state(state: dict[str, Any]) -> CorrectedPSLSTMAgent:
    agent = CorrectedPSLSTMAgent(PSLSTMConfig(**dict(state["config"])))
    agent.load_state_dict(state)
    return agent


def _force_step(agent: CorrectedPSLSTMAgent, obs: np.ndarray, action: int) -> tuple[np.ndarray, np.ndarray]:
    scores, next_state = agent._candidate_scores_and_states(obs)
    probs = torch.softmax(agent.beta * scores, dim=0).detach().cpu().numpy().astype(np.float64)
    hn, cn = next_state
    agent._hidden = (
        hn[:, action : action + 1, :].detach().clone(),
        cn[:, action : action + 1, :].detach().clone(),
    )
    nxt = np.zeros(agent.config.obs_dim, dtype=np.float64)
    nxt[action] = 1.0
    return probs, nxt


def probe_agent_state(
    agent_state: dict[str, Any],
    sequences: Sequence[Sequence[int]] = EXACT_SEQUENCES,
) -> dict[str, Any]:
    agent = _agent_from_state(agent_state)
    results: list[dict[str, Any]] = []
    for seq0 in sequences:
        seq = tuple(int(a) for a in seq0)
        agent.reset_recurrent_state(clear_pending=True)
        obs = np.zeros(agent.config.obs_dim, dtype=np.float64)
        step_p, ent, maxp = [], [], []
        for action in seq:
            probs, obs = _force_step(agent, obs, action)
            step_p.append(float(probs[action]))
            e = float(-(probs * np.log(np.maximum(probs, 1e-300))).sum())
            ent.append(e)
            maxp.append(float(probs.max()))
        results.append({
            "sequence": list(seq),
            "step_probabilities": step_p,
            "step_entropies_nats": ent,
            "step_normalized_entropies": [x / np.log(agent.config.action_dim) for x in ent],
            "step_max_probabilities": maxp,
            "product_probability": float(np.prod(step_p)),
        })
    products = [x["product_probability"] for x in results]
    L = len(results[0]["sequence"])
    uniform_single = float((1.0 / agent.config.action_dim) ** L)
    return {
        "episodes_trained": int(agent.episodes),
        "beta": float(agent.beta),
        "sequences": results,
        "any_known_exact_probability": float(sum(products)),
        "best_known_exact_probability": float(max(products)),
        "uniform_single_exact_probability": uniform_single,
        "uniform_any_known_probability": float(uniform_single * len(results)),
        "exact_mass_ratio_to_uniform": float(sum(products) / (uniform_single * len(results))),
    }
