"""Deterministic small-depth exhaustive search utilities.

These tools are validation baselines, not intended as a scalable compiler.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from itertools import product
from collections.abc import Iterable, Sequence
from typing import Any

import numpy as np
from numpy.typing import ArrayLike

from .circuit import ActionKind
from .environment import ACTION_KINDS
from .optimizer import OptimizerConfig, optimize_topology
from .topology import number_of_entanglers, operations_from_kinds


@dataclass(frozen=True)
class ExhaustiveCandidate:
    kinds: tuple[ActionKind, ...]
    mean_infidelity: float
    worst_train_infidelity: float
    worst_test_infidelity: float | None
    n_entanglers: int
    parameters: tuple[float, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def enumerate_topologies(
    max_depth: int,
    *,
    min_depth: int = 1,
    action_kinds: Sequence[ActionKind] = ACTION_KINDS,
) -> Iterable[tuple[ActionKind, ...]]:
    """Enumerate every topology in canonical lexicographic action order.

    No pruning or same-gate merging is silently applied.
    """
    if max_depth < 0 or min_depth < 0 or min_depth > max_depth:
        raise ValueError("require 0 <= min_depth <= max_depth")
    kinds = tuple(action_kinds)
    if not kinds:
        raise ValueError("action_kinds must be non-empty")
    if len(set(kinds)) != len(kinds):
        raise ValueError("action_kinds must be unique")
    for depth in range(min_depth, max_depth + 1):
        yield from product(kinds, repeat=depth)


def exhaustive_search(
    max_depth: int,
    train_xis: ArrayLike,
    *,
    test_xis: ArrayLike | None = None,
    min_depth: int = 1,
    action_kinds: Sequence[ActionKind] = ACTION_KINDS,
    optimizer_config: OptimizerConfig = OptimizerConfig(maxiter=40),
) -> tuple[ExhaustiveCandidate, ...]:
    """Optimize and rank all supplied topologies up to a small depth.

    Ranking is deterministic: mean infidelity, worst train infidelity, number of
    entanglers, circuit length, then topology tuple.
    """
    results: list[ExhaustiveCandidate] = []
    for i, kinds in enumerate(enumerate_topologies(max_depth, min_depth=min_depth, action_kinds=action_kinds)):
        ops = operations_from_kinds(kinds)
        # Give each topology a deterministic but distinct optimizer seed.
        cfg = replace(optimizer_config, seed=int(optimizer_config.seed + i))
        r = optimize_topology(ops, train_xis, test_xis=test_xis, config=cfg)
        results.append(
            ExhaustiveCandidate(
                kinds=tuple(kinds),
                mean_infidelity=float(r.train_metrics.mean_infidelity),
                worst_train_infidelity=float(r.train_metrics.worst_infidelity),
                worst_test_infidelity=None if r.test_metrics is None else float(r.test_metrics.worst_infidelity),
                n_entanglers=number_of_entanglers(r.operations),
                parameters=tuple(r.parameters),
            )
        )
    return tuple(sorted(results, key=lambda c: (
        c.mean_infidelity,
        c.worst_train_infidelity,
        c.n_entanglers,
        len(c.kinds),
        c.kinds,
    )))
