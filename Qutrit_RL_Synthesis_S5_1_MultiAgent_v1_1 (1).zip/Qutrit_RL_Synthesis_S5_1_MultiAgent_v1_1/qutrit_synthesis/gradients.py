"""Fidelity gradients and family-level continuous objective.

The packed family gradient uses a GRAPE-style forward/backward product cache so
all local-parameter derivatives for one xi share the same circuit products.
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .circuit import (
    Operation,
    circuit_parameter_derivative,
    circuit_unitary,
    operation_parameter_derivative,
    operation_unitary,
)
from .fidelity import gate_fidelity
from .target import target_unitary

RealVector = NDArray[np.float64]


def _validate_xis(xis: ArrayLike) -> RealVector:
    x = np.asarray(xis, dtype=np.float64)
    if x.ndim != 1 or x.size == 0:
        raise ValueError("xis must be a non-empty 1D array")
    if not np.all(np.isfinite(x)):
        raise ValueError("xis must be finite")
    return x


def fidelity_parameter_gradient(
    operations: Sequence[Operation], xi: float, op_index: int, param_index: int
) -> float:
    """Exact derivative of F_xi wrt one local synthesis coefficient."""
    target = target_unitary(xi)
    trial = circuit_unitary(operations, xi)
    dtrial = circuit_parameter_derivative(operations, xi, op_index, param_index)
    a = np.trace(target.conj().T @ dtrial)
    b = np.trace(trial.conj().T @ target)
    return float((2.0 / 81.0) * np.real(a * b))


def _local_slots(operations: Sequence[Operation]) -> list[int]:
    return [i for i, op in enumerate(operations) if op.kind in ("u3_q0", "u3_q1")]


def pack_local_parameters(operations: Sequence[Operation]) -> RealVector:
    """Flatten local-operation coefficients in chronological order."""
    values: list[float] = []
    for i in _local_slots(operations):
        assert operations[i].params is not None
        values.extend(operations[i].params)
    return np.asarray(values, dtype=np.float64)


def with_packed_local_parameters(
    operations: Sequence[Operation], vector: ArrayLike
) -> tuple[Operation, ...]:
    """Return a new immutable operation tuple with flattened local params replaced."""
    x = np.asarray(vector, dtype=np.float64)
    slots = _local_slots(operations)
    if x.shape != (8 * len(slots),):
        raise ValueError(f"expected shape {(8 * len(slots),)}, got {x.shape}")
    if not np.all(np.isfinite(x)):
        raise ValueError("packed parameters must be finite")
    out = list(operations)
    offset = 0
    for i in slots:
        out[i] = Operation.local(out[i].kind, x[offset : offset + 8])  # type: ignore[arg-type]
        offset += 8
    return tuple(out)


def point_fidelity_and_packed_gradient(
    operations: Sequence[Operation], xi: float
) -> tuple[float, RealVector]:
    """Return F_xi and dF_xi/dp for all local coefficients in one cached pass."""
    ops = tuple(operations)
    if not np.isfinite(xi):
        raise ValueError("xi must be finite")
    n_ops = len(ops)
    slots = _local_slots(ops)
    grad = np.zeros(8 * len(slots), dtype=np.float64)

    gates = [operation_unitary(op, float(xi)) for op in ops]

    # prefix_before[i] = G_{i-1} ... G_0
    prefix_before: list[np.ndarray] = [np.eye(9, dtype=np.complex128) for _ in range(n_ops)]
    running = np.eye(9, dtype=np.complex128)
    for i in range(n_ops):
        prefix_before[i] = running
        running = gates[i] @ running
    trial = running

    # suffix_after[i] = G_{L-1} ... G_{i+1}
    suffix_after: list[np.ndarray] = [np.eye(9, dtype=np.complex128) for _ in range(n_ops)]
    running = np.eye(9, dtype=np.complex128)
    for i in range(n_ops - 1, -1, -1):
        suffix_after[i] = running
        running = running @ gates[i]

    target = target_unitary(float(xi))
    target_dg = target.conj().T
    overlap = np.trace(target_dg @ trial)
    fidelity = float((abs(overlap) ** 2) / 81.0)
    overlap_conj = np.conj(overlap)

    offset = 0
    for op_index in slots:
        left = suffix_after[op_index]
        right = prefix_before[op_index]
        for k in range(8):
            dg = operation_parameter_derivative(ops[op_index], float(xi), k)
            dtrial = left @ dg @ right
            d_overlap = np.trace(target_dg @ dtrial)
            grad[offset + k] = float((2.0 / 81.0) * np.real(d_overlap * overlap_conj))
        offset += 8

    return fidelity, grad


def family_mean_cost_and_gradient(
    operations: Sequence[Operation], xis: ArrayLike
) -> tuple[float, RealVector]:
    """Mean family infidelity and packed gradient in one cached GRAPE-style pass."""
    x = _validate_xis(xis)
    slots = _local_slots(operations)
    grad = np.zeros(8 * len(slots), dtype=np.float64)
    cost_sum = 0.0
    for xi in x:
        fidelity, df = point_fidelity_and_packed_gradient(operations, float(xi))
        cost_sum += 1.0 - fidelity
        grad -= df
    scale = 1.0 / float(x.size)
    return float(cost_sum * scale), grad * scale


def family_mean_cost(operations: Sequence[Operation], xis: ArrayLike) -> float:
    """Mean family infidelity over the supplied xi values."""
    x = _validate_xis(xis)
    values = [1.0 - gate_fidelity(target_unitary(float(xi)), circuit_unitary(operations, float(xi))) for xi in x]
    return float(np.mean(values))


def family_mean_gradient(operations: Sequence[Operation], xis: ArrayLike) -> RealVector:
    """Gradient of mean family infidelity wrt all local coefficients."""
    _, grad = family_mean_cost_and_gradient(operations, xis)
    return grad
