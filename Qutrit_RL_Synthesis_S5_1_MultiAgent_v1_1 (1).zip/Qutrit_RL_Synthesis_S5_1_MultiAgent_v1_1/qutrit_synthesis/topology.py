"""Utilities that separate discrete topology from continuous coefficients."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .circuit import ActionKind, Operation
from .gradients import pack_local_parameters

RealVector = NDArray[np.float64]


def operations_from_kinds(
    kinds: Sequence[ActionKind],
    *,
    local_initial: ArrayLike | None = None,
) -> tuple[Operation, ...]:
    """Create an operation template from discrete action kinds.

    Every local U3 occurrence receives the same initial 8-vector. The default is
    zero. Fixed entanglers carry no continuous parameters.
    """
    init = np.zeros(8, dtype=np.float64) if local_initial is None else np.asarray(local_initial, dtype=np.float64)
    if init.shape != (8,):
        raise ValueError(f"local_initial must have shape (8,), got {init.shape}")
    if not np.all(np.isfinite(init)):
        raise ValueError("local_initial must be finite")
    out: list[Operation] = []
    for kind in kinds:
        if kind in ("u3_q0", "u3_q1"):
            out.append(Operation.local(kind, init))
        elif kind in ("cx", "cx_dg"):
            out.append(Operation.fixed(kind))
        else:
            raise ValueError(f"unknown action kind: {kind}")
    return tuple(out)


def number_of_local_blocks(operations: Sequence[Operation]) -> int:
    return sum(op.kind in ("u3_q0", "u3_q1") for op in operations)


def number_of_entanglers(operations: Sequence[Operation]) -> int:
    return sum(op.kind in ("cx", "cx_dg") for op in operations)


def warm_start_after_append(
    parent_operations: Sequence[Operation],
    parent_parameters: ArrayLike,
    appended_kind: ActionKind,
    *,
    new_local_initial: ArrayLike | None = None,
) -> tuple[tuple[Operation, ...], RealVector]:
    """Create a child topology and packed warm start for one appended action.

    Existing optimized coefficients are copied exactly. A newly appended local
    U3 block is initialized to zeros by default; fixed entanglers add no
    coefficients. This function is intended for the later RL environment.
    """
    parent = tuple(parent_operations)
    x_parent = np.asarray(parent_parameters, dtype=np.float64)
    expected = 8 * number_of_local_blocks(parent)
    if x_parent.shape != (expected,):
        raise ValueError(f"parent_parameters must have shape {(expected,)}, got {x_parent.shape}")
    if not np.all(np.isfinite(x_parent)):
        raise ValueError("parent_parameters must be finite")

    if appended_kind in ("u3_q0", "u3_q1"):
        init = np.zeros(8, dtype=np.float64) if new_local_initial is None else np.asarray(new_local_initial, dtype=np.float64)
        if init.shape != (8,) or not np.all(np.isfinite(init)):
            raise ValueError("new_local_initial must be a finite 8-vector")
        child = parent + (Operation.local(appended_kind, init),)
        x0 = np.concatenate([x_parent, init])
    elif appended_kind in ("cx", "cx_dg"):
        if new_local_initial is not None:
            raise ValueError("new_local_initial is invalid for a fixed entangler")
        child = parent + (Operation.fixed(appended_kind),)
        x0 = x_parent.copy()
    else:
        raise ValueError(f"unknown action kind: {appended_kind}")

    # Defensive invariant: packing the child template must match the returned vector shape.
    if pack_local_parameters(child).shape != x0.shape:
        raise RuntimeError("internal warm-start packing invariant violated")
    return child, x0
