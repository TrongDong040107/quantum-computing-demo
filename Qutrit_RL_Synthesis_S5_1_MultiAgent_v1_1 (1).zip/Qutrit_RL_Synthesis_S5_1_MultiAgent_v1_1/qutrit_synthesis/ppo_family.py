"""Discrete-action PPO family for parameterized two-qutrit circuit synthesis.

This module adds three on-policy baselines to the frozen qutrit environment:

* ``ppo``: memoryless categorical PPO/GAE.
* ``ppo_trxl``: PPO with detached episodic Transformer-XL-style memory.
* ``cad_sf_trppo``: the same temporal PPO plus critic-residual-conditioned
  entropy and residual-gated diagonal Soft-Fisher shaping of the *categorical
  actor head only*.

The CAD adaptation follows the training logic of the PASS CAD-SF-TrPPO method,
but changes the policy family from a continuous Gaussian to a categorical
policy because qutrit circuit synthesis has four discrete actions.  Therefore
all likelihoods, entropy and empirical score moments are computed from
``Categorical(logits=...)``.  No Gaussian or continuous-action formula is
silently reused.

The environment reward and continuous L-BFGS-B inner optimizer are unchanged.
This is important: PPO variants optimize the same synthesis task rather than a
reshaped surrogate task.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal, Sequence
import copy
import math

import numpy as np
from numpy.typing import ArrayLike, NDArray
import torch
from torch import Tensor, nn
from torch.distributions import Categorical

AlgorithmName = Literal["ppo", "ppo_trxl", "cad_sf_trppo"]
RealVector = NDArray[np.float64]


def _layer_init(layer: nn.Linear, std: float = math.sqrt(2.0), bias_const: float = 0.0) -> nn.Linear:
    nn.init.orthogonal_(layer.weight, std)
    nn.init.constant_(layer.bias, bias_const)
    return layer


@dataclass(frozen=True)
class PPOFamilyConfig:
    algorithm: AlgorithmName = "ppo"
    obs_dim: int = 4
    action_dim: int = 4
    hidden_dim: int = 128
    encoder_dim: int = 256
    trxl_num_layers: int = 2
    trxl_num_heads: int = 4
    trxl_memory_length: int = 5
    rollout_steps: int = 100
    update_epochs: int = 4
    num_minibatches: int = 4
    learning_rate: float = 3e-4
    final_learning_rate: float = 5e-5
    lr_anneal_interactions: int = 45_000
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_coef: float = 0.2
    clip_vloss: bool = True
    normalize_advantage: bool = True
    vf_coef: float = 0.5
    ent_coef_start: float = 0.01
    ent_coef_end: float = 0.001
    entropy_anneal_interactions: int = 50_000
    max_grad_norm: float = 0.5
    adam_weight_decay: float = 1e-2
    adam_eps: float = 1e-5
    # CAD-SF-TrPPO only.
    residual_coef: float = 0.5
    cad_alpha_init: float = 0.01
    cad_kappa: float = 5.0
    residual_eps: float = 1e-5
    fisher_damping: float = 1e-8
    fisher_eps: float = 1e-4
    fisher_beta: float = 0.95
    seed: int = 20260922
    device: str = "cpu"

    def validate(self) -> None:
        if self.algorithm not in ("ppo", "ppo_trxl", "cad_sf_trppo"):
            raise ValueError("unknown PPO-family algorithm")
        if self.obs_dim <= 0 or self.action_dim <= 1:
            raise ValueError("invalid observation/action dimensions")
        if self.hidden_dim <= 0 or self.encoder_dim <= 0:
            raise ValueError("hidden dimensions must be positive")
        if self.trxl_num_layers <= 0 or self.trxl_num_heads <= 0:
            raise ValueError("Transformer dimensions must be positive")
        if self.hidden_dim % self.trxl_num_heads != 0:
            raise ValueError("hidden_dim must be divisible by trxl_num_heads")
        if self.trxl_memory_length <= 0:
            raise ValueError("trxl_memory_length must be positive")
        if self.rollout_steps <= 0 or self.update_epochs <= 0 or self.num_minibatches <= 0:
            raise ValueError("rollout/update settings must be positive")
        if self.learning_rate <= 0 or self.final_learning_rate <= 0:
            raise ValueError("learning rates must be positive")
        if self.lr_anneal_interactions <= 0 or self.entropy_anneal_interactions <= 0:
            raise ValueError("anneal horizons must be positive")
        if not (0.0 < self.gamma <= 1.0) or not (0.0 <= self.gae_lambda <= 1.0):
            raise ValueError("invalid gamma/GAE lambda")
        if not (0.0 < self.clip_coef < 1.0):
            raise ValueError("clip_coef must be in (0,1)")
        if self.vf_coef < 0 or self.ent_coef_start < 0 or self.ent_coef_end < 0:
            raise ValueError("loss coefficients must be non-negative")
        if self.max_grad_norm <= 0:
            raise ValueError("max_grad_norm must be positive")
        if self.adam_weight_decay < 0 or self.adam_eps <= 0:
            raise ValueError("invalid AdamW parameters")
        if self.residual_coef < 0 or self.cad_alpha_init < 0 or self.cad_kappa < 0:
            raise ValueError("invalid CAD coefficients")
        if self.residual_eps <= 0 or self.fisher_damping <= 0 or self.fisher_eps <= 0:
            raise ValueError("CAD numerical epsilons must be positive")
        if not (0.0 <= self.fisher_beta < 1.0):
            raise ValueError("fisher_beta must be in [0,1)")
        if self.device != "cpu" and not self.device.startswith("cuda"):
            raise ValueError("device must be cpu or CUDA device string")

    @property
    def uses_memory(self) -> bool:
        return self.algorithm in ("ppo_trxl", "cad_sf_trppo")

    @property
    def uses_cad(self) -> bool:
        return self.algorithm == "cad_sf_trppo"


@dataclass(frozen=True)
class DetachedMemory:
    values: tuple[tuple[tuple[float, ...], ...], ...]  # [L, Nlayer, D]
    mask: tuple[float, ...]  # [L]
    indices: tuple[int, ...]  # [L]
    current_index: int

    @staticmethod
    def empty(config: PPOFamilyConfig) -> "DetachedMemory":
        values = tuple(
            tuple(tuple(0.0 for _ in range(config.hidden_dim)) for _ in range(config.trxl_num_layers))
            for _ in range(config.trxl_memory_length)
        )
        return DetachedMemory(
            values=values,
            mask=tuple(0.0 for _ in range(config.trxl_memory_length)),
            indices=tuple(0 for _ in range(config.trxl_memory_length)),
            current_index=0,
        )


@dataclass(frozen=True)
class PPOActionEvaluation:
    logprob: float
    value: float
    entropy: float
    probabilities: tuple[float, ...]
    memory: DetachedMemory | None
    memory_entry: tuple[tuple[float, ...], ...] | None


@dataclass(frozen=True)
class RolloutTransition:
    observation: tuple[float, ...]
    action: int
    reward: float
    done: bool
    logprob: float
    value: float
    next_value: float
    memory: DetachedMemory | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "observation": list(self.observation),
            "action": int(self.action),
            "reward": float(self.reward),
            "done": bool(self.done),
            "logprob": float(self.logprob),
            "value": float(self.value),
            "next_value": float(self.next_value),
            "memory": None,
        }
        if self.memory is not None:
            d["memory"] = {
                "values": [[[float(v) for v in layer] for layer in step] for step in self.memory.values],
                "mask": list(self.memory.mask),
                "indices": list(self.memory.indices),
                "current_index": int(self.memory.current_index),
            }
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "RolloutTransition":
        mem = d.get("memory")
        memory = None
        if mem is not None:
            memory = DetachedMemory(
                values=tuple(tuple(tuple(float(v) for v in layer) for layer in step) for step in mem["values"]),
                mask=tuple(float(v) for v in mem["mask"]),
                indices=tuple(int(v) for v in mem["indices"]),
                current_index=int(mem["current_index"]),
            )
        return cls(
            observation=tuple(float(v) for v in d["observation"]),
            action=int(d["action"]), reward=float(d["reward"]), done=bool(d["done"]),
            logprob=float(d["logprob"]), value=float(d["value"]), next_value=float(d["next_value"]),
            memory=memory,
        )


class DetachedMemoryAttentionLayer(nn.Module):
    """One Transformer-XL-style layer using fixed behavior memory as K/V context."""

    def __init__(self, dim: int, heads: int):
        super().__init__()
        self.q_norm = nn.LayerNorm(dim)
        self.kv_norm = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.post_attn_norm = nn.LayerNorm(dim)
        self.ff = nn.Sequential(nn.Linear(dim, dim), nn.ReLU(), nn.Linear(dim, dim))
        self.post_ff_norm = nn.LayerNorm(dim)

    def forward(self, x: Tensor, memory: Tensor, memory_mask: Tensor) -> Tensor:
        # x: [B,D], memory: [B,L,D], mask: [B,L] where 1=valid.
        q = self.q_norm(x).unsqueeze(1)
        # Current token is always included in K/V, preventing all-masked attention
        # at the beginning of an episode.
        kv_raw = torch.cat([memory, x.unsqueeze(1)], dim=1)
        kv = self.kv_norm(kv_raw)
        pad_mask = torch.cat(
            [memory_mask <= 0.0, torch.zeros((x.shape[0], 1), dtype=torch.bool, device=x.device)], dim=1
        )
        attn_out, _ = self.attn(q, kv, kv, key_padding_mask=pad_mask, need_weights=False)
        x = x + attn_out.squeeze(1)
        x = x + self.ff(self.post_attn_norm(x))
        return self.post_ff_norm(x)


class CategoricalPPOModel(nn.Module):
    def __init__(self, config: PPOFamilyConfig):
        super().__init__()
        self.config = config
        self.actor = nn.Sequential(
            _layer_init(nn.Linear(config.obs_dim, 256)), nn.ReLU(),
            _layer_init(nn.Linear(256, 256)), nn.ReLU(),
            _layer_init(nn.Linear(256, config.action_dim), std=0.01),
        )
        self.critic = nn.Sequential(
            _layer_init(nn.Linear(config.obs_dim, 256)), nn.ReLU(),
            _layer_init(nn.Linear(256, 256)), nn.ReLU(),
            _layer_init(nn.Linear(256, 1), std=1.0),
        )

    def forward(self, obs: Tensor) -> tuple[Tensor, Tensor, None, None]:
        return self.actor(obs), self.critic(obs).squeeze(-1), None, None

    def actor_head_parameters(self) -> tuple[nn.Parameter, ...]:
        last = self.actor[-1]
        assert isinstance(last, nn.Linear)
        return tuple(last.parameters())


class CategoricalTrXLModel(nn.Module):
    def __init__(self, config: PPOFamilyConfig):
        super().__init__()
        self.config = config
        self.encoder = nn.Sequential(
            _layer_init(nn.Linear(config.obs_dim, config.encoder_dim)), nn.ReLU(),
            _layer_init(nn.Linear(config.encoder_dim, config.hidden_dim)), nn.ReLU(),
        )
        self.position = nn.Embedding(config.trxl_memory_length + 1, config.hidden_dim)
        self.layers = nn.ModuleList(
            [DetachedMemoryAttentionLayer(config.hidden_dim, config.trxl_num_heads) for _ in range(config.trxl_num_layers)]
        )
        self.post = nn.Sequential(_layer_init(nn.Linear(config.hidden_dim, config.hidden_dim)), nn.ReLU())
        self.actor_head = _layer_init(nn.Linear(config.hidden_dim, config.action_dim), std=0.01)
        self.critic_head = _layer_init(nn.Linear(config.hidden_dim, 1), std=1.0)
        self.residual_head = None
        if config.uses_cad:
            self.residual_head = nn.Sequential(
                _layer_init(nn.Linear(config.hidden_dim, 64)), nn.ReLU(),
                _layer_init(nn.Linear(64, 1), std=1.0), nn.Sigmoid(),
            )

    def forward(
        self,
        obs: Tensor,
        memory: Tensor,
        memory_mask: Tensor,
        memory_indices: Tensor,
        current_index: Tensor,
    ) -> tuple[Tensor, Tensor, Tensor, Tensor | None]:
        # memory [B,L,Nlayer,D] stores detached *layer inputs* from behavior collection.
        x = self.encoder(obs)
        # Match the detached-memory convention used by the reference TrXL PPO:
        # positional encoding is applied to cached memory tokens, while the
        # current query token is left unshifted.  We store each layer input
        # *before* positional encoding so replay does not double-add position.
        new_entries: list[Tensor] = []
        for layer_i, layer in enumerate(self.layers):
            new_entries.append(x.detach())
            mem = memory[:, :, layer_i, :]
            idx = memory_indices.clamp(0, self.config.trxl_memory_length)
            mem = mem + self.position(idx)
            x = layer(x, mem, memory_mask)
        h = self.post(x)
        logits = self.actor_head(h)
        value = self.critic_head(h).squeeze(-1)
        residual = None if self.residual_head is None else self.residual_head(h).squeeze(-1)
        return logits, value, torch.stack(new_entries, dim=1), residual

    def actor_head_parameters(self) -> tuple[nn.Parameter, ...]:
        return tuple(self.actor_head.parameters())


class DiscretePPOAgent:
    """Stateful PPO/PPO-TrXL/CAD-SF-TrPPO learner with exact CPU resume."""

    format_version = 1

    def __init__(self, config: PPOFamilyConfig):
        config.validate()
        self.config = config
        self.device = torch.device(config.device)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable")
        devices: list[int] = [] if self.device.type == "cpu" else [self.device.index or 0]
        with torch.random.fork_rng(devices=devices):
            torch.manual_seed(config.seed)
            self.model: nn.Module
            if config.algorithm == "ppo":
                self.model = CategoricalPPOModel(config)
            else:
                self.model = CategoricalTrXLModel(config)
        self.model.to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=config.learning_rate,
            weight_decay=config.adam_weight_decay, eps=config.adam_eps,
        )
        self._np_rng = np.random.default_rng(config.seed + 17)
        self._torch_rng = torch.Generator(device="cpu")
        self._torch_rng.manual_seed(config.seed + 23)
        self.interactions = 0
        self.episodes = 0
        self.gradient_updates = 0
        self.ppo_updates = 0
        self.last_metrics: dict[str, float] = {}
        self.rollout: list[RolloutTransition] = []
        self._episode_memory: list[np.ndarray] = []  # each [Nlayer,D]
        self._episode_index = 0
        self._fisher_diag: list[Tensor] = []
        if config.uses_cad:
            self._fisher_diag = [torch.full_like(p, config.fisher_damping) for p in self._actor_head_parameters()]

    def _actor_head_parameters(self) -> tuple[nn.Parameter, ...]:
        if isinstance(self.model, CategoricalPPOModel):
            return self.model.actor_head_parameters()
        assert isinstance(self.model, CategoricalTrXLModel)
        return self.model.actor_head_parameters()

    @staticmethod
    def _obs(observation: ArrayLike, dim: int) -> RealVector:
        obs = np.asarray(observation, dtype=np.float64)
        if obs.shape != (dim,) or not np.all(np.isfinite(obs)):
            raise ValueError(f"observation must be finite with shape {(dim,)}")
        return obs

    def reset_episode(self) -> None:
        self._episode_memory.clear()
        self._episode_index = 0

    def _memory_snapshot(self) -> DetachedMemory:
        c = self.config
        if not c.uses_memory:
            return DetachedMemory.empty(c)
        vals = np.zeros((c.trxl_memory_length, c.trxl_num_layers, c.hidden_dim), dtype=np.float32)
        mask = np.zeros(c.trxl_memory_length, dtype=np.float32)
        indices = np.zeros(c.trxl_memory_length, dtype=np.int64)
        entries = self._episode_memory[-c.trxl_memory_length:]
        start = c.trxl_memory_length - len(entries)
        for j, entry in enumerate(entries):
            vals[start + j] = entry
            mask[start + j] = 1.0
            absolute_idx = max(0, self._episode_index - len(entries) + j)
            indices[start + j] = min(absolute_idx, c.trxl_memory_length)
        return DetachedMemory(
            values=tuple(tuple(tuple(float(v) for v in layer) for layer in step) for step in vals),
            mask=tuple(float(v) for v in mask),
            indices=tuple(int(v) for v in indices),
            current_index=min(self._episode_index, c.trxl_memory_length),
        )

    def _forward_one(self, obs: RealVector, memory: DetachedMemory | None = None):
        obs_t = torch.as_tensor(obs, dtype=torch.float32, device=self.device).view(1, -1)
        if self.config.algorithm == "ppo":
            assert isinstance(self.model, CategoricalPPOModel)
            return self.model(obs_t)
        assert isinstance(self.model, CategoricalTrXLModel)
        mem = self._memory_snapshot() if memory is None else memory
        memory_t = torch.tensor(mem.values, dtype=torch.float32, device=self.device).unsqueeze(0)
        mask_t = torch.tensor(mem.mask, dtype=torch.float32, device=self.device).unsqueeze(0)
        idx_t = torch.tensor(mem.indices, dtype=torch.long, device=self.device).unsqueeze(0)
        cur_t = torch.tensor([mem.current_index], dtype=torch.long, device=self.device)
        return self.model(obs_t, memory_t, mask_t, idx_t, cur_t)

    def act(self, observation: ArrayLike, *, deterministic: bool = False) -> tuple[int, PPOActionEvaluation]:
        obs = self._obs(observation, self.config.obs_dim)
        memory = self._memory_snapshot() if self.config.uses_memory else None
        with torch.no_grad():
            logits, value, entry, _ = self._forward_one(obs, memory)
            dist = Categorical(logits=logits)
            probs = dist.probs[0]
            if deterministic:
                action = int(torch.argmax(probs).item())
            else:
                action = int(torch.multinomial(probs.detach().cpu(), 1, generator=self._torch_rng).item())
            action_t = torch.tensor([action], device=self.device)
            logprob = float(dist.log_prob(action_t).item())
            entropy = float(dist.entropy().item())
            value_f = float(value.item())
        entry_tuple = None
        if self.config.uses_memory:
            assert entry is not None
            e = entry[0].detach().cpu().numpy().astype(np.float32)
            self._episode_memory.append(e)
            self._episode_index += 1
            entry_tuple = tuple(tuple(float(v) for v in layer) for layer in e)
        return action, PPOActionEvaluation(
            logprob=logprob, value=value_f, entropy=entropy,
            probabilities=tuple(float(x) for x in probs.cpu().numpy()),
            memory=memory, memory_entry=entry_tuple,
        )

    def value(self, observation: ArrayLike, memory: DetachedMemory | None = None) -> float:
        obs = self._obs(observation, self.config.obs_dim)
        with torch.no_grad():
            _, value, _, _ = self._forward_one(obs, memory)
        return float(value.item())

    def observe(
        self,
        observation: ArrayLike,
        action: int,
        reward: float,
        next_observation: ArrayLike,
        *,
        terminated: bool,
        truncated: bool,
        evaluation: PPOActionEvaluation,
    ) -> dict[str, float] | None:
        obs = self._obs(observation, self.config.obs_dim)
        nxt = self._obs(next_observation, self.config.obs_dim)
        if not (0 <= int(action) < self.config.action_dim):
            raise ValueError("invalid action")
        if not np.isfinite(reward):
            raise ValueError("reward must be finite")
        done = bool(terminated or truncated)
        next_value = 0.0 if done else self.value(nxt, self._memory_snapshot() if self.config.uses_memory else None)
        self.rollout.append(RolloutTransition(
            observation=tuple(float(v) for v in obs), action=int(action), reward=float(reward), done=done,
            logprob=float(evaluation.logprob), value=float(evaluation.value), next_value=float(next_value),
            memory=evaluation.memory,
        ))
        self.interactions += 1
        metrics = None
        if len(self.rollout) >= self.config.rollout_steps:
            metrics = self.update(force=False)
        if done:
            self.episodes += 1
            self.reset_episode()
        return metrics

    def _anneal(self, start: float, end: float, horizon: int) -> float:
        frac = min(max(self.interactions / horizon, 0.0), 1.0)
        return float(start + frac * (end - start))

    @property
    def learning_rate(self) -> float:
        return self._anneal(self.config.learning_rate, self.config.final_learning_rate, self.config.lr_anneal_interactions)

    @property
    def entropy_coef(self) -> float:
        return self._anneal(self.config.ent_coef_start, self.config.ent_coef_end, self.config.entropy_anneal_interactions)

    def _batch_forward(self, transitions: Sequence[RolloutTransition], indices: np.ndarray):
        obs = torch.tensor([transitions[int(i)].observation for i in indices], dtype=torch.float32, device=self.device)
        if self.config.algorithm == "ppo":
            assert isinstance(self.model, CategoricalPPOModel)
            return self.model(obs)
        assert isinstance(self.model, CategoricalTrXLModel)
        mems = [transitions[int(i)].memory for i in indices]
        if any(m is None for m in mems):
            raise RuntimeError("missing temporal memory")
        mem_t = torch.tensor([m.values for m in mems if m is not None], dtype=torch.float32, device=self.device)
        mask_t = torch.tensor([m.mask for m in mems if m is not None], dtype=torch.float32, device=self.device)
        idx_t = torch.tensor([m.indices for m in mems if m is not None], dtype=torch.long, device=self.device)
        cur_t = torch.tensor([m.current_index for m in mems if m is not None], dtype=torch.long, device=self.device)
        return self.model(obs, mem_t, mask_t, idx_t, cur_t)

    def _compute_advantages(self, transitions: Sequence[RolloutTransition]) -> tuple[np.ndarray, np.ndarray]:
        n = len(transitions)
        adv = np.zeros(n, dtype=np.float64)
        last = 0.0
        for t in range(n - 1, -1, -1):
            tr = transitions[t]
            nonterminal = 0.0 if tr.done else 1.0
            delta = tr.reward + self.config.gamma * tr.next_value * nonterminal - tr.value
            last = delta + self.config.gamma * self.config.gae_lambda * nonterminal * last
            adv[t] = last
        values = np.asarray([x.value for x in transitions], dtype=np.float64)
        return adv, adv + values

    def update(self, *, force: bool = False) -> dict[str, float] | None:
        if not self.rollout:
            return None
        if not force and len(self.rollout) < self.config.rollout_steps:
            return None
        transitions = list(self.rollout)
        advantages_np, returns_np = self._compute_advantages(transitions)
        old_logp = torch.tensor([x.logprob for x in transitions], dtype=torch.float32, device=self.device)
        old_values = torch.tensor([x.value for x in transitions], dtype=torch.float32, device=self.device)
        actions = torch.tensor([x.action for x in transitions], dtype=torch.long, device=self.device)
        advantages = torch.tensor(advantages_np, dtype=torch.float32, device=self.device)
        returns = torch.tensor(returns_np, dtype=torch.float32, device=self.device)
        n = len(transitions)

        for group in self.optimizer.param_groups:
            group["lr"] = self.learning_rate

        last_pg = last_v = last_ent = last_res = last_alpha = last_kl = 0.0
        fisher_weight = 0.0
        for _ in range(self.config.update_epochs):
            order = self._np_rng.permutation(n)
            # At most num_minibatches; never silently drop a tail.
            splits = [x for x in np.array_split(order, min(self.config.num_minibatches, n)) if len(x)]
            for mb in splits:
                mb_t = torch.tensor(mb, dtype=torch.long, device=self.device)
                logits, newvalue, _, residual_pred = self._batch_forward(transitions, mb)
                dist = Categorical(logits=logits)
                newlogp = dist.log_prob(actions[mb_t])
                entropy = dist.entropy()
                ratio = torch.exp(newlogp - old_logp[mb_t])
                mb_adv = advantages[mb_t]
                if self.config.normalize_advantage and mb_adv.numel() > 1:
                    mb_adv = (mb_adv - mb_adv.mean()) / (mb_adv.std(unbiased=False) + 1e-8)
                pg1 = -mb_adv * ratio
                pg2 = -mb_adv * torch.clamp(ratio, 1.0 - self.config.clip_coef, 1.0 + self.config.clip_coef)
                pg_loss = torch.maximum(pg1, pg2).mean()

                if self.config.clip_vloss:
                    v_unclipped = (newvalue - returns[mb_t]) ** 2
                    v_clipped_pred = old_values[mb_t] + torch.clamp(
                        newvalue - old_values[mb_t], -self.config.clip_coef, self.config.clip_coef
                    )
                    v_clipped = (v_clipped_pred - returns[mb_t]) ** 2
                    v_loss = 0.5 * torch.maximum(v_unclipped, v_clipped).mean()
                else:
                    v_loss = 0.5 * ((newvalue - returns[mb_t]) ** 2).mean()

                self.optimizer.zero_grad(set_to_none=True)
                residual_loss = torch.zeros((), device=self.device)
                if self.config.uses_cad:
                    assert residual_pred is not None
                    delta = torch.abs(newvalue.detach() - returns[mb_t])
                    nu = torch.clamp(delta / (delta.mean() + self.config.residual_eps), 0.0, 1.0)
                    residual_loss = torch.mean((residual_pred - nu) ** 2)
                    w = residual_pred.detach().mean()
                    alpha_dyn = self.config.cad_kappa * self.config.cad_alpha_init * w
                    loss = pg_loss + self.config.vf_coef * v_loss + self.config.residual_coef * residual_loss - alpha_dyn * entropy.mean()

                    actor_params = self._actor_head_parameters()
                    accum = [torch.zeros_like(p) for p in actor_params]
                    for i in range(newlogp.shape[0]):
                        gs = torch.autograd.grad(newlogp[i], actor_params, retain_graph=True, allow_unused=True)
                        for j, g in enumerate(gs):
                            if g is not None:
                                accum[j].add_(g.detach().pow(2))
                    with torch.no_grad():
                        for j in range(len(actor_params)):
                            f_new = accum[j] / max(1, newlogp.shape[0]) + self.config.fisher_damping
                            self._fisher_diag[j].mul_(self.config.fisher_beta).add_((1.0 - self.config.fisher_beta) * f_new)
                    fisher_weight = float(w.item())
                    last_alpha = float(alpha_dyn.item())
                else:
                    ent_coef = self.entropy_coef
                    loss = pg_loss + self.config.vf_coef * v_loss - ent_coef * entropy.mean()
                    last_alpha = float(ent_coef)

                loss.backward()
                if self.config.uses_cad:
                    with torch.no_grad():
                        for p, fdiag in zip(self._actor_head_parameters(), self._fisher_diag):
                            if p.grad is None:
                                continue
                            original = p.grad.clone()
                            fisher_grad = original / (torch.sqrt(fdiag + self.config.fisher_damping) + self.config.fisher_eps)
                            p.grad.copy_(fisher_weight * fisher_grad + (1.0 - fisher_weight) * original)
                nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
                self.optimizer.step()
                self.gradient_updates += 1
                with torch.no_grad():
                    approx_kl = ((ratio - 1.0) - torch.log(ratio)).mean()
                last_pg = float(pg_loss.detach().item())
                last_v = float(v_loss.detach().item())
                last_ent = float(entropy.mean().detach().item())
                last_res = float(residual_loss.detach().item())
                last_kl = float(approx_kl.detach().item())

        self.ppo_updates += 1
        self.rollout.clear()
        self.last_metrics = {
            "policy_loss": last_pg,
            "value_loss": last_v,
            "entropy": last_ent,
            "residual_loss": last_res,
            "entropy_coefficient": last_alpha,
            "fisher_weight": fisher_weight,
            "approx_kl": last_kl,
            "learning_rate": self.learning_rate,
            "gradient_updates": float(self.gradient_updates),
            "ppo_updates": float(self.ppo_updates),
        }
        if not all(np.isfinite(v) for v in self.last_metrics.values()):
            raise FloatingPointError("non-finite PPO metric")
        return dict(self.last_metrics)

    def state_dict(self) -> dict[str, Any]:
        return {
            "format_version": self.format_version,
            "config": asdict(self.config),
            "model": copy.deepcopy(self.model.state_dict()),
            "optimizer": copy.deepcopy(self.optimizer.state_dict()),
            "np_rng_state": copy.deepcopy(self._np_rng.bit_generator.state),
            "torch_rng_state": self._torch_rng.get_state().clone(),
            "interactions": self.interactions,
            "episodes": self.episodes,
            "gradient_updates": self.gradient_updates,
            "ppo_updates": self.ppo_updates,
            "last_metrics": dict(self.last_metrics),
            "rollout": [x.to_dict() for x in self.rollout],
            "episode_memory": [x.tolist() for x in self._episode_memory],
            "episode_index": self._episode_index,
            "fisher_diag": [x.detach().cpu().clone() for x in self._fisher_diag],
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        if int(state["format_version"]) != self.format_version:
            raise ValueError("unsupported PPO agent state format")
        if dict(state["config"]) != asdict(self.config):
            raise ValueError("PPO agent config mismatch")
        self.model.load_state_dict(state["model"])
        self.optimizer.load_state_dict(state["optimizer"])
        self._np_rng = np.random.default_rng()
        self._np_rng.bit_generator.state = copy.deepcopy(state["np_rng_state"])
        self._torch_rng = torch.Generator(device="cpu")
        self._torch_rng.set_state(state["torch_rng_state"].clone())
        self.interactions = int(state["interactions"])
        self.episodes = int(state["episodes"])
        self.gradient_updates = int(state["gradient_updates"])
        self.ppo_updates = int(state["ppo_updates"])
        self.last_metrics = {str(k): float(v) for k, v in state["last_metrics"].items()}
        self.rollout = [RolloutTransition.from_dict(x) for x in state["rollout"]]
        self._episode_memory = [np.asarray(x, dtype=np.float32) for x in state["episode_memory"]]
        self._episode_index = int(state["episode_index"])
        if self.config.uses_cad:
            saved = state["fisher_diag"]
            if len(saved) != len(self._fisher_diag):
                raise ValueError("Fisher state size mismatch")
            self._fisher_diag = [x.to(self.device).clone() for x in saved]

    def flush(self) -> dict[str, float] | None:
        return self.update(force=True)


def make_ppo_agent(
    algorithm: AlgorithmName,
    *, seed: int,
    episodes_budget: int = 10_000,
    max_steps: int = 5,
    device: str = "cpu",
    rollout_steps: int = 100,
) -> DiscretePPOAgent:
    if episodes_budget <= 0 or max_steps <= 0:
        raise ValueError("positive training budget required")
    interaction_budget = episodes_budget * max_steps
    return DiscretePPOAgent(PPOFamilyConfig(
        algorithm=algorithm,
        seed=int(seed),
        device=device,
        rollout_steps=rollout_steps,
        lr_anneal_interactions=max(1, int(0.9 * interaction_budget)),
        entropy_anneal_interactions=max(1, interaction_budget),
        trxl_memory_length=max_steps,
    ))
