"""Read-only exact-sequence policy probes for discrete PPO-family agents."""
from __future__ import annotations

from typing import Any, Sequence
import copy
import numpy as np
import torch
from torch.distributions import Categorical

from .ppo_family import DiscretePPOAgent, PPOFamilyConfig

EXACT_SEQUENCES = ((2, 1, 2, 1, 2), (3, 1, 3, 1, 3))


def _agent_from_state(state: dict[str, Any]) -> DiscretePPOAgent:
    agent = DiscretePPOAgent(PPOFamilyConfig(**dict(state["config"])))
    agent.load_state_dict(copy.deepcopy(state))
    return agent


def probe_ppo_agent_state(
    agent_state: dict[str, Any],
    sequences: Sequence[Sequence[int]] = EXACT_SEQUENCES,
) -> dict[str, Any]:
    agent = _agent_from_state(agent_state)
    results: list[dict[str, Any]] = []
    for seq0 in sequences:
        seq = tuple(int(a) for a in seq0)
        agent.reset_episode()
        obs = np.zeros(agent.config.obs_dim, dtype=np.float64)
        probs_taken: list[float] = []
        entropies: list[float] = []
        max_probs: list[float] = []
        for action in seq:
            # Use the normal deterministic forward path but do not consume RNG.
            obs_t = agent._obs(obs, agent.config.obs_dim)
            memory = agent._memory_snapshot() if agent.config.uses_memory else None
            with torch.no_grad():
                logits, _, entry, _ = agent._forward_one(obs_t, memory)
                dist = Categorical(logits=logits)
                probs = dist.probs[0].detach().cpu().numpy().astype(np.float64)
            probs_taken.append(float(probs[action]))
            e = float(-(probs * np.log(np.maximum(probs, 1e-300))).sum())
            entropies.append(e)
            max_probs.append(float(probs.max()))
            if agent.config.uses_memory:
                assert entry is not None
                agent._episode_memory.append(entry[0].detach().cpu().numpy().astype(np.float32))
                agent._episode_index += 1
            obs = np.zeros(agent.config.obs_dim, dtype=np.float64)
            obs[action] = 1.0
        results.append({
            "sequence": list(seq),
            "step_probabilities": probs_taken,
            "step_entropies_nats": entropies,
            "step_normalized_entropies": [e / np.log(agent.config.action_dim) for e in entropies],
            "step_max_probabilities": max_probs,
            "product_probability": float(np.prod(probs_taken)),
        })
    products = [r["product_probability"] for r in results]
    L = len(results[0]["sequence"])
    uniform_single = float((1.0 / agent.config.action_dim) ** L)
    return {
        "algorithm": agent.config.algorithm,
        "episodes_trained": int(agent.episodes),
        "interactions": int(agent.interactions),
        "sequences": results,
        "any_known_exact_probability": float(sum(products)),
        "best_known_exact_probability": float(max(products)),
        "uniform_single_exact_probability": uniform_single,
        "uniform_any_known_probability": float(uniform_single * len(results)),
        "exact_mass_ratio_to_uniform": float(sum(products) / (uniform_single * len(results))),
    }
