"""Deterministic periodic xi-grid construction for the target family."""
from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

RealVector = NDArray[np.float64]


def periodic_uniform_grid(n: int, *, phase_fraction: float = 0.0) -> RealVector:
    """Uniform grid on [-pi,pi), shifted by a fraction of one grid spacing."""
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")
    if not np.isfinite(phase_fraction):
        raise ValueError("phase_fraction must be finite")
    spacing = 2.0 * np.pi / n
    x = -np.pi + spacing * (np.arange(n, dtype=np.float64) + float(phase_fraction))
    # Wrap exactly to the canonical periodic interval.
    return ((x + np.pi) % (2.0 * np.pi)) - np.pi


def minimum_periodic_separation(a: RealVector, b: RealVector) -> float:
    aa = np.asarray(a, dtype=np.float64).reshape(-1, 1)
    bb = np.asarray(b, dtype=np.float64).reshape(1, -1)
    d = np.abs(aa - bb)
    d = np.minimum(d, 2.0 * np.pi - np.minimum(d, 2.0 * np.pi))
    return float(np.min(d))
