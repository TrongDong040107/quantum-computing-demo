"""Corrected PS-LSTM learner for the qutrit synthesis environment.

Scientific intent
-----------------
This module reproduces the *structure* described in the reference paper while
fixing several implementation ambiguities observed in the released source:

* the LSTM depth is explicit and defaults to the two layers reported in the
  manuscript;
* PS damping ``gamma_damping`` is actually present in the fitted target;
* the target network is synchronized by *environment interactions*, not by
  gradient-update count;
* exact-resume state contains the Adam optimizer, replay buffer, recurrent
  hidden/cell state, local RNGs, pending episode, and all counters;
* only the recurrent state corresponding to the sampled candidate action is
  propagated to the next interaction.

The network represents an h-value h_theta(s, a, u).  Candidate actions are
sampled from

    pi(a|s,u) = softmax(beta * h_theta(s,a,u)).

The fitted deep-PS target used here is

    y = h_target - gamma * (h_target - 1) + r_glow,

which is the neural fitted analogue of the standard PS h-value update.  A
successful terminal reward is propagated backward through an episode as
r_glow(t) = R_terminal * (1-eta)^(T-1-t).

This is a corrected research baseline, not a claim that every unpublished
implementation detail of the original source has been reconstructed exactly.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Sequence
import copy

import numpy as np
from numpy.typing import ArrayLike, NDArray
import torch
from torch import Tensor, nn

RealVector = NDArray[np.float64]


@dataclass(frozen=True)
class PSLSTMConfig:
    obs_dim: int = 4
    action_dim: int = 4
    hidden_size: int = 128
    num_layers: int = 2
    learning_rate: float = 1e-2
    batch_size: int = 64
    replay_capacity: int = 50_000
    min_replay_size: int = 64
    train_every_interactions: int = 100
    target_update_interactions: int = 50
    gamma_damping: float = 1e-3
    eta_glow: float = 0.1
    beta_start: float = 1e-3
    beta_end: float = 1.0
    beta_anneal_episodes: int = 10_000
    gradient_clip_norm: float | None = 5.0
    store_successes_only: bool = True
    replay_sampling: str = "uniform"
    replay_priority_alpha: float = 1.0
    replay_priority_epsilon: float = 0.05
    seed: int = 20260910
    device: str = "cpu"

    def validate(self) -> None:
        if self.obs_dim <= 0 or self.action_dim <= 1:
            raise ValueError("obs_dim must be positive and action_dim must exceed one")
        if self.hidden_size <= 0 or self.num_layers <= 0:
            raise ValueError("hidden_size and num_layers must be positive")
        if self.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        if self.batch_size <= 0 or self.replay_capacity <= 0:
            raise ValueError("batch_size and replay_capacity must be positive")
        if self.min_replay_size < 1 or self.min_replay_size > self.replay_capacity:
            raise ValueError("min_replay_size must be in [1,replay_capacity]")
        if self.train_every_interactions <= 0 or self.target_update_interactions <= 0:
            raise ValueError("interaction cadences must be positive")
        if not (0.0 <= self.gamma_damping <= 1.0):
            raise ValueError("gamma_damping must be in [0,1]")
        if not (0.0 <= self.eta_glow <= 1.0):
            raise ValueError("eta_glow must be in [0,1]")
        if self.beta_start <= 0 or self.beta_end <= 0:
            raise ValueError("beta endpoints must be positive")
        if self.beta_anneal_episodes <= 0:
            raise ValueError("beta_anneal_episodes must be positive")
        if self.gradient_clip_norm is not None and self.gradient_clip_norm <= 0:
            raise ValueError("gradient_clip_norm must be positive or None")
        if self.replay_sampling not in ("uniform", "terminal_priority"):
            raise ValueError("replay_sampling must be uniform or terminal_priority")
        if self.replay_priority_alpha < 0 or self.replay_priority_epsilon <= 0:
            raise ValueError("invalid replay priority parameters")
        if self.device != "cpu" and not self.device.startswith("cuda"):
            raise ValueError("device must be 'cpu' or a CUDA device string")


@dataclass(frozen=True)
class ReplayItem:
    """One recurrent training sample ending at one chosen action."""

    observations: tuple[tuple[float, ...], ...]
    actions: tuple[int, ...]
    glow_reward: float
    sampling_priority: float = 1.0

    def validate(self, obs_dim: int, action_dim: int) -> None:
        if len(self.observations) == 0 or len(self.observations) != len(self.actions):
            raise ValueError("replay prefix must be non-empty and aligned")
        for obs in self.observations:
            if len(obs) != obs_dim or not np.all(np.isfinite(obs)):
                raise ValueError("invalid replay observation")
        for a in self.actions:
            if not isinstance(a, int) or not (0 <= a < action_dim):
                raise ValueError("invalid replay action")
        if not np.isfinite(self.glow_reward):
            raise ValueError("glow_reward must be finite")
        if not np.isfinite(self.sampling_priority) or self.sampling_priority < 0:
            raise ValueError("sampling_priority must be finite and non-negative")

    def to_dict(self) -> dict[str, Any]:
        return {
            "observations": [list(x) for x in self.observations],
            "actions": list(self.actions),
            "glow_reward": float(self.glow_reward),
            "sampling_priority": float(self.sampling_priority),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ReplayItem":
        return cls(
            observations=tuple(tuple(float(v) for v in x) for x in d["observations"]),
            actions=tuple(int(a) for a in d["actions"]),
            glow_reward=float(d["glow_reward"]),
            sampling_priority=float(d.get("sampling_priority", 1.0)),
        )


class ReplayBuffer:
    def __init__(self, capacity: int):
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self.capacity = int(capacity)
        self._items: deque[ReplayItem] = deque(maxlen=self.capacity)

    def __len__(self) -> int:
        return len(self._items)

    def add(self, item: ReplayItem) -> None:
        self._items.append(item)

    def extend(self, items: Sequence[ReplayItem]) -> None:
        self._items.extend(items)

    def sample(self, n: int, rng: np.random.Generator, *, mode: str = "uniform", alpha: float = 1.0, epsilon: float = 0.05) -> list[ReplayItem]:
        if n <= 0:
            raise ValueError("n must be positive")
        if n > len(self._items):
            raise ValueError("cannot sample more items than replay contains")
        items = list(self._items)
        if mode == "uniform":
            p = None
        elif mode == "terminal_priority":
            w = np.asarray([(x.sampling_priority + epsilon) ** alpha for x in items], dtype=np.float64)
            p = w / w.sum()
        else:
            raise ValueError("unknown replay sampling mode")
        idx = rng.choice(len(self._items), size=n, replace=False, p=p)
        return [items[int(i)] for i in idx]

    def state_dict(self) -> dict[str, Any]:
        return {"capacity": self.capacity, "items": [x.to_dict() for x in self._items]}

    def load_state_dict(self, state: dict[str, Any], *, obs_dim: int, action_dim: int) -> None:
        if int(state["capacity"]) != self.capacity:
            raise ValueError("replay capacity mismatch")
        items = [ReplayItem.from_dict(x) for x in state["items"]]
        if len(items) > self.capacity:
            raise ValueError("stored replay exceeds capacity")
        for item in items:
            item.validate(obs_dim, action_dim)
        self._items.clear()
        self._items.extend(items)


class PSLSTMNetwork(nn.Module):
    """Two-layer recurrent h-value network with an explicit action input."""

    def __init__(self, config: PSLSTMConfig):
        super().__init__()
        self.config = config
        self.input_size = config.obs_dim + config.action_dim
        self.lstm = nn.LSTM(
            input_size=self.input_size,
            hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            batch_first=True,
        )
        self.readout = nn.Linear(config.hidden_size, 1)

        # Standard projective simulation starts with h(s,a)=1.  Zeroing the
        # readout weights and setting bias=1 yields an exactly uniform initial
        # policy while leaving recurrent candidate states action-dependent.
        nn.init.zeros_(self.readout.weight)
        nn.init.ones_(self.readout.bias)

    def zero_state(self, batch_size: int, device: torch.device) -> tuple[Tensor, Tensor]:
        shape = (self.config.num_layers, batch_size, self.config.hidden_size)
        return (
            torch.zeros(shape, dtype=torch.float32, device=device),
            torch.zeros(shape, dtype=torch.float32, device=device),
        )

    def forward(
        self,
        x: Tensor,
        state: tuple[Tensor, Tensor] | None = None,
    ) -> tuple[Tensor, tuple[Tensor, Tensor]]:
        out, next_state = self.lstm(x, state)
        h = self.readout(out).squeeze(-1)
        return h, next_state


@dataclass(frozen=True)
class ActionEvaluation:
    h_values: tuple[float, ...]
    probabilities: tuple[float, ...]
    beta: float


class CorrectedPSLSTMAgent:
    """Corrected deep projective-simulation LSTM agent."""

    format_version = 1

    def __init__(self, config: PSLSTMConfig = PSLSTMConfig()):
        config.validate()
        self.config = config
        self.device = torch.device(config.device)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA device requested but CUDA is unavailable")

        # Seed model initialization without perturbing the caller's global RNG.
        devices: list[int] = []
        if self.device.type == "cuda":
            devices = [self.device.index or 0]
        with torch.random.fork_rng(devices=devices):
            torch.manual_seed(config.seed)
            self.network = PSLSTMNetwork(config).to(self.device)
        self.target_network = copy.deepcopy(self.network).to(self.device)
        self.target_network.eval()
        for p in self.target_network.parameters():
            p.requires_grad_(False)

        self.optimizer = torch.optim.Adam(self.network.parameters(), lr=config.learning_rate)
        self.replay = ReplayBuffer(config.replay_capacity)
        self._np_rng = np.random.default_rng(config.seed + 1)
        self._torch_rng = torch.Generator(device="cpu")
        self._torch_rng.manual_seed(config.seed + 2)

        self.interactions = 0
        self.episodes = 0
        self.gradient_updates = 0
        self.target_syncs = 0
        self.successful_episodes = 0
        self.last_train_loss: float | None = None

        self._hidden = self.network.zero_state(1, self.device)
        self._pending_observations: list[RealVector] = []
        self._pending_actions: list[int] = []
        self._pending_rewards: list[float] = []

    @property
    def beta(self) -> float:
        frac = min(max(self.episodes / self.config.beta_anneal_episodes, 0.0), 1.0)
        return float(self.config.beta_start + frac * (self.config.beta_end - self.config.beta_start))

    def reset_recurrent_state(self, *, clear_pending: bool = True) -> None:
        self._hidden = self.network.zero_state(1, self.device)
        if clear_pending:
            self._pending_observations.clear()
            self._pending_actions.clear()
            self._pending_rewards.clear()

    def _validate_observation(self, observation: ArrayLike) -> RealVector:
        obs = np.asarray(observation, dtype=np.float64)
        if obs.shape != (self.config.obs_dim,) or not np.all(np.isfinite(obs)):
            raise ValueError(f"observation must have shape {(self.config.obs_dim,)} and be finite")
        return obs

    def _candidate_scores_and_states(
        self, observation: ArrayLike
    ) -> tuple[Tensor, tuple[Tensor, Tensor]]:
        obs = self._validate_observation(observation)
        A = self.config.action_dim
        obs_t = torch.tensor(obs, dtype=torch.float32, device=self.device).view(1, 1, -1).repeat(A, 1, 1)
        act_t = torch.eye(A, dtype=torch.float32, device=self.device).view(A, 1, A)
        x = torch.cat([obs_t, act_t], dim=-1)
        h0, c0 = self._hidden
        state = (h0.repeat(1, A, 1), c0.repeat(1, A, 1))
        with torch.no_grad():
            scores, next_state = self.network(x, state)
        return scores[:, -1], next_state

    def evaluate_actions(self, observation: ArrayLike) -> ActionEvaluation:
        scores, _ = self._candidate_scores_and_states(observation)
        probs = torch.softmax(self.beta * scores, dim=0)
        return ActionEvaluation(
            h_values=tuple(float(v) for v in scores.detach().cpu().numpy()),
            probabilities=tuple(float(v) for v in probs.detach().cpu().numpy()),
            beta=self.beta,
        )

    def act(self, observation: ArrayLike, *, deterministic: bool = False) -> tuple[int, ActionEvaluation]:
        scores, next_state = self._candidate_scores_and_states(observation)
        probs = torch.softmax(self.beta * scores, dim=0)
        if deterministic:
            action = int(torch.argmax(probs).item())
        else:
            # Sampling on CPU with an agent-local generator gives exact resume
            # without consuming PyTorch's process-global RNG stream.
            action = int(torch.multinomial(probs.detach().cpu(), 1, generator=self._torch_rng).item())

        hn, cn = next_state
        self._hidden = (
            hn[:, action : action + 1, :].detach().clone(),
            cn[:, action : action + 1, :].detach().clone(),
        )
        ev = ActionEvaluation(
            h_values=tuple(float(v) for v in scores.detach().cpu().numpy()),
            probabilities=tuple(float(v) for v in probs.detach().cpu().numpy()),
            beta=self.beta,
        )
        return action, ev

    @staticmethod
    def glow_rewards(length: int, terminal_reward: float, eta_glow: float) -> RealVector:
        if length <= 0:
            raise ValueError("length must be positive")
        if not np.isfinite(terminal_reward):
            raise ValueError("terminal_reward must be finite")
        if not (0.0 <= eta_glow <= 1.0):
            raise ValueError("eta_glow must be in [0,1]")
        powers = np.arange(length - 1, -1, -1, dtype=np.float64)
        return float(terminal_reward) * np.power(1.0 - eta_glow, powers)

    @staticmethod
    def fitted_ps_target(old_h: Tensor, glow_reward: Tensor, gamma_damping: float) -> Tensor:
        return old_h - gamma_damping * (old_h - 1.0) + glow_reward

    def _commit_episode_to_replay(self, success: bool, terminal_reward: float) -> int:
        T = len(self._pending_actions)
        if T == 0:
            return 0
        if self.config.store_successes_only and not success:
            return 0
        glow = self.glow_rewards(T, terminal_reward, self.config.eta_glow)
        items: list[ReplayItem] = []
        for t in range(T):
            item = ReplayItem(
                observations=tuple(tuple(float(v) for v in x) for x in self._pending_observations[: t + 1]),
                actions=tuple(int(a) for a in self._pending_actions[: t + 1]),
                glow_reward=float(glow[t]),
                sampling_priority=float(max(terminal_reward, 0.0)),
            )
            item.validate(self.config.obs_dim, self.config.action_dim)
            items.append(item)
        self.replay.extend(items)
        return len(items)

    def sync_target(self) -> None:
        self.target_network.load_state_dict(self.network.state_dict())
        self.target_syncs += 1

    def observe(
        self,
        observation: ArrayLike,
        action: int,
        reward: float,
        *,
        terminated: bool,
        truncated: bool,
        success: bool,
        auxiliary_terminal_reward: float | None = None,
    ) -> dict[str, Any]:
        obs = self._validate_observation(observation)
        if not isinstance(action, (int, np.integer)) or not (0 <= int(action) < self.config.action_dim):
            raise ValueError("invalid action")
        if not np.isfinite(reward):
            raise ValueError("reward must be finite")
        if terminated and truncated:
            raise ValueError("an interaction cannot be both terminated and truncated")
        done = bool(terminated or truncated)
        if success and not done:
            raise ValueError("success must coincide with an episode end")
        if auxiliary_terminal_reward is not None:
            if not done:
                raise ValueError("auxiliary terminal reward may only be supplied at episode end")
            if not np.isfinite(auxiliary_terminal_reward) or auxiliary_terminal_reward < 0:
                raise ValueError("auxiliary terminal reward must be finite and non-negative")

        self._pending_observations.append(obs.copy())
        self._pending_actions.append(int(action))
        self._pending_rewards.append(float(reward))
        self.interactions += 1

        target_synced = False
        if self.interactions % self.config.target_update_interactions == 0:
            self.sync_target()
            target_synced = True

        replay_added = 0
        immediate_success_train = False
        if done:
            use_auxiliary = bool((not success) and (auxiliary_terminal_reward is not None))
            terminal_reward = float(auxiliary_terminal_reward if use_auxiliary else reward)
            replay_added = self._commit_episode_to_replay(success or use_auxiliary, terminal_reward)
            self.episodes += 1
            if success:
                self.successful_episodes += 1
            # An auxiliary terminal-credit trajectory is deliberately trainable
            # immediately, just like a curriculum-success trajectory.  This
            # affects learner credit only; environment reward/success is unchanged.
            immediate_success_train = bool(success or use_auxiliary)

        periodic_train = self.interactions % self.config.train_every_interactions == 0
        trained = False
        loss = None
        if (immediate_success_train or periodic_train) and len(self.replay) >= self.config.min_replay_size:
            loss = self.train_step()
            trained = True
            if not done:
                self._recompute_hidden_from_pending()

        if done:
            self.reset_recurrent_state(clear_pending=True)

        return {
            "interactions": self.interactions,
            "episodes": self.episodes,
            "beta": self.beta,
            "replay_size": len(self.replay),
            "replay_added": replay_added,
            "target_synced": target_synced,
            "trained": trained,
            "train_loss": loss,
            "auxiliary_terminal_reward": None if auxiliary_terminal_reward is None else float(auxiliary_terminal_reward),
        }

    def _encode_batch(self, items: Sequence[ReplayItem]) -> tuple[Tensor, Tensor, Tensor]:
        B = len(items)
        if B == 0:
            raise ValueError("empty batch")
        lengths = torch.tensor([len(x.actions) for x in items], dtype=torch.int64, device="cpu")
        T = int(lengths.max().item())
        D = self.config.obs_dim + self.config.action_dim
        x = torch.zeros((B, T, D), dtype=torch.float32, device=self.device)
        y = torch.tensor([x_.glow_reward for x_ in items], dtype=torch.float32, device=self.device)
        for b, item in enumerate(items):
            item.validate(self.config.obs_dim, self.config.action_dim)
            for t, (obs, action) in enumerate(zip(item.observations, item.actions)):
                x[b, t, : self.config.obs_dim] = torch.tensor(obs, dtype=torch.float32, device=self.device)
                x[b, t, self.config.obs_dim + action] = 1.0
        return x, lengths, y

    @staticmethod
    def _last_valid(values: Tensor, lengths_cpu: Tensor) -> Tensor:
        # values: [B,T].  Index tensor must live on the same device.
        idx = (lengths_cpu - 1).to(values.device)
        return values[torch.arange(values.shape[0], device=values.device), idx]

    def _recompute_hidden_from_pending(self) -> None:
        """Rebuild online recurrent state after a mid-episode weight update.

        The paper-style periodic learner update is interaction-count based and can
        therefore occur before an episode ends.  If network weights change while
        the old hidden state is retained, the next policy decision mixes hidden
        features produced by stale weights with the updated network.  Replaying
        the already-chosen prefix restores a self-consistent recurrent state.
        """
        if not self._pending_actions:
            self._hidden = self.network.zero_state(1, self.device)
            return
        state = self.network.zero_state(1, self.device)
        with torch.no_grad():
            for obs, action in zip(self._pending_observations, self._pending_actions):
                obs_t = torch.tensor(obs, dtype=torch.float32, device=self.device).view(1, 1, -1)
                act_t = torch.zeros((1, 1, self.config.action_dim), dtype=torch.float32, device=self.device)
                act_t[0, 0, int(action)] = 1.0
                x = torch.cat([obs_t, act_t], dim=-1)
                _, state = self.network(x, state)
        self._hidden = (state[0].detach().clone(), state[1].detach().clone())

    def train_step(self) -> float:
        if len(self.replay) < self.config.min_replay_size:
            raise RuntimeError("not enough replay to train")
        n = min(self.config.batch_size, len(self.replay))
        items = self.replay.sample(n, self._np_rng, mode=self.config.replay_sampling, alpha=self.config.replay_priority_alpha, epsilon=self.config.replay_priority_epsilon)
        x, lengths, glow = self._encode_batch(items)

        # Sequences are short (<= max circuit length), so explicit masking is
        # simpler and deterministic. Padding is ignored by gathering each
        # sequence's final valid output.
        pred_seq, _ = self.network(x)
        pred = self._last_valid(pred_seq, lengths)
        with torch.no_grad():
            old_seq, _ = self.target_network(x)
            old = self._last_valid(old_seq, lengths)
            target = self.fitted_ps_target(old, glow, self.config.gamma_damping)

        loss = torch.mean((pred - target) ** 2)
        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        if self.config.gradient_clip_norm is not None:
            nn.utils.clip_grad_norm_(self.network.parameters(), self.config.gradient_clip_norm)
        self.optimizer.step()
        self.gradient_updates += 1
        self.last_train_loss = float(loss.detach().cpu().item())
        return self.last_train_loss

    def hidden_state_numpy(self) -> tuple[RealVector, RealVector]:
        h, c = self._hidden
        return (
            h.detach().cpu().numpy().astype(np.float64, copy=True),
            c.detach().cpu().numpy().astype(np.float64, copy=True),
        )

    def state_dict(self) -> dict[str, Any]:
        h, c = self._hidden
        return {
            "format_version": self.format_version,
            "config": asdict(self.config),
            "network": copy.deepcopy(self.network.state_dict()),
            "target_network": copy.deepcopy(self.target_network.state_dict()),
            "optimizer": copy.deepcopy(self.optimizer.state_dict()),
            "replay": self.replay.state_dict(),
            "np_rng_state": copy.deepcopy(self._np_rng.bit_generator.state),
            "torch_rng_state": self._torch_rng.get_state().clone(),
            "interactions": self.interactions,
            "episodes": self.episodes,
            "gradient_updates": self.gradient_updates,
            "target_syncs": self.target_syncs,
            "successful_episodes": self.successful_episodes,
            "last_train_loss": self.last_train_loss,
            "hidden_h": h.detach().cpu().clone(),
            "hidden_c": c.detach().cpu().clone(),
            "pending_observations": [x.tolist() for x in self._pending_observations],
            "pending_actions": list(self._pending_actions),
            "pending_rewards": list(self._pending_rewards),
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        if int(state["format_version"]) != self.format_version:
            raise ValueError("unsupported learner state format")
        if state["config"] != asdict(self.config):
            raise ValueError("PS-LSTM config mismatch")
        self.network.load_state_dict(state["network"])
        self.target_network.load_state_dict(state["target_network"])
        self.optimizer.load_state_dict(state["optimizer"])
        self.replay.load_state_dict(
            state["replay"], obs_dim=self.config.obs_dim, action_dim=self.config.action_dim
        )
        self._np_rng = np.random.default_rng()
        self._np_rng.bit_generator.state = copy.deepcopy(state["np_rng_state"])
        self._torch_rng.set_state(state["torch_rng_state"].cpu())
        self.interactions = int(state["interactions"])
        self.episodes = int(state["episodes"])
        self.gradient_updates = int(state["gradient_updates"])
        self.target_syncs = int(state["target_syncs"])
        self.successful_episodes = int(state["successful_episodes"])
        self.last_train_loss = None if state["last_train_loss"] is None else float(state["last_train_loss"])
        self._hidden = (
            state["hidden_h"].to(self.device).clone(),
            state["hidden_c"].to(self.device).clone(),
        )
        self._pending_observations = [np.asarray(x, dtype=np.float64) for x in state["pending_observations"]]
        self._pending_actions = [int(x) for x in state["pending_actions"]]
        self._pending_rewards = [float(x) for x in state["pending_rewards"]]
        if not (
            len(self._pending_observations)
            == len(self._pending_actions)
            == len(self._pending_rewards)
        ):
            raise ValueError("corrupt pending episode state")

    def save_checkpoint(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(self.state_dict(), path)

    def load_checkpoint(self, path: str | Path) -> None:
        # Checkpoints are pickle-backed. Load only files produced/trusted by this
        # project. `weights_only=False` is required because exact resume contains
        # optimizer/replay/RNG Python containers in addition to tensor weights.
        state = torch.load(Path(path), map_location=self.device, weights_only=False)
        self.load_state_dict(state)
