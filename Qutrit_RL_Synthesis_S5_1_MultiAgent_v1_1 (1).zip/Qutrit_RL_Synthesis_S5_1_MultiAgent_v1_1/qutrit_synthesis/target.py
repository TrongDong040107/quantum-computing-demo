"""Parameterized target family U_target(xi) = exp[-i xi (lambda3 tensor lambda3)]."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

ComplexMatrix = NDArray[np.complex128]

LAMBDA3: ComplexMatrix = np.diag([1.0, -1.0, 0.0]).astype(np.complex128)
H_TARGET: ComplexMatrix = np.kron(LAMBDA3, LAMBDA3)
_TARGET_EIGENVALUES = np.diag(H_TARGET).real.copy()


def target_unitary(xi: float) -> ComplexMatrix:
    """Return the exact 9x9 target unitary without a matrix exponential."""
    if not np.isfinite(xi):
        raise ValueError("xi must be finite")
    return np.diag(np.exp(-1j * float(xi) * _TARGET_EIGENVALUES)).astype(np.complex128)
