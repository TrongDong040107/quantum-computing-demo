"""Episode-transaction state machine for the frozen S5 training candidate."""
from __future__ import annotations

import copy
import hashlib
import time
from pathlib import Path
from typing import Any

import numpy as np

from .campaign import KNOWN_EXACT_ACTIONS, ORACLE_ACTIONS
from .final_training import PROBE_INTERVAL_EPISODES, agent_for, environment_for, protocol_sha256, terminal_credit
from .policy_probe import probe_agent_state
from .trainer import run_episode

FORMAT_VERSION = 1
ARMS = ("terminal_priority", "uniform", "random")


def core_python_tree_sha256(root: Path) -> str:
    h = hashlib.sha256()
    for p in sorted((root / "qutrit_synthesis").rglob("*.py")):
        h.update(p.relative_to(root).as_posix().encode() + b"\0")
        h.update(hashlib.sha256(p.read_bytes()).digest())
    return h.hexdigest()


def _empty_stats() -> dict[str, Any]:
    return {
        "episodes_completed": 0,
        "interactions": 0,
        "final_success_episodes": 0,
        "first_final_success_episode": None,
        "best_objective": float("inf"),
        "best_worst_test_infidelity": None,
        "shortest_final_success_length": None,
        "oracle_exact_hits": 0,
        "known_exact_hits": 0,
        "best_actions": [],
        "best_action_kinds": [],
        "auxiliary_credit_episodes": 0,
        "action_counts": [0, 0, 0, 0],
        "episode_records": [],
        "probe_history": [],
    }


def initialize_state(root: Path, *, arm: str, seed: int, episodes_total: int) -> dict[str, Any]:
    if arm not in ARMS:
        raise ValueError(f"arm must be one of {ARMS}")
    if episodes_total <= 0:
        raise ValueError("episodes_total must be positive")
    env = environment_for(seed)
    state: dict[str, Any] = {
        "format_version": FORMAT_VERSION,
        "arm": arm,
        "seed": int(seed),
        "episodes_total": int(episodes_total),
        "next_episode": 0,
        "protocol_sha256": protocol_sha256(),
        "core_python_tree_sha256": core_python_tree_sha256(root),
        "env_state": env.state_dict(),
        "agent_state": None,
        "random_rng_state": None,
        "stats": _empty_stats(),
        "execution_audit": {
            "successful_episode_wall_seconds": 0.0,
            "watchdog_timeouts": 0,
            "worker_failures": 0,
            "retries": 0,
        },
    }
    if arm in ("terminal_priority", "uniform"):
        state["agent_state"] = agent_for(seed, replay_sampling=arm).state_dict()
    else:
        rng = np.random.default_rng(seed)
        state["random_rng_state"] = copy.deepcopy(rng.bit_generator.state)
    return state


def validate_state(root: Path, state: dict[str, Any]) -> None:
    if int(state["format_version"]) != FORMAT_VERSION:
        raise ValueError("unsupported checkpoint format")
    if state["arm"] not in ARMS:
        raise ValueError("invalid arm")
    if state["protocol_sha256"] != protocol_sha256():
        raise ValueError("protocol hash mismatch")
    if state["core_python_tree_sha256"] != core_python_tree_sha256(root):
        raise ValueError("scientific Python tree hash mismatch")
    if not (0 <= int(state["next_episode"]) <= int(state["episodes_total"])):
        raise ValueError("invalid next_episode")


def _update_stats(stats: dict[str, Any], rec: dict[str, Any]) -> None:
    ep = int(rec["episode"])
    actions = tuple(int(a) for a in rec["actions"])
    for a in actions:
        stats["action_counts"][a] += 1
    stats["interactions"] += len(actions)
    if actions == ORACLE_ACTIONS:
        stats["oracle_exact_hits"] += 1
    if actions in KNOWN_EXACT_ACTIONS:
        stats["known_exact_hits"] += 1
    objective = float(rec["objective"])
    if objective < float(stats["best_objective"]):
        stats["best_objective"] = objective
        stats["best_worst_test_infidelity"] = rec["worst_test_infidelity"]
        stats["best_actions"] = list(actions)
        stats["best_action_kinds"] = list(rec["action_kinds"])
    if bool(rec["final_success"]):
        stats["final_success_episodes"] += 1
        if stats["first_final_success_episode"] is None:
            stats["first_final_success_episode"] = ep
        L = len(actions)
        old = stats["shortest_final_success_length"]
        stats["shortest_final_success_length"] = L if old is None else min(int(old), L)
    aux = rec.get("auxiliary_terminal_credit")
    if aux is not None and float(aux) > 0:
        stats["auxiliary_credit_episodes"] += 1
    stats["episodes_completed"] += 1
    stats["episode_records"].append({
        "episode": ep,
        "actions": list(actions),
        "objective": objective,
        "worst_test_infidelity": rec["worst_test_infidelity"],
        "final_success": bool(rec["final_success"]),
        "auxiliary_terminal_credit": aux,
    })


def execute_one_episode(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    validate_state(root, state)
    ep = int(state["next_episode"])
    if ep >= int(state["episodes_total"]):
        return state
    seed = int(state["seed"])
    episode_seed = seed * 100_000 + ep + 1
    env = environment_for(seed)
    env.load_state_dict(state["env_state"])
    t0 = time.perf_counter()

    new_state = copy.deepcopy(state)
    if state["arm"] in ("terminal_priority", "uniform"):
        agent = agent_for(seed, replay_sampling=state["arm"])
        agent.load_state_dict(state["agent_state"])
        out = run_episode(env, agent, seed=episode_seed, terminal_credit=terminal_credit())
        rec = {
            "episode": ep,
            "actions": list(out.actions),
            "action_kinds": list(out.action_kinds),
            "objective": float(out.final_objective),
            "worst_test_infidelity": out.final_worst_test_infidelity,
            "final_success": bool(out.final_success),
            "auxiliary_terminal_credit": out.auxiliary_terminal_credit,
        }
        new_state["agent_state"] = agent.state_dict()
    else:
        rng = np.random.default_rng()
        rng.bit_generator.state = copy.deepcopy(state["random_rng_state"])
        env.reset(seed=episode_seed)
        actions, kinds = [], []
        terminated = truncated = False
        info = None
        while not (terminated or truncated):
            action = int(rng.integers(env.action_space_n))
            _, _, terminated, truncated, info = env.step(action)
            actions.append(action)
            kinds.append(str(info["action_kind"]))
        assert info is not None
        tm = info.get("test_metrics")
        rec = {
            "episode": ep,
            "actions": actions,
            "action_kinds": kinds,
            "objective": float(info["objective"]),
            "worst_test_infidelity": None if tm is None else float(tm["worst_infidelity"]),
            "final_success": bool(info["final_success"]),
            "auxiliary_terminal_credit": None,
        }
        new_state["random_rng_state"] = copy.deepcopy(rng.bit_generator.state)

    new_state["env_state"] = env.state_dict()
    _update_stats(new_state["stats"], rec)
    new_state["next_episode"] = ep + 1
    new_state["execution_audit"]["successful_episode_wall_seconds"] += float(time.perf_counter() - t0)

    if new_state["agent_state"] is not None and new_state["next_episode"] % PROBE_INTERVAL_EPISODES == 0:
        probe = probe_agent_state(new_state["agent_state"])
        probe["episode"] = int(new_state["next_episode"])
        new_state["stats"]["probe_history"].append(probe)
    return new_state


def scientific_result(state: dict[str, Any]) -> dict[str, Any]:
    s = state["stats"]
    out: dict[str, Any] = {
        "arm": state["arm"],
        "seed": int(state["seed"]),
        "episodes": int(state["episodes_total"]),
        "episodes_completed": int(s["episodes_completed"]),
        "interactions": int(s["interactions"]),
        "final_success_episodes": int(s["final_success_episodes"]),
        "first_final_success_episode": s["first_final_success_episode"],
        "best_objective": float(s["best_objective"]),
        "best_worst_test_infidelity": s["best_worst_test_infidelity"],
        "shortest_final_success_length": s["shortest_final_success_length"],
        "oracle_exact_hits": int(s["oracle_exact_hits"]),
        "known_exact_hits": int(s["known_exact_hits"]),
        "best_actions": list(s["best_actions"]),
        "best_action_kinds": list(s["best_action_kinds"]),
        "final_curriculum_threshold": float(state["env_state"]["curriculum_state"]["threshold"]),
        "action_counts": list(s["action_counts"]),
        "probe_history": copy.deepcopy(s["probe_history"]),
    }
    if state["agent_state"] is not None:
        a = state["agent_state"]
        out.update({
            "replay_size": len(a["replay"]["items"]),
            "gradient_updates": int(a["gradient_updates"]),
            "target_syncs": int(a["target_syncs"]),
            "successful_curriculum_episodes": int(a["successful_episodes"]),
            "auxiliary_credit_episodes": int(s["auxiliary_credit_episodes"]),
            "final_policy_probe": probe_agent_state(a),
        })
    else:
        out.update({
            "replay_size": None,
            "gradient_updates": None,
            "target_syncs": None,
            "successful_curriculum_episodes": None,
            "auxiliary_credit_episodes": None,
            "final_policy_probe": None,
        })
    return out
