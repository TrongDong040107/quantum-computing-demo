"""Training-loop glue between CorrectedPSLSTMAgent and QutritSynthesisEnv."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .environment import QutritSynthesisEnv
from .ps_lstm import CorrectedPSLSTMAgent
from .terminal_credit import TerminalCreditConfig, terminal_objective_credit


@dataclass(frozen=True)
class EpisodeResult:
    episode_index: int
    episode_seed: int
    actions: tuple[int, ...]
    action_kinds: tuple[str, ...]
    rewards: tuple[float, ...]
    final_objective: float
    final_worst_test_infidelity: float | None
    terminated: bool
    truncated: bool
    final_success: bool
    replay_size: int
    gradient_updates: int
    auxiliary_terminal_credit: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "episode_index": self.episode_index,
            "episode_seed": self.episode_seed,
            "actions": list(self.actions),
            "action_kinds": list(self.action_kinds),
            "rewards": list(self.rewards),
            "final_objective": self.final_objective,
            "final_worst_test_infidelity": self.final_worst_test_infidelity,
            "terminated": self.terminated,
            "truncated": self.truncated,
            "final_success": self.final_success,
            "replay_size": self.replay_size,
            "gradient_updates": self.gradient_updates,
            "auxiliary_terminal_credit": self.auxiliary_terminal_credit,
        }


def run_episode(
    env: QutritSynthesisEnv,
    agent: CorrectedPSLSTMAgent,
    *,
    seed: int,
    deterministic_policy: bool = False,
    terminal_credit: TerminalCreditConfig | None = None,
) -> EpisodeResult:
    if env.config.observation_mode != "last_action":
        raise ValueError("Corrected PS-LSTM baseline expects last_action observations")
    if env.action_space_n != agent.config.action_dim:
        raise ValueError("environment/agent action dimension mismatch")
    if env.observation_shape != (agent.config.obs_dim,):
        raise ValueError("environment/agent observation dimension mismatch")

    obs, reset_info = env.reset(seed=seed)
    agent.reset_recurrent_state(clear_pending=True)
    actions: list[int] = []
    kinds: list[str] = []
    rewards: list[float] = []
    final_info: dict[str, Any] | None = None
    final_auxiliary_credit: float | None = None
    terminated = truncated = False

    while not (terminated or truncated):
        obs_before = np.asarray(obs, dtype=np.float64).copy()
        action, _ = agent.act(obs_before, deterministic=deterministic_policy)
        obs, reward, terminated, truncated, info = env.step(action)
        success = bool((terminated or truncated) and info["success"])
        auxiliary_credit = None
        if (terminated or truncated) and (not success) and terminal_credit is not None and terminal_credit.enabled:
            auxiliary_credit = terminal_objective_credit(float(info["objective"]), terminal_credit)
            final_auxiliary_credit = float(auxiliary_credit)
        agent.observe(
            obs_before,
            action,
            reward,
            terminated=terminated,
            truncated=truncated,
            success=success,
            auxiliary_terminal_reward=auxiliary_credit,
        )
        actions.append(action)
        kinds.append(str(info["action_kind"]))
        rewards.append(float(reward))
        final_info = info

    assert final_info is not None
    test_metrics = final_info.get("test_metrics")
    worst_test = None if test_metrics is None else float(test_metrics["worst_infidelity"])
    return EpisodeResult(
        episode_index=int(reset_info["episode_index"]),
        episode_seed=int(reset_info["episode_seed"]),
        actions=tuple(actions),
        action_kinds=tuple(kinds),
        rewards=tuple(rewards),
        final_objective=float(final_info["objective"]),
        final_worst_test_infidelity=worst_test,
        terminated=bool(terminated),
        truncated=bool(truncated),
        final_success=bool(final_info["final_success"]),
        replay_size=len(agent.replay),
        gradient_updates=agent.gradient_updates,
        auxiliary_terminal_credit=final_auxiliary_credit,
    )
