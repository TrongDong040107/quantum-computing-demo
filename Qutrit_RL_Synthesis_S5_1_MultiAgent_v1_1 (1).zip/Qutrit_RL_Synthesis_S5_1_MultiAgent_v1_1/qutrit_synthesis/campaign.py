"""Controlled S4 pilot utilities for PS-LSTM vs matched uniform random search.

The pilot deliberately keeps the same qutrit environment, continuous optimizer,
training/test xi grids, curriculum and episode budget for both policies.  It is
an engineering/scientific pilot, not the final paper-scale campaign.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal
import time

import numpy as np

from .environment import QutritSynthesisEnv
from .ps_lstm import CorrectedPSLSTMAgent
from .trainer import run_episode
from .terminal_credit import TerminalCreditConfig

PolicyName = Literal["ps_lstm", "ps_lstm_toc", "random"]
ORACLE_ACTIONS = (3, 1, 3, 1, 3)  # canonical cx_dg oracle
DUAL_ORACLE_ACTIONS = (2, 1, 2, 1, 2)  # S4.2-discovered exact cx oracle
KNOWN_EXACT_ACTIONS = (ORACLE_ACTIONS, DUAL_ORACLE_ACTIONS)


@dataclass(frozen=True)
class PilotRunResult:
    policy: PolicyName
    seed: int
    episodes: int
    interactions: int
    final_success_episodes: int
    first_final_success_episode: int | None
    best_objective: float
    best_worst_test_infidelity: float | None
    shortest_final_success_length: int | None
    oracle_exact_hits: int
    known_exact_hits: int
    best_actions: tuple[int, ...]
    best_action_kinds: tuple[str, ...]
    final_curriculum_threshold: float
    wall_seconds: float
    replay_size: int | None = None
    gradient_updates: int | None = None
    target_syncs: int | None = None
    successful_curriculum_episodes: int | None = None
    auxiliary_credit_episodes: int | None = None
    action_counts: tuple[int, ...] = (0, 0, 0, 0)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["best_actions"] = list(self.best_actions)
        d["best_action_kinds"] = list(self.best_action_kinds)
        d["action_counts"] = list(self.action_counts)
        return d


def _run_random_episode(env: QutritSynthesisEnv, rng: np.random.Generator, *, seed: int) -> dict[str, Any]:
    _, reset_info = env.reset(seed=seed)
    actions: list[int] = []
    kinds: list[str] = []
    terminated = truncated = False
    final_info: dict[str, Any] | None = None
    while not (terminated or truncated):
        action = int(rng.integers(env.action_space_n))
        _, _, terminated, truncated, info = env.step(action)
        actions.append(action)
        kinds.append(str(info["action_kind"]))
        final_info = info
    assert final_info is not None
    tm = final_info.get("test_metrics")
    return {
        "episode_index": int(reset_info["episode_index"]),
        "actions": tuple(actions),
        "action_kinds": tuple(kinds),
        "objective": float(final_info["objective"]),
        "worst_test_infidelity": None if tm is None else float(tm["worst_infidelity"]),
        "final_success": bool(final_info["final_success"]),
    }


def run_random_pilot(env: QutritSynthesisEnv, *, seed: int, episodes: int) -> PilotRunResult:
    if episodes <= 0:
        raise ValueError("episodes must be positive")
    rng = np.random.default_rng(seed)
    start = time.perf_counter()
    best = np.inf
    best_worst = None
    best_actions: tuple[int, ...] = ()
    best_kinds: tuple[str, ...] = ()
    final_successes = 0
    first_success = None
    shortest = None
    oracle_hits = 0
    known_exact_hits = 0
    counts = np.zeros(env.action_space_n, dtype=int)
    interactions = 0
    for ep in range(episodes):
        rec = _run_random_episode(env, rng, seed=seed * 100_000 + ep + 1)
        for a in rec["actions"]:
            counts[a] += 1
        interactions += len(rec["actions"])
        if rec["actions"] == ORACLE_ACTIONS:
            oracle_hits += 1
        if rec["actions"] in KNOWN_EXACT_ACTIONS:
            known_exact_hits += 1
        if rec["objective"] < best:
            best = rec["objective"]
            best_worst = rec["worst_test_infidelity"]
            best_actions = rec["actions"]
            best_kinds = rec["action_kinds"]
        if rec["final_success"]:
            final_successes += 1
            if first_success is None:
                first_success = ep
            L = len(rec["actions"])
            shortest = L if shortest is None else min(shortest, L)
    return PilotRunResult(
        policy="random", seed=seed, episodes=episodes, interactions=interactions,
        final_success_episodes=final_successes, first_final_success_episode=first_success,
        best_objective=float(best), best_worst_test_infidelity=best_worst,
        shortest_final_success_length=shortest, oracle_exact_hits=oracle_hits, known_exact_hits=known_exact_hits,
        best_actions=best_actions, best_action_kinds=best_kinds,
        final_curriculum_threshold=float(env.curriculum.threshold),
        wall_seconds=float(time.perf_counter()-start), action_counts=tuple(int(x) for x in counts),
    )


def run_ps_lstm_pilot(
    env: QutritSynthesisEnv,
    agent: CorrectedPSLSTMAgent,
    *, seed: int, episodes: int, terminal_credit: TerminalCreditConfig | None = None,
) -> PilotRunResult:
    if episodes <= 0:
        raise ValueError("episodes must be positive")
    start = time.perf_counter()
    best = np.inf
    best_worst = None
    best_actions: tuple[int, ...] = ()
    best_kinds: tuple[str, ...] = ()
    final_successes = 0
    first_success = None
    shortest = None
    oracle_hits = 0
    known_exact_hits = 0
    counts = np.zeros(env.action_space_n, dtype=int)
    interactions0 = agent.interactions
    auxiliary_credit_episodes = 0
    for ep in range(episodes):
        rec = run_episode(env, agent, seed=seed * 100_000 + ep + 1, terminal_credit=terminal_credit)
        if rec.auxiliary_terminal_credit is not None and rec.auxiliary_terminal_credit > 0:
            auxiliary_credit_episodes += 1
        for a in rec.actions:
            counts[a] += 1
        if rec.actions == ORACLE_ACTIONS:
            oracle_hits += 1
        if rec.actions in KNOWN_EXACT_ACTIONS:
            known_exact_hits += 1
        if rec.final_objective < best:
            best = rec.final_objective
            best_worst = rec.final_worst_test_infidelity
            best_actions = rec.actions
            best_kinds = rec.action_kinds
        if rec.final_success:
            final_successes += 1
            if first_success is None:
                first_success = ep
            L = len(rec.actions)
            shortest = L if shortest is None else min(shortest, L)
    return PilotRunResult(
        policy=("ps_lstm_toc" if terminal_credit is not None and terminal_credit.enabled else "ps_lstm"), seed=seed, episodes=episodes,
        interactions=agent.interactions-interactions0,
        final_success_episodes=final_successes, first_final_success_episode=first_success,
        best_objective=float(best), best_worst_test_infidelity=best_worst,
        shortest_final_success_length=shortest, oracle_exact_hits=oracle_hits, known_exact_hits=known_exact_hits,
        best_actions=best_actions, best_action_kinds=best_kinds,
        final_curriculum_threshold=float(env.curriculum.threshold),
        wall_seconds=float(time.perf_counter()-start), replay_size=len(agent.replay),
        gradient_updates=agent.gradient_updates, target_syncs=agent.target_syncs,
        successful_curriculum_episodes=agent.successful_episodes,
        auxiliary_credit_episodes=auxiliary_credit_episodes,
        action_counts=tuple(int(x) for x in counts),
    )


def aggregate_runs(runs: list[PilotRunResult]) -> dict[str, Any]:
    if not runs:
        raise ValueError("runs must be non-empty")
    policies = {r.policy for r in runs}
    if len(policies) != 1:
        raise ValueError("aggregate_runs expects one policy")
    best = np.asarray([r.best_objective for r in runs], dtype=float)
    hit = np.asarray([r.final_success_episodes > 0 for r in runs], dtype=float)
    interactions = np.asarray([r.interactions for r in runs], dtype=float)
    wall = np.asarray([r.wall_seconds for r in runs], dtype=float)
    return {
        "policy": runs[0].policy,
        "n_seeds": len(runs),
        "seed_final_success_rate": float(hit.mean()),
        "total_final_success_episodes": int(sum(r.final_success_episodes for r in runs)),
        "total_oracle_exact_hits": int(sum(r.oracle_exact_hits for r in runs)),
        "total_known_exact_hits": int(sum(r.known_exact_hits for r in runs)),
        "best_objective_min": float(best.min()),
        "best_objective_median": float(np.median(best)),
        "best_objective_max": float(best.max()),
        "mean_interactions": float(interactions.mean()),
        "mean_wall_seconds": float(wall.mean()),
        "runs": [r.to_dict() for r in runs],
    }
