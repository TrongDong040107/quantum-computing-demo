"""Exact 5-operation oracle for exp[-i xi (lambda3 tensor lambda3)]."""

from __future__ import annotations

from .circuit import Operation, circuit_unitary


def oracle_operations() -> tuple[Operation, ...]:
    """Chronological sequence implementing target up to global phase.

    Final product:
        C^† [I⊗Ud(-xi,-xi)] C^† [I⊗Ud(-xi,0)] C^†
      = exp(-i xi) U_target(xi).
    """
    p_diff = (-1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    p_sum = (-1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    return (
        Operation.fixed("cx_dg"),
        Operation.local("u3_q1", p_diff),
        Operation.fixed("cx_dg"),
        Operation.local("u3_q1", p_sum),
        Operation.fixed("cx_dg"),
    )


def oracle_unitary(xi: float):
    return circuit_unitary(oracle_operations(), xi)


def dual_oracle_operations() -> tuple[Operation, ...]:
    """Second exact five-operation topology discovered by S4.2 search.

    Chronological sequence:
        C, I⊗Ud(-xi,-xi), C, I⊗Ud(-xi,0), C

    The resulting product is also ``exp(-i xi) U_target(xi)``.  This is a
    symmetry-related exact solution using CX instead of CX^†; it was not
    supplied to the structured search.
    """
    p_diff = (-1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    p_sum = (-1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    return (
        Operation.fixed("cx"),
        Operation.local("u3_q1", p_sum),
        Operation.fixed("cx"),
        Operation.local("u3_q1", p_diff),
        Operation.fixed("cx"),
    )


def dual_oracle_unitary(xi: float):
    return circuit_unitary(dual_oracle_operations(), xi)
