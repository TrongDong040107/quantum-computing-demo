# S5 full-training runbook

Use Python 3.10+ with NumPy, SciPy, PyTorch and pytest.  For deterministic CPU execution, cap BLAS/PyTorch workers to one thread per seed process.  The watchdog is an execution safeguard only; timed-out episodes are retried from the previous completed-episode checkpoint.

## Gate check

```bash
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
python -m pytest -q tests/test_s5_final_training.py tests/test_s5_final_runner.py
```

## One frozen seed

```bash
python tools/final_training_runner.py run \
  --root . \
  --checkpoint /kaggle/working/s5/terminal_priority/seed_2848563236/checkpoint.pt \
  --result-json /kaggle/working/s5/terminal_priority/seed_2848563236/result.json \
  --snapshots-dir /kaggle/working/s5/terminal_priority/seed_2848563236/snapshots \
  --arm terminal_priority \
  --seed 2848563236 \
  --episodes 300 \
  --thread-cap 1 \
  --inactivity-timeout-s 180 \
  --max-retries 3
```

Re-running exactly the same command resumes automatically.

## Recommended 4-shard campaign

Each arm has 32 seeds.  Run four independent jobs with seed-index shards 0-7, 8-15, 16-23 and 24-31.  Example:

```bash
python tools/run_s5_campaign.py --arm terminal_priority --output-root /kaggle/working/s5 --start-index 0  --count 8
python tools/run_s5_campaign.py --arm terminal_priority --output-root /kaggle/working/s5 --start-index 8  --count 8
python tools/run_s5_campaign.py --arm terminal_priority --output-root /kaggle/working/s5 --start-index 16 --count 8
python tools/run_s5_campaign.py --arm terminal_priority --output-root /kaggle/working/s5 --start-index 24 --count 8
```

Repeat with `--arm uniform` and, for the matched search baseline, `--arm random`.  The proposed learner arm can be run first, but the protocol identity already freezes all arms.

Do not edit `qutrit_synthesis/final_training.py` after starting the campaign.  The runner stores both the protocol hash and the scientific Python-tree hash in every checkpoint and refuses to resume on a mismatch.
