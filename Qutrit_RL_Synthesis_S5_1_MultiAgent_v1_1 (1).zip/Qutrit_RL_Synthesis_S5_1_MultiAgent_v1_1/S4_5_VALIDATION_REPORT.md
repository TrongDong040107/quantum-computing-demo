# S4.5 validation report

- `compileall`: PASS.
- New priority-replay + learner/TOC regression partition: 34 tests PASS.
- Physics/matrix/gradient/family/topology/oracle partition: 26 tests PASS.
- Critical environment oracle, environment exact-resume continuation, and L-BFGS-B exact-family recovery: 3 tests PASS.
- Six paired 120-episode uniform-vs-terminal-priority diagnostic runs completed successfully (12 runs total).
- Each completed learner contains 600 replay items and 119 gradient updates, confirming equal training cadence.
- No scientific p-value claim is made from this diagnostic.

## Fresh-extract release verification

A preverification ZIP was extracted into a new directory and verified independently:

- SHA256 tree: PASS.
- `compileall`: PASS.
- Fresh learner/replay/probe regression partition: 22 tests PASS.
- Fresh physics/gradient/family/oracle partition: 23 tests PASS.
- Fresh critical slow checks (oracle environment, exact environment continuation, exact-family L-BFGS-B recovery): 3 tests PASS.

No Python source file was modified after this fresh-extract verification.
