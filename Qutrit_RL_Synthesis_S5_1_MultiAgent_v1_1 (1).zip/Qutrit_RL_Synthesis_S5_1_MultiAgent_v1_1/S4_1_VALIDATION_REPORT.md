# S4.1 Validation Report — Objective & Credit Upgrade v0.6

## Decision

**S4.1 MECHANISM PASS — READY FOR S4.2 STRUCTURED SEARCH / LONGER CONTROLLED PILOT.**

This release is **not** evidence that PS-LSTM outperforms random search and is **not** a paper-scale convergence result.

## Scientific blocker A: sparse family support

S4 showed that three training values of the target parameter can severely understate error between sampled values. S4.1 therefore adds a deterministic robust objective

`C = (1-rho) mean(c_i) + rho tau log(mean(exp(c_i/tau)))`,

where `c_i=1-F_i`. The log-mean-exp term is a smooth approximation of the worst point and has an analytic gradient equal to a softmax-weighted combination of pointwise cost gradients.

For the S4.1 diagnostic, `rho=0.6`, `tau=0.08`, and 9 periodic train points are used.

On the fixed wrong topology

`CX† -> U3(q1) -> CX† -> U3(q1) -> U3(q1)`,

3-point mean optimization yielded:

- train mean infidelity: **0.3639129846**;
- dense held-out mean infidelity: **0.6816375411**;
- train/test mean gap: **+0.3177245565**;
- dense held-out worst infidelity: **0.9782288840**.

Nine-point robust optimization yielded:

- train mean infidelity: **0.6557069520**;
- dense held-out mean infidelity: **0.6515846984**;
- train/test mean gap: **-0.0041222536**;
- dense held-out worst infidelity: **0.8888888889**.

The important result is not that the wrong topology became accurate; it remained poor. The important result is that sparse-sample optimism largely disappeared in the mean metric.

## Oracle-preservation gate

The robust objective must not destroy the known exact family solution. Replaying

`CX† -> U3(q1) -> CX† -> U3(q1) -> CX†`

through the real sequential environment using only **4 L-BFGS-B iterations per step** produced at step 5:

- robust objective: **4.478457439e-4**;
- train mean infidelity: **4.472040848e-4**;
- train worst infidelity: **1.309017531e-3**;
- 73-point held-out worst infidelity: **1.273418936e-3**;
- reward: **10**;
- final success: **PASS**.

Thus the new robust objective preserves oracle reachability under the compute-bounded inner optimizer.

## Scientific blocker B: delayed / non-monotone credit

S4 demonstrated that fidelity along a correct prefix is non-monotone, so prefix-difference reward shaping is unsafe. S4.1 instead adds Terminal Objective Credit (TOC):

`r_aux(C_terminal) = scale * exp(-C_terminal / temperature)`.

Key semantics:

- TOC is supplied only when an episode ends without curriculum success.
- It does not alter environment reward, termination, final threshold, or reported scientific objective.
- It depends only on terminal circuit quality, not on whether intermediate prefixes improved.
- It is strictly decreasing in terminal cost, so better terminal circuits receive greater auxiliary replay credit.

The frozen diagnostic uses `temperature=0.25`, `scale=2.0`, `minimum_credit=0.05`.

## Compute-bounded credit pilot

Policies: matched uniform random, success-only corrected PS-LSTM, and TOC corrected PS-LSTM.

Frozen pilot:

- seeds: **11, 29, 47**;
- episodes per seed: **4**;
- max logical depth: **5**;
- train support: **9** periodic xi points;
- held-out support: **73** shifted periodic xi points, evaluated only at episode end;
- inner L-BFGS-B max iterations: **4**;
- robust objective: `rho=0.6`, `tau=0.08`.

No policy found a final solution in this tiny pilot. Seed-best robust objective medians were approximately:

- random: **0.62081**;
- success-only PS-LSTM: **0.76705**;
- TOC PS-LSTM: **0.76705**.

These values must not be interpreted as an algorithm ranking because the budget is extremely small and the two PS-LSTM variants sampled the same early trajectories.

The mechanism-level result is clear:

- success-only PS-LSTM: **0 replay items, 0 gradient updates** for all three seeds;
- TOC PS-LSTM: **20 replay items, 3 gradient updates** for each seed;
- auxiliary-credit episodes: **4, 4, 3** across seeds 11, 29, 47.

A policy-shift diagnostic at seed 11 confirms that the success-only learner remains exactly uniform after four episodes, while TOC changes the learned h-values from `[1,1,1,1]` to approximately `[1.13944,1.14364,1.13988,1.14105]`. The action-probability shift remains small because beta is intentionally near its early annealing value; this is expected and is not a convergence claim.

## Test evaluation isolation

S4.1 adds `defer_test_evaluation=True`. Under this mode, held-out xi points are not passed into L-BFGS-B and are not evaluated at intermediate environment steps. The dense test grid is evaluated only once when an episode ends. A regression test verifies this behavior.

## Regression suite

Final collected suite: **73 tests**.

Validated partitions:

- fast physics/gradient/learner/objective tests: **48/48 PASS**;
- optimizer + exhaustive search: **7/7 PASS**;
- environment: **13/13 PASS**;
- trainer/campaign/terminal-credit integration: **5/5 PASS**.

Total: **73/73 PASS**.

## Remaining blockers

1. TOC has demonstrated active credit flow, not superior search performance.
2. The robust objective has reduced one known sparse-grid failure mode but does not prove uniform approximation over a continuous interval. Dense held-out testing remains mandatory.
3. No structured search baseline has yet been integrated into the v0.6 campaign.
4. No long multi-seed convergence experiment has been authorized.

## Next milestone

S4.2 should implement at least one structured discrete-search baseline (beam / best-first / MCTS-style), compare it with random and PS-LSTM under matched inner-optimizer budgets, and determine whether the five-gate oracle can be discovered reliably without directly seeding the oracle sequence.
