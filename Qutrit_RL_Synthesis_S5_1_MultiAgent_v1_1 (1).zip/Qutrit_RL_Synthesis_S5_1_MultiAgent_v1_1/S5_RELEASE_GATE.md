# S5 Final Training Candidate Gate

| Gate | Status |
|---|---|
| Physics/gates/target regression | PASS |
| Analytic gradients | PASS |
| Robust family objective | PASS |
| 9-point train grid / 73-point held-out separation | PASS |
| 721-point audit grid isolated from training | PASS |
| Exact depth-5 oracle reachable with frozen `maxiter=4` | PASS |
| Held-out worst infidelity for both known exact topologies < 1e-2 | PASS |
| Dense 721-point worst infidelity for both oracle topologies < 1e-2 | PASS |
| Corrected 2-layer PS-LSTM | PASS |
| TOC credit | PASS |
| Terminal-priority replay | PASS |
| Uniform-replay one-factor control | PASS |
| Read-only convergence probe | PASS |
| Exact episode-transaction resume | PASS |
| Runner protocol/tree hash lock | PASS |
| 32 new frozen seeds | PASS |
| 300-episode budget frozen | PASS |
| Regression tests | 97/97 PASS |
| Pre-final fresh-extract integrity | PASS |

**Gate decision:** READY_FOR_FULL_TRAINING.

This status means the software/protocol is ready to launch the full campaign.  It does **not** mean the learner has already demonstrated stable convergence.
