# S4.3a changelog — resumable confirmatory campaign execution

- Added an **execution-only** resumable campaign layer under `tools/`.
- Frozen scientific files under `qutrit_synthesis/` and `examples/` are unchanged byte-for-byte from S4.3.
- Campaign checkpoints are atomic at completed-episode boundaries.
- Added persistent child worker to avoid per-episode Python/PyTorch startup overhead.
- Added external no-progress watchdog. A timeout kills the child and retries the same episode from the last authoritative checkpoint.
- No seed/topology is skipped on timeout. Exhausted retries block the run instead of dropping data.
- Added optional execution thread caps (`OMP`, `MKL`, `OPENBLAS`, `NUMEXPR`, Torch) without modifying scientific hyperparameters.
- Validated exact pause/reconstruct/resume semantics for Uniform Random and Corrected PS-LSTM+TOC.
- Validated injected-watchdog recovery with exact scientific-result equality.
- Validated exact equality against the original frozen one-shot campaign implementation.
- Completed predeclared confirmatory seed `1012132659` for both policies; PS-LSTM+TOC found the canonical exact topology at episode index 17 while matched random had no success. This single seed is evidence only, not a superiority claim.
