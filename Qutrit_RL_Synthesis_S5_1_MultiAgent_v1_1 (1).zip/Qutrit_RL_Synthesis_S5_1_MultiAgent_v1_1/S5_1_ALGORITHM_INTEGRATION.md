# S5.1 Algorithm Integration — Qutrit PPO / PPO-TrXL / CAD-SF-TrPPO

## Scope

This release extends the validated parameterized two-qutrit synthesis code. It does **not** import the PASS radio environment or modify the qutrit physics. The following remain unchanged from S5:

- target family `U_target(xi)=exp[-i xi (lambda3 ⊗ lambda3)]`;
- action semantics `U3(q0), U3(q1), CX, CX†`;
- exact 3×3 / 9×9 logical gate matrices;
- family fidelity and robust objective;
- deterministic L-BFGS-B continuous optimizer and warm-start/zero-restart semantics;
- curriculum and terminal success threshold;
- train / held-out xi grids and exact oracle registry.

Only the **discrete topology learner** is extended.

## 1. Memoryless categorical PPO

For the four qutrit gate actions the policy is categorical,

`pi(a|s) = softmax(z_theta(s))_a`.

The implementation uses clipped PPO with GAE:

`r_t(theta)=exp(log pi_theta(a_t|s_t)-log pi_old(a_t|s_t))`,

`L_clip = mean(min(r_t A_t, clip(r_t,1-eps,1+eps) A_t))`,

with `gamma=0.99`, `lambda_GAE=0.95`, `eps=0.2`, clipped value loss, four PPO epochs and four minibatches. The policy and value networks use separate 256-256 MLPs. AdamW is used with weight decay `1e-2`; learning rate is annealed from `3e-4` to `5e-5`.

## 2. PPO-TrXL for the partially observed gate sequence

The environment exposes the same 4-D `last_action` observation used by PS-LSTM. PPO-TrXL adds detached episodic temporal context rather than changing the environment observation.

Architecture:

- 256-unit observation encoder;
- two temporal-attention layers;
- hidden dimension 128;
- four attention heads;
- qutrit episode memory length = 5, equal to the frozen maximum topology depth;
- 128-unit post-temporal layer;
- categorical actor head and scalar critic head.

Each behavior transition stores the **detached per-layer memory inputs** that generated that action. PPO epochs reuse this behavior-generated context. Thus rollout collection does not backpropagate across old episode steps and the temporal context is not silently recomputed as a different recurrent state during the update.

## 3. CAD-SF-TrPPO discrete adaptation

The PASS version of CAD-SF-TrPPO uses a Gaussian policy because the PASS action is continuous. Directly copying its Gaussian likelihood/Fisher formulas into circuit synthesis would be incorrect. S5.1 therefore preserves the CAD training mechanism but derives it for the qutrit categorical actor.

For each minibatch, the critic-return inconsistency target is

`delta_b = stopgrad(|V(h_b)-V_target_b|)`,

`nu_b = clip(delta_b / (mean(delta)+eps_res), 0, 1)`.

A two-layer sigmoid residual head predicts `M_phi(h_b)` and

`w_res = mean_b M_phi(h_b)`,

`alpha_dyn = kappa * alpha_init * stopgrad(w_res)`.

The CAD objective is the categorical PPO objective plus value/residual losses and dynamic categorical entropy.

For the Soft-Fisher term, the score is the correct discrete-policy score

`grad_theta_a log Categorical(a_b; logits_theta(h_b))`.

The implementation maintains the diagonal on-policy score second moment

`F_B = mean_b[(grad log pi_b)^2] + xi_d`,

`Fdiag <- beta Fdiag + (1-beta) F_B`.

Only the categorical actor-head gradient is replaced by

`g_tilde = w_res * g/(sqrt(Fdiag+xi_d)+eps_F) + (1-w_res)*g`.

The temporal encoder, critic and residual head retain their ordinary gradients, followed by global norm clipping and AdamW. `TrPPO` here means **Transformer/temporal PPO**, not TRPO.

## 4. Reward fairness

PPO, PPO-TrXL and CAD-SF-TrPPO receive the environment's native curriculum reward. No PS-LSTM terminal objective credit is injected into PPO rewards. This avoids silently changing the Markov reward when adding the new algorithms. The existing `ps_lstm` arm remains the previously selected PS-LSTM+TOC+terminal-priority variant and is therefore a distinct learner design rather than a reward-identical PPO ablation.

## 5. Checkpoint / exact resume

The PPO-family state includes:

- model and AdamW optimizer;
- local NumPy and PyTorch RNG states;
- interaction / episode / PPO-update counters;
- incomplete on-policy rollout buffer;
- detached episodic memory state;
- CAD running diagonal Fisher state;
- last training diagnostics.

The S5.1 runner commits after every completed episode and refuses resume if either the S5.1 protocol hash or scientific Python-tree hash changes.

## 6. Five common pilot seeds

The default pilot uses the same five seeds for all four learners:

`2848563236, 3136500928, 664763853, 2415822092, 1456147837`.

The default budget remains 300 episodes/seed for an initial controlled comparison. Longer runs should use a new declared experiment identity rather than changing a completed pilot retrospectively.
