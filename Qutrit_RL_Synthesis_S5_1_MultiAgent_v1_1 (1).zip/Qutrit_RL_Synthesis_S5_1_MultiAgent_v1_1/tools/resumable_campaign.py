from __future__ import annotations

"""Episode-transactional, resumable S4.3 campaign runner.

Scientific invariance rule
--------------------------
This runner does not modify qutrit_synthesis/ or examples/.  It reconstructs the
frozen S4.3 environment/learner from examples.run_s4_2_matched_seed and executes
one *complete episode* in a child process.  The parent checkpoint is atomically
advanced only after the child finishes successfully.  If a child is killed or
hits the external wall-clock watchdog, the previous checkpoint remains intact
and the exact same episode is retried from the same environment, learner, and
RNG state.

The watchdog/thread caps are execution controls only.  They do not change the
frozen optimizer method, maxiter, starts, objective, rewards, seeds, or policy.
"""

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from typing import Any

# Make the frozen package importable when this tool is executed by path.
SCRIPT_ROOT = Path(__file__).resolve().parents[1]
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

import numpy as np
import torch

# Frozen scientific construction.  Do not duplicate hyperparameters here.
from examples.run_s4_2_matched_seed import TOC, agent_for, env_for
from qutrit_synthesis.campaign import KNOWN_EXACT_ACTIONS, ORACLE_ACTIONS
from qutrit_synthesis.environment import ACTION_TO_KIND
from qutrit_synthesis.terminal_credit import terminal_objective_credit
from qutrit_synthesis.trainer import run_episode

FORMAT_VERSION = 1
POLICIES = ("random", "ps_lstm_toc")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _tree_fingerprint(root: Path) -> str:
    """Fingerprint the frozen Python scientific tree only."""
    files = sorted(
        [p for base in (root / "qutrit_synthesis", root / "examples") for p in base.rglob("*.py")]
    )
    h = hashlib.sha256()
    for p in files:
        rel = p.relative_to(root).as_posix().encode()
        h.update(rel + b"\0")
        h.update(bytes.fromhex(_sha256_file(p)))
    return h.hexdigest()


def _protocol_fingerprint(root: Path) -> str:
    return _sha256_file(root / "S4_3_PROTOCOL_PREDECLARED.json")


def _atomic_torch_save(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        torch.save(obj, tmp)
        with tmp.open("rb") as f:
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)


def _atomic_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
        with tmp.open("rb") as f:
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)


def _empty_stats(policy: str, seed: int) -> dict[str, Any]:
    return {
        "policy": policy,
        "seed": int(seed),
        "episodes_completed": 0,
        "interactions": 0,
        "final_success_episodes": 0,
        "first_final_success_episode": None,
        "best_objective": float("inf"),
        "best_worst_test_infidelity": None,
        "shortest_final_success_length": None,
        "oracle_exact_hits": 0,
        "known_exact_hits": 0,
        "best_actions": [],
        "best_action_kinds": [],
        "auxiliary_credit_episodes": 0,
        "action_counts": [0, 0, 0, 0],
        "episode_records": [],
    }


def initialize_state(root: Path, *, policy: str, seed: int, episodes_total: int) -> dict[str, Any]:
    if policy not in POLICIES:
        raise ValueError(f"policy must be one of {POLICIES}")
    if episodes_total <= 0:
        raise ValueError("episodes_total must be positive")
    env = env_for(seed)
    state: dict[str, Any] = {
        "format_version": FORMAT_VERSION,
        "policy": policy,
        "seed": int(seed),
        "episodes_total": int(episodes_total),
        "next_episode": 0,
        "protocol_sha256": _protocol_fingerprint(root),
        "core_python_tree_sha256": _tree_fingerprint(root),
        "env_state": env.state_dict(),
        "agent_state": None,
        "random_rng_state": None,
        "stats": _empty_stats(policy, seed),
        "execution_audit": {
            "successful_episode_wall_seconds": 0.0,
            "watchdog_timeouts": 0,
            "worker_failures": 0,
            "retries": 0,
        },
    }
    if policy == "ps_lstm_toc":
        state["agent_state"] = agent_for(seed).state_dict()
    else:
        rng = np.random.default_rng(seed)
        state["random_rng_state"] = copy.deepcopy(rng.bit_generator.state)
    return state


def validate_state(root: Path, state: dict[str, Any]) -> None:
    if int(state["format_version"]) != FORMAT_VERSION:
        raise ValueError("unsupported campaign checkpoint version")
    if state["policy"] not in POLICIES:
        raise ValueError("invalid checkpoint policy")
    if state["protocol_sha256"] != _protocol_fingerprint(root):
        raise ValueError("frozen protocol hash mismatch")
    if state["core_python_tree_sha256"] != _tree_fingerprint(root):
        raise ValueError("frozen scientific Python tree hash mismatch")
    if not (0 <= int(state["next_episode"]) <= int(state["episodes_total"])):
        raise ValueError("invalid next_episode")


def _update_stats(stats: dict[str, Any], rec: dict[str, Any]) -> None:
    ep = int(rec["episode_index_local"])
    actions = tuple(int(x) for x in rec["actions"])
    kinds = tuple(str(x) for x in rec["action_kinds"])
    for a in actions:
        stats["action_counts"][a] += 1
    stats["interactions"] += len(actions)
    if actions == ORACLE_ACTIONS:
        stats["oracle_exact_hits"] += 1
    if actions in KNOWN_EXACT_ACTIONS:
        stats["known_exact_hits"] += 1
    objective = float(rec["objective"])
    if objective < float(stats["best_objective"]):
        stats["best_objective"] = objective
        stats["best_worst_test_infidelity"] = rec["worst_test_infidelity"]
        stats["best_actions"] = list(actions)
        stats["best_action_kinds"] = list(kinds)
    if bool(rec["final_success"]):
        stats["final_success_episodes"] += 1
        if stats["first_final_success_episode"] is None:
            stats["first_final_success_episode"] = ep
        L = len(actions)
        old = stats["shortest_final_success_length"]
        stats["shortest_final_success_length"] = L if old is None else min(int(old), L)
    if rec.get("auxiliary_terminal_credit") is not None and float(rec["auxiliary_terminal_credit"]) > 0:
        stats["auxiliary_credit_episodes"] += 1
    stats["episodes_completed"] += 1
    # Keep a compact, auditable per-episode record; no optimizer internals.
    stats["episode_records"].append({
        "episode": ep,
        "actions": list(actions),
        "objective": objective,
        "worst_test_infidelity": rec["worst_test_infidelity"],
        "final_success": bool(rec["final_success"]),
        "auxiliary_terminal_credit": rec.get("auxiliary_terminal_credit"),
    })


def execute_one_episode(root: Path, state: dict[str, Any]) -> dict[str, Any]:
    """Pure episode transaction: input checkpoint -> output next checkpoint."""
    validate_state(root, state)
    ep = int(state["next_episode"])
    if ep >= int(state["episodes_total"]):
        return state
    seed = int(state["seed"])
    episode_seed = seed * 100_000 + ep + 1
    env = env_for(seed)
    env.load_state_dict(state["env_state"])
    t0 = time.perf_counter()

    if state["policy"] == "ps_lstm_toc":
        agent = agent_for(seed)
        agent.load_state_dict(state["agent_state"])
        rec0 = run_episode(env, agent, seed=episode_seed, terminal_credit=TOC)
        rec = {
            "episode_index_local": ep,
            "actions": list(rec0.actions),
            "action_kinds": list(rec0.action_kinds),
            "objective": float(rec0.final_objective),
            "worst_test_infidelity": rec0.final_worst_test_infidelity,
            "final_success": bool(rec0.final_success),
            "auxiliary_terminal_credit": rec0.auxiliary_terminal_credit,
        }
        new_agent_state = agent.state_dict()
    else:
        rng = np.random.default_rng()
        rng.bit_generator.state = copy.deepcopy(state["random_rng_state"])
        _, _ = env.reset(seed=episode_seed)
        actions: list[int] = []
        kinds: list[str] = []
        terminated = truncated = False
        final_info: dict[str, Any] | None = None
        while not (terminated or truncated):
            action = int(rng.integers(env.action_space_n))
            _, _, terminated, truncated, info = env.step(action)
            actions.append(action)
            kinds.append(str(info["action_kind"]))
            final_info = info
        assert final_info is not None
        tm = final_info.get("test_metrics")
        rec = {
            "episode_index_local": ep,
            "actions": actions,
            "action_kinds": kinds,
            "objective": float(final_info["objective"]),
            "worst_test_infidelity": None if tm is None else float(tm["worst_infidelity"]),
            "final_success": bool(final_info["final_success"]),
            "auxiliary_terminal_credit": None,
        }
        new_agent_state = None
        state["random_rng_state"] = copy.deepcopy(rng.bit_generator.state)

    new_state = copy.deepcopy(state)
    new_state["env_state"] = env.state_dict()
    new_state["agent_state"] = new_agent_state
    if state["policy"] == "random":
        new_state["random_rng_state"] = copy.deepcopy(state["random_rng_state"])
    _update_stats(new_state["stats"], rec)
    new_state["next_episode"] = ep + 1
    new_state["execution_audit"]["successful_episode_wall_seconds"] += float(time.perf_counter() - t0)
    return new_state


def scientific_result(state: dict[str, Any]) -> dict[str, Any]:
    """Return the protocol endpoints; intentionally exclude wall-clock/retry fields."""
    s = state["stats"]
    out = {
        "policy": state["policy"],
        "seed": int(state["seed"]),
        "episodes": int(state["episodes_total"]),
        "episodes_completed": int(s["episodes_completed"]),
        "interactions": int(s["interactions"]),
        "final_success_episodes": int(s["final_success_episodes"]),
        "first_final_success_episode": s["first_final_success_episode"],
        "best_objective": float(s["best_objective"]),
        "best_worst_test_infidelity": s["best_worst_test_infidelity"],
        "shortest_final_success_length": s["shortest_final_success_length"],
        "oracle_exact_hits": int(s["oracle_exact_hits"]),
        "known_exact_hits": int(s["known_exact_hits"]),
        "best_actions": list(s["best_actions"]),
        "best_action_kinds": list(s["best_action_kinds"]),
        "final_curriculum_threshold": float(state["env_state"]["curriculum_state"]["threshold"]),
        "auxiliary_credit_episodes": (int(s["auxiliary_credit_episodes"]) if state["policy"] == "ps_lstm_toc" else None),
        "action_counts": list(s["action_counts"]),
    }
    if state["policy"] == "ps_lstm_toc":
        a = state["agent_state"]
        out.update({
            "replay_size": len(a["replay"]["items"]),
            "gradient_updates": int(a["gradient_updates"]),
            "target_syncs": int(a["target_syncs"]),
            "successful_curriculum_episodes": int(a["successful_episodes"]),
        })
    else:
        out.update({
            "replay_size": None,
            "gradient_updates": None,
            "target_syncs": None,
            "successful_curriculum_episodes": None,
        })
    return out


def _worker_main(root: Path, checkpoint: Path, candidate: Path, sleep_s: float) -> int:
    # Legacy one-episode worker retained for focused debugging.
    if sleep_s > 0:
        time.sleep(sleep_s)
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    new_state = execute_one_episode(root, state)
    _atomic_torch_save(new_state, candidate)
    return 0


def _loop_worker_main(
    root: Path, checkpoint: Path, target_completed: int,
    inject_sleep_episode: int | None, sleep_s: float,
) -> int:
    """Run multiple episode transactions in one process, checkpointing each.

    The supervisor may kill this process at any point.  Because the checkpoint is
    atomically replaced only after a complete episode, a kill during an optimizer
    call leaves the last completed episode authoritative.
    """
    injected = False
    while True:
        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        validate_state(root, state)
        ep = int(state["next_episode"])
        if ep >= int(state["episodes_total"]) or ep >= int(target_completed):
            return 0
        if inject_sleep_episode is not None and ep == int(inject_sleep_episode) and not injected:
            injected = True
            time.sleep(float(sleep_s))
        new_state = execute_one_episode(root, state)
        _atomic_torch_save(new_state, checkpoint)


def _child_env(thread_cap: int) -> dict[str, str]:
    env = os.environ.copy()
    if thread_cap > 0:
        for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
            env[key] = str(thread_cap)
        env["TORCH_NUM_THREADS"] = str(thread_cap)
    return env


def supervisor_run(
    root: Path,
    checkpoint: Path,
    result_json: Path,
    *,
    policy: str,
    seed: int,
    episodes_total: int,
    episode_timeout_s: float,
    max_retries: int,
    thread_cap: int,
    stop_after_completed: int | None = None,
    inject_timeout_once_episode: int | None = None,
) -> dict[str, Any]:
    if episode_timeout_s <= 0:
        raise ValueError("episode_timeout_s must be positive")
    if max_retries < 0:
        raise ValueError("max_retries must be non-negative")
    if checkpoint.exists():
        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        validate_state(root, state)
        if state["policy"] != policy or int(state["seed"]) != int(seed) or int(state["episodes_total"]) != int(episodes_total):
            raise ValueError("existing checkpoint identity mismatch")
    else:
        state = initialize_state(root, policy=policy, seed=seed, episodes_total=episodes_total)
        _atomic_torch_save(state, checkpoint)

    target = episodes_total if stop_after_completed is None else min(int(stop_after_completed), episodes_total)
    injected_once = False
    retries_for_episode = 0

    while int(state["next_episode"]) < target:
        start_ep = int(state["next_episode"])
        inject_ep = None
        inject_sleep = 0.0
        if inject_timeout_once_episode is not None and start_ep <= int(inject_timeout_once_episode) < target and not injected_once:
            inject_ep = int(inject_timeout_once_episode)
            inject_sleep = max(float(episode_timeout_s) * 2.0, 0.2)

        cmd = [
            sys.executable, str(Path(__file__).resolve()), "loop-worker",
            "--root", str(root), "--checkpoint", str(checkpoint),
            "--target-completed", str(target),
        ]
        if inject_ep is not None:
            cmd += ["--inject-sleep-episode", str(inject_ep), "--sleep-s", str(inject_sleep)]

        proc = subprocess.Popen(
            cmd,
            env=_child_env(thread_cap),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        last_ep = start_ep
        last_progress = time.monotonic()
        timeout_happened = False
        stderr_tail = ""

        while True:
            rc = proc.poll()
            # Atomic checkpoint replacement makes concurrent reads safe.  If a
            # transient filesystem read fails, simply try again on the next poll.
            try:
                observed = torch.load(checkpoint, map_location="cpu", weights_only=False)
                validate_state(root, observed)
                obs_ep = int(observed["next_episode"])
                if obs_ep > last_ep:
                    state = observed
                    last_ep = obs_ep
                    last_progress = time.monotonic()
                    retries_for_episode = 0
            except Exception:
                pass

            if rc is not None:
                if proc.stderr is not None:
                    try:
                        stderr_tail = proc.stderr.read()[-4000:]
                    except Exception:
                        stderr_tail = ""
                break
            if time.monotonic() - last_progress > float(episode_timeout_s):
                timeout_happened = True
                proc.kill()
                try:
                    proc.wait(timeout=5)
                except Exception:
                    pass
                break
            time.sleep(0.25)

        # Reload the authoritative checkpoint after the worker is definitely dead.
        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        validate_state(root, state)
        now_ep = int(state["next_episode"])

        if timeout_happened:
            state["execution_audit"]["watchdog_timeouts"] += 1
            state["execution_audit"]["retries"] += 1
            _atomic_torch_save(state, checkpoint)
            if inject_ep is not None:
                injected_once = True
            if now_ep == last_ep:
                retries_for_episode += 1
            else:
                retries_for_episode = 0
            if retries_for_episode > max_retries:
                raise RuntimeError(f"episode {now_ep} exceeded watchdog after {max_retries} retries")
            continue

        if rc != 0:
            state["execution_audit"]["worker_failures"] += 1
            state["execution_audit"]["retries"] += 1
            _atomic_torch_save(state, checkpoint)
            retries_for_episode += 1
            if retries_for_episode > max_retries:
                raise RuntimeError(
                    f"worker failed near episode {now_ep} after {max_retries} retries; stderr={stderr_tail}"
                )
            continue

        if now_ep <= start_ep and now_ep < target:
            raise RuntimeError("worker exited successfully without advancing checkpoint")
        retries_for_episode = 0

    payload = {
        "status": "COMPLETE" if int(state["next_episode"]) == episodes_total else "PAUSED",
        "protocol_sha256": state["protocol_sha256"],
        "core_python_tree_sha256": state["core_python_tree_sha256"],
        "scientific_result": scientific_result(state),
        "execution_audit": copy.deepcopy(state["execution_audit"]),
        "checkpoint": str(checkpoint),
    }
    _atomic_json(payload, result_json)
    return payload

def _parse() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    wp = sub.add_parser("worker")
    wp.add_argument("--root", type=Path, required=True)
    wp.add_argument("--checkpoint", type=Path, required=True)
    wp.add_argument("--candidate", type=Path, required=True)
    wp.add_argument("--sleep-s", type=float, default=0.0)

    lp = sub.add_parser("loop-worker")
    lp.add_argument("--root", type=Path, required=True)
    lp.add_argument("--checkpoint", type=Path, required=True)
    lp.add_argument("--target-completed", type=int, required=True)
    lp.add_argument("--inject-sleep-episode", type=int)
    lp.add_argument("--sleep-s", type=float, default=0.0)

    rp = sub.add_parser("run")
    rp.add_argument("--root", type=Path, required=True)
    rp.add_argument("--checkpoint", type=Path, required=True)
    rp.add_argument("--result-json", type=Path, required=True)
    rp.add_argument("--policy", choices=POLICIES, required=True)
    rp.add_argument("--seed", type=int, required=True)
    rp.add_argument("--episodes", type=int, required=True)
    rp.add_argument("--episode-timeout-s", type=float, default=120.0)
    rp.add_argument("--max-retries", type=int, default=3)
    rp.add_argument("--thread-cap", type=int, default=1)
    rp.add_argument("--stop-after-completed", type=int)
    rp.add_argument("--inject-timeout-once-episode", type=int)
    return ap.parse_args()


def main() -> None:
    a = _parse()
    if a.cmd == "worker":
        code = _worker_main(a.root.resolve(), a.checkpoint.resolve(), a.candidate.resolve(), a.sleep_s)
        try:
            sys.stdout.flush(); sys.stderr.flush()
        finally:
            os._exit(code)
    if a.cmd == "loop-worker":
        code = _loop_worker_main(
            a.root.resolve(), a.checkpoint.resolve(), a.target_completed,
            a.inject_sleep_episode, a.sleep_s,
        )
        try:
            sys.stdout.flush(); sys.stderr.flush()
        finally:
            os._exit(code)
    payload = supervisor_run(
        a.root.resolve(), a.checkpoint.resolve(), a.result_json.resolve(),
        policy=a.policy, seed=a.seed, episodes_total=a.episodes,
        episode_timeout_s=a.episode_timeout_s, max_retries=a.max_retries,
        thread_cap=a.thread_cap, stop_after_completed=a.stop_after_completed,
        inject_timeout_once_episode=a.inject_timeout_once_episode,
    )
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
