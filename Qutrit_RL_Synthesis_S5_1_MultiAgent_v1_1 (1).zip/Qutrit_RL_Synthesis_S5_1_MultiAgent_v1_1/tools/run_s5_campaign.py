from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from qutrit_synthesis.final_training import FINAL_SEEDS, FINAL_EPISODES_PER_SEED


def main() -> None:
    ap=argparse.ArgumentParser(description='Run a resumable shard of the frozen S5 campaign.')
    ap.add_argument('--arm', choices=['terminal_priority','uniform','random'], required=True)
    ap.add_argument('--output-root', type=Path, required=True)
    ap.add_argument('--start-index', type=int, default=0)
    ap.add_argument('--count', type=int, default=8)
    ap.add_argument('--inactivity-timeout-s', type=float, default=180.0)
    ap.add_argument('--max-retries', type=int, default=3)
    ap.add_argument('--thread-cap', type=int, default=1)
    a=ap.parse_args()
    if a.start_index < 0 or a.count <= 0 or a.start_index+a.count > len(FINAL_SEEDS):
        raise SystemExit('invalid seed shard')
    a.output_root.mkdir(parents=True,exist_ok=True)
    rows=[]
    runner=ROOT/'tools'/'final_training_runner.py'
    for idx in range(a.start_index,a.start_index+a.count):
        seed=FINAL_SEEDS[idx]
        run_dir=a.output_root/a.arm/f'seed_{seed}'
        run_dir.mkdir(parents=True,exist_ok=True)
        cmd=[sys.executable,str(runner),'run','--root',str(ROOT),
             '--checkpoint',str(run_dir/'checkpoint.pt'),
             '--result-json',str(run_dir/'result.json'),
             '--snapshots-dir',str(run_dir/'snapshots'),
             '--arm',a.arm,'--seed',str(seed),'--episodes',str(FINAL_EPISODES_PER_SEED),
             '--inactivity-timeout-s',str(a.inactivity_timeout_s),
             '--max-retries',str(a.max_retries),'--thread-cap',str(a.thread_cap)]
        subprocess.run(cmd,check=True)
        payload=json.loads((run_dir/'result.json').read_text())
        rows.append({'seed_index':idx,'seed':seed,'status':payload['status'],
                     'scientific_result':payload['scientific_result'],
                     'execution_audit':payload['execution_audit']})
        (a.output_root/a.arm/f'shard_{a.start_index:02d}_{a.start_index+a.count-1:02d}.json').write_text(
            json.dumps({'arm':a.arm,'rows':rows},indent=2),encoding='utf-8')
    print(json.dumps({'arm':a.arm,'completed':len(rows),'seed_indices':[a.start_index,a.start_index+a.count-1]},indent=2))

if __name__=='__main__':
    main()
