from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import torch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from tools.resumable_campaign import supervisor_run
from tools.convergence_probe import probe_agent_state


def atomic_json(obj,path):
    path.write_text(json.dumps(obj,indent=2,sort_keys=True),encoding='utf-8')


def compact_stats(st):
    stats=st['stats']
    return {
        'episodes_completed':stats['episodes_completed'],
        'interactions':stats['interactions'],
        'final_success_episodes':stats['final_success_episodes'],
        'first_final_success_episode':stats['first_final_success_episode'],
        'best_objective':stats['best_objective'],
        'known_exact_hits':stats['known_exact_hits'],
        'action_counts':stats['action_counts'],
        'replay_size':len(st['agent_state']['replay']['items']),
        'gradient_updates':st['agent_state']['gradient_updates'],
        'target_syncs':st['agent_state']['target_syncs'],
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--out-dir',type=Path,required=True)
    ap.add_argument('--episodes',type=int,default=120)
    ap.add_argument('--chunk',type=int,default=10)
    ap.add_argument('--episode-timeout-s',type=float,default=120.)
    a=ap.parse_args()
    a.out_dir.mkdir(parents=True,exist_ok=True)
    ck=a.out_dir/f'ps_lstm_toc_{a.seed}.pt'
    result=a.out_dir/f'ps_lstm_toc_{a.seed}.json'
    trace=a.out_dir/f'convergence_trace_{a.seed}.json'

    if trace.exists():
        payload=json.loads(trace.read_text())
        records=payload['records']
    else:
        records=[]

    if not ck.exists():
        supervisor_run(ROOT,ck,result,policy='ps_lstm_toc',seed=a.seed,episodes_total=a.episodes,
                       episode_timeout_s=a.episode_timeout_s,max_retries=5,thread_cap=1,stop_after_completed=0)
    st=torch.load(ck,map_location='cpu',weights_only=False)
    current=int(st['next_episode'])
    recorded={int(r['episode']) for r in records}
    if 0 not in recorded and current==0:
        records.append({'episode':0,'probe':probe_agent_state(st['agent_state']),'stats':compact_stats(st)})
        atomic_json({'seed':a.seed,'episodes_total':a.episodes,'records':records},trace)

    next_target=((current//a.chunk)+1)*a.chunk
    if current % a.chunk == 0 and current not in recorded:
        records.append({'episode':current,'probe':probe_agent_state(st['agent_state']),'stats':compact_stats(st)})
        atomic_json({'seed':a.seed,'episodes_total':a.episodes,'records':records},trace)
        next_target=current+a.chunk

    while current < a.episodes:
        target=min(next_target,a.episodes)
        supervisor_run(ROOT,ck,result,policy='ps_lstm_toc',seed=a.seed,episodes_total=a.episodes,
                       episode_timeout_s=a.episode_timeout_s,max_retries=5,thread_cap=1,stop_after_completed=target)
        st=torch.load(ck,map_location='cpu',weights_only=False)
        current=int(st['next_episode'])
        if current not in {int(r['episode']) for r in records}:
            records.append({'episode':current,'probe':probe_agent_state(st['agent_state']),'stats':compact_stats(st)})
            records.sort(key=lambda r:int(r['episode']))
            atomic_json({'seed':a.seed,'episodes_total':a.episodes,'records':records},trace)
        next_target=current+a.chunk
    print(trace)

if __name__=='__main__': main()
