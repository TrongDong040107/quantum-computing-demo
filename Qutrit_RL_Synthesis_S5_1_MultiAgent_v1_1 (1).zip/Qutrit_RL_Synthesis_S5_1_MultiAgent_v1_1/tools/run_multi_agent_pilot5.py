#!/usr/bin/env python3
"""Launch the common-five-seed pilot for one selected algorithm."""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
from qutrit_synthesis.multi_agent_training import MULTI_AGENT_ALGORITHMS, PILOT_SEEDS


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--algorithm", choices=MULTI_AGENT_ALGORITHMS, required=True)
    p.add_argument("--episodes", type=int, default=300)
    p.add_argument("--output-dir", type=Path, default=Path("runs_s5_1"))
    p.add_argument("--start-index", type=int, default=0)
    p.add_argument("--count", type=int, default=5)
    args = p.parse_args()
    seeds = PILOT_SEEDS[args.start_index:args.start_index + args.count]
    if not seeds:
        raise SystemExit("empty seed shard")
    for seed in seeds:
        cmd = [
            sys.executable, str(ROOT / "tools" / "run_multi_agent_qutrit.py"),
            "--algorithm", args.algorithm,
            "--seed", str(seed),
            "--episodes", str(args.episodes),
            "--output-dir", str(args.output_dir),
        ]
        print("RUN", " ".join(cmd), flush=True)
        subprocess.run(cmd, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
