from __future__ import annotations
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "tools" / "resumable_campaign.py"


def run_cmd(args):
    cp = subprocess.run([sys.executable, str(RUNNER), *args], cwd=ROOT, capture_output=True, text=True, check=True)
    return cp


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def strip_runtime(payload):
    return payload["scientific_result"]


def main():
    outdir = ROOT / "s4_3a_validation"
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir()

    records = {}
    for policy in ("random", "ps_lstm_toc"):
        # A: uninterrupted supervisor transaction sequence.
        ca = outdir / f"{policy}_A.pt"; ra = outdir / f"{policy}_A.json"
        run_cmd(["run","--root",str(ROOT),"--checkpoint",str(ca),"--result-json",str(ra),
                 "--policy",policy,"--seed","11","--episodes","2","--episode-timeout-s","60","--thread-cap","1"])
        # B: pause after episode 1, then reconstruct process and resume the same checkpoint.
        cb = outdir / f"{policy}_B.pt"; rb = outdir / f"{policy}_B.json"
        run_cmd(["run","--root",str(ROOT),"--checkpoint",str(cb),"--result-json",str(rb),
                 "--policy",policy,"--seed","11","--episodes","2","--episode-timeout-s","60","--thread-cap","1",
                 "--stop-after-completed","1"])
        run_cmd(["run","--root",str(ROOT),"--checkpoint",str(cb),"--result-json",str(rb),
                 "--policy",policy,"--seed","11","--episodes","2","--episode-timeout-s","60","--thread-cap","1"])
        A=load(ra); B=load(rb)
        exact = strip_runtime(A) == strip_runtime(B)
        records[policy] = {"pause_resume_exact": exact, "A": strip_runtime(A), "B": strip_runtime(B)}
        if not exact:
            raise SystemExit(f"pause/resume mismatch: {policy}")

    # C: actual watchdog timeout before any scientific mutation, then retry same checkpoint.
    c = outdir / "random_watchdog.pt"; r = outdir / "random_watchdog.json"
    run_cmd(["run","--root",str(ROOT),"--checkpoint",str(c),"--result-json",str(r),
             "--policy","random","--seed","11","--episodes","2","--episode-timeout-s","15","--max-retries","2",
             "--thread-cap","1","--inject-timeout-once-episode","0"])
    wd=load(r)
    c2 = outdir / "random_reference.pt"; r2 = outdir / "random_reference.json"
    run_cmd(["run","--root",str(ROOT),"--checkpoint",str(c2),"--result-json",str(r2),
             "--policy","random","--seed","11","--episodes","2","--episode-timeout-s","60","--thread-cap","1"])
    ref=load(r2)
    records["watchdog"] = {
        "scientific_result_exact": strip_runtime(wd)==strip_runtime(ref),
        "watchdog_timeouts": wd["execution_audit"]["watchdog_timeouts"],
        "retries": wd["execution_audit"]["retries"],
    }
    if not records["watchdog"]["scientific_result_exact"] or records["watchdog"]["watchdog_timeouts"] < 1:
        raise SystemExit("watchdog transactional test failed")

    # D: compare resumable scientific fields with the original frozen one-shot
    # campaign functions for the same seed/episode budget.
    from examples.run_s4_2_matched_seed import env_for, agent_for, TOC
    from qutrit_synthesis.campaign import run_random_pilot, run_ps_lstm_pilot
    direct_random = run_random_pilot(env_for(11), seed=11, episodes=2).to_dict()
    direct_ps = run_ps_lstm_pilot(env_for(11), agent_for(11), seed=11, episodes=2, terminal_credit=TOC).to_dict()
    def normalize_direct(d):
        return {k:v for k,v in d.items() if k != "wall_seconds"}
    resumable_random = load(outdir / "random_A.json")["scientific_result"]
    resumable_ps = load(outdir / "ps_lstm_toc_A.json")["scientific_result"]
    # Runner adds episodes_completed; frozen PilotRunResult does not.
    rr = dict(resumable_random); rr.pop("episodes_completed", None)
    rp = dict(resumable_ps); rp.pop("episodes_completed", None)
    records["frozen_one_shot_alignment"] = {
        "random_exact": rr == normalize_direct(direct_random),
        "ps_lstm_toc_exact": rp == normalize_direct(direct_ps),
    }
    if not all(records["frozen_one_shot_alignment"].values()):
        raise SystemExit("frozen one-shot alignment failed")

    path = outdir / "S4_3A_RESUME_VALIDATION.json"
    path.write_text(json.dumps(records,indent=2,sort_keys=True),encoding="utf-8")
    print(path)
    print("S4_3A_RESUME_VALIDATION_PASS")

if __name__=="__main__": main()
