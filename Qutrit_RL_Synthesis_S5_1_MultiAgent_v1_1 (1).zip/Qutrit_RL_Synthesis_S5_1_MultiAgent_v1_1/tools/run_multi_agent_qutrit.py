#!/usr/bin/env python3
"""Run/resume one S5.1 qutrit learner seed with episode-transaction checkpoints."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qutrit_synthesis.multi_agent_runner import (
    initialize_state, execute_one_episode, scientific_result, validate_state,
)
from qutrit_synthesis.multi_agent_training import MULTI_AGENT_ALGORITHMS, PILOT_SEEDS


def atomic_torch_save(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmpname = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    os.close(fd)
    tmp = Path(tmpname)
    try:
        torch.save(obj, tmp)
        # Verify readability before replace.
        _ = torch.load(tmp, map_location="cpu", weights_only=False)
        with tmp.open("rb") as f:
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--algorithm", choices=MULTI_AGENT_ALGORITHMS, required=True)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--episodes", type=int, default=300)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--max-episodes-this-run", type=int, default=0,
                   help="0=run until complete; positive value is useful for Colab chunking")
    args = p.parse_args()

    if args.episodes <= 0:
        raise SystemExit("--episodes must be positive")
    out = args.output_dir / args.algorithm / f"seed_{args.seed}"
    out.mkdir(parents=True, exist_ok=True)
    checkpoint = out / "checkpoint.pt"
    result_json = out / "result.json"

    if checkpoint.exists():
        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        validate_state(ROOT, state)
        if state["algorithm"] != args.algorithm or int(state["seed"]) != args.seed:
            raise RuntimeError("checkpoint identity mismatch")
        if int(state["episodes_total"]) != args.episodes:
            raise RuntimeError("episode-budget mismatch; use a new output directory")
    else:
        state = initialize_state(ROOT, algorithm=args.algorithm, seed=args.seed, episodes_total=args.episodes)
        atomic_torch_save(state, checkpoint)

    start_ep = int(state["next_episode"])
    stop_ep = args.episodes
    if args.max_episodes_this_run > 0:
        stop_ep = min(stop_ep, start_ep + args.max_episodes_this_run)

    while int(state["next_episode"]) < stop_ep:
        state = execute_one_episode(ROOT, state)
        atomic_torch_save(state, checkpoint)
        sr = scientific_result(state)
        print(json.dumps({
            "algorithm": args.algorithm,
            "seed": args.seed,
            "episode": int(state["next_episode"]),
            "episodes_total": args.episodes,
            "best_objective": sr["best_objective"],
            "success_episodes": sr["final_success_episodes"],
            "known_exact_hits": sr["known_exact_hits"],
        }), flush=True)

    if int(state["next_episode"]) == args.episodes:
        payload = scientific_result(state)
        result_json.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        print(f"COMPLETE {result_json}")
    else:
        print(f"PAUSED at episode {state['next_episode']}/{args.episodes}; rerun same command to resume")


if __name__ == "__main__":
    main()
