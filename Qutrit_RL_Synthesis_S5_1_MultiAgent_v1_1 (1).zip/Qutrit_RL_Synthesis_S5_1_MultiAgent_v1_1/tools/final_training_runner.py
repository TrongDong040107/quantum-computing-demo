from __future__ import annotations

"""Watchdog-supervised, exact-resume runner for the S5 frozen campaign."""
import argparse
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

SCRIPT_ROOT = Path(__file__).resolve().parents[1]
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))

import torch

from qutrit_synthesis.final_runner import ARMS, execute_one_episode, initialize_state, scientific_result, validate_state
from qutrit_synthesis.final_training import FINAL_EPISODES_PER_SEED, FINAL_SEEDS, SNAPSHOT_INTERVAL_EPISODES


def _atomic_torch_save(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        torch.save(obj, tmp)
        with tmp.open("rb") as f:
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def _atomic_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
        with tmp.open("rb") as f:
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def _loop_worker(root: Path, checkpoint: Path, target: int) -> int:
    while True:
        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        validate_state(root, state)
        if int(state["next_episode"]) >= min(int(state["episodes_total"]), int(target)):
            return 0
        new_state = execute_one_episode(root, state)
        _atomic_torch_save(new_state, checkpoint)


def _child_env(thread_cap: int) -> dict[str, str]:
    env = os.environ.copy()
    if thread_cap > 0:
        for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
            env[k] = str(thread_cap)
        env["TORCH_NUM_THREADS"] = str(thread_cap)
    return env


def supervisor_run(
    root: Path,
    checkpoint: Path,
    result_json: Path,
    *,
    arm: str,
    seed: int,
    episodes_total: int = FINAL_EPISODES_PER_SEED,
    inactivity_timeout_s: float = 180.0,
    max_retries: int = 3,
    thread_cap: int = 1,
    stop_after_completed: int | None = None,
    snapshots_dir: Path | None = None,
    enforce_final_identity: bool = True,
) -> dict[str, Any]:
    if arm not in ARMS:
        raise ValueError(f"arm must be one of {ARMS}")
    if enforce_final_identity:
        if seed not in FINAL_SEEDS:
            raise ValueError("seed is not in the frozen S5 final seed list")
        if int(episodes_total) != FINAL_EPISODES_PER_SEED:
            raise ValueError("final campaign must use the frozen episode budget")
    if inactivity_timeout_s <= 0 or max_retries < 0:
        raise ValueError("invalid watchdog settings")

    if checkpoint.exists():
        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        validate_state(root, state)
        if state["arm"] != arm or int(state["seed"]) != seed or int(state["episodes_total"]) != episodes_total:
            raise ValueError("checkpoint identity mismatch")
    else:
        state = initialize_state(root, arm=arm, seed=seed, episodes_total=episodes_total)
        _atomic_torch_save(state, checkpoint)

    target = episodes_total if stop_after_completed is None else min(int(stop_after_completed), episodes_total)
    retries_for_episode = 0
    last_snapshot_ep = -1

    while int(state["next_episode"]) < target:
        start_ep = int(state["next_episode"])
        cmd = [
            sys.executable, str(Path(__file__).resolve()), "worker-loop",
            "--root", str(root), "--checkpoint", str(checkpoint), "--target", str(target),
        ]
        proc = subprocess.Popen(cmd, env=_child_env(thread_cap), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
        last_progress = time.monotonic()
        last_ep = start_ep
        timed_out = False
        stderr_tail = ""
        while True:
            rc = proc.poll()
            try:
                observed = torch.load(checkpoint, map_location="cpu", weights_only=False)
                validate_state(root, observed)
                obs_ep = int(observed["next_episode"])
                if obs_ep > last_ep:
                    state = observed
                    last_ep = obs_ep
                    last_progress = time.monotonic()
                    retries_for_episode = 0
                    if snapshots_dir is not None and obs_ep % SNAPSHOT_INTERVAL_EPISODES == 0 and obs_ep != last_snapshot_ep:
                        snapshots_dir.mkdir(parents=True, exist_ok=True)
                        _atomic_torch_save(state, snapshots_dir / f"episode_{obs_ep:04d}.pt")
                        last_snapshot_ep = obs_ep
            except Exception:
                pass
            if rc is not None:
                if proc.stderr is not None:
                    try: stderr_tail = proc.stderr.read()[-4000:]
                    except Exception: stderr_tail = ""
                break
            if time.monotonic() - last_progress > inactivity_timeout_s:
                timed_out = True
                proc.kill()
                try: proc.wait(timeout=5)
                except Exception: pass
                break
            time.sleep(0.25)

        state = torch.load(checkpoint, map_location="cpu", weights_only=False)
        validate_state(root, state)
        now_ep = int(state["next_episode"])
        if timed_out:
            state["execution_audit"]["watchdog_timeouts"] += 1
            state["execution_audit"]["retries"] += 1
            _atomic_torch_save(state, checkpoint)
            retries_for_episode += 1
            if retries_for_episode > max_retries:
                raise RuntimeError(f"episode {now_ep} exceeded watchdog after {max_retries} retries")
            continue
        if rc != 0:
            state["execution_audit"]["worker_failures"] += 1
            state["execution_audit"]["retries"] += 1
            _atomic_torch_save(state, checkpoint)
            retries_for_episode += 1
            if retries_for_episode > max_retries:
                raise RuntimeError(f"worker failed near episode {now_ep}: {stderr_tail}")
            continue
        if now_ep <= start_ep and now_ep < target:
            raise RuntimeError("worker exited without advancing checkpoint")
        retries_for_episode = 0

    payload = {
        "status": "COMPLETE" if int(state["next_episode"]) == episodes_total else "PAUSED",
        "protocol_sha256": state["protocol_sha256"],
        "core_python_tree_sha256": state["core_python_tree_sha256"],
        "scientific_result": scientific_result(state),
        "execution_audit": copy.deepcopy(state["execution_audit"]),
        "checkpoint": str(checkpoint),
    }
    _atomic_json(payload, result_json)
    return payload


def _parse() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    wp = sub.add_parser("worker-loop")
    wp.add_argument("--root", type=Path, required=True)
    wp.add_argument("--checkpoint", type=Path, required=True)
    wp.add_argument("--target", type=int, required=True)
    rp = sub.add_parser("run")
    rp.add_argument("--root", type=Path, required=True)
    rp.add_argument("--checkpoint", type=Path, required=True)
    rp.add_argument("--result-json", type=Path, required=True)
    rp.add_argument("--arm", choices=ARMS, required=True)
    rp.add_argument("--seed", type=int, required=True)
    rp.add_argument("--episodes", type=int, default=FINAL_EPISODES_PER_SEED)
    rp.add_argument("--inactivity-timeout-s", type=float, default=180.0)
    rp.add_argument("--max-retries", type=int, default=3)
    rp.add_argument("--thread-cap", type=int, default=1)
    rp.add_argument("--stop-after-completed", type=int)
    rp.add_argument("--snapshots-dir", type=Path)
    rp.add_argument("--allow-nonfinal-identity", action="store_true")
    return ap.parse_args()


def main() -> None:
    a = _parse()
    if a.cmd == "worker-loop":
        code = _loop_worker(a.root.resolve(), a.checkpoint.resolve(), a.target)
        try: sys.stdout.flush(); sys.stderr.flush()
        finally: os._exit(code)
    payload = supervisor_run(
        a.root.resolve(), a.checkpoint.resolve(), a.result_json.resolve(),
        arm=a.arm, seed=a.seed, episodes_total=a.episodes,
        inactivity_timeout_s=a.inactivity_timeout_s, max_retries=a.max_retries,
        thread_cap=a.thread_cap, stop_after_completed=a.stop_after_completed,
        snapshots_dir=(None if a.snapshots_dir is None else a.snapshots_dir.resolve()),
        enforce_final_identity=not a.allow_nonfinal_identity,
    )
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
