from __future__ import annotations
import copy
from dataclasses import dataclass, asdict
from typing import Sequence, Any
import numpy as np
import torch

from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig

EXACT_SEQUENCES=((2,1,2,1,2),(3,1,3,1,3))


def _agent_from_state(state: dict[str, Any]) -> CorrectedPSLSTMAgent:
    a=CorrectedPSLSTMAgent(PSLSTMConfig(**dict(state['config'])))
    a.load_state_dict(state)
    return a


def _force_step(agent, obs, action):
    scores,next_state=agent._candidate_scores_and_states(obs)
    probs=torch.softmax(agent.beta*scores,dim=0).detach().cpu().numpy().astype(np.float64)
    hn,cn=next_state
    agent._hidden=(hn[:,action:action+1,:].detach().clone(),cn[:,action:action+1,:].detach().clone())
    nxt=np.zeros(agent.config.obs_dim,dtype=np.float64); nxt[action]=1.0
    return probs,nxt


def probe_agent_state(agent_state: dict[str, Any], sequences: Sequence[Sequence[int]]=EXACT_SEQUENCES) -> dict[str, Any]:
    agent=_agent_from_state(agent_state)
    results=[]
    for seq0 in sequences:
        seq=tuple(int(a) for a in seq0)
        agent.reset_recurrent_state(clear_pending=True)
        obs=np.zeros(agent.config.obs_dim,dtype=np.float64)
        step_p=[]; ent=[]; maxp=[]
        for action in seq:
            probs,obs=_force_step(agent,obs,action)
            step_p.append(float(probs[action]))
            ent.append(float(-(probs*np.log(np.maximum(probs,1e-300))).sum()))
            maxp.append(float(probs.max()))
        results.append({
            'sequence':list(seq),
            'step_probabilities':step_p,
            'step_entropies_nats':ent,
            'step_normalized_entropies':[x/np.log(agent.config.action_dim) for x in ent],
            'step_max_probabilities':maxp,
            'product_probability':float(np.prod(step_p)),
        })
    products=[x['product_probability'] for x in results]
    return {
        'episodes_trained':int(agent.episodes),
        'beta':float(agent.beta),
        'sequences':results,
        'any_known_exact_probability':float(sum(products)),
        'best_known_exact_probability':float(max(products)),
        'uniform_single_exact_probability':float((1/agent.config.action_dim)**len(results[0]['sequence'])),
        'uniform_any_known_probability':float(sum((1/agent.config.action_dim)**len(x['sequence']) for x in results)),
    }
