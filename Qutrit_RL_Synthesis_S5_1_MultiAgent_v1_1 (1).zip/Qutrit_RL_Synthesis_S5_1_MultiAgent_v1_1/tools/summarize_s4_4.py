from __future__ import annotations
import json, math, sys
from pathlib import Path
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from examples.run_s4_2_matched_seed import agent_for
from tools.convergence_probe import probe_agent_state

SEEDS=[130883010,2848563235,3136500927,1826782196]
RUN=ROOT/'s4_4_trace_runs'
UNIFORM=2/1024
rows=[]
for s in SEEDS:
    st=torch.load(RUN/f'ps_lstm_toc_{s}.pt',map_location='cpu',weights_only=False)
    p=probe_agent_state(st['agent_state'])
    ag=agent_for(s); ag.load_state_dict(st['agent_state']); ag.reset_recurrent_state(clear_pending=True)
    ev=ag.evaluate_actions(np.zeros(4,dtype=np.float64))
    recs=st['stats']['episode_records']
    def action_entropy(lo,hi):
        c=np.zeros(4,int)
        for r in recs[lo:hi]:
            for a in r['actions']: c[int(a)]+=1
        q=c/c.sum(); H=float(-(q*np.log(np.maximum(q,1e-300))).sum()/np.log(4))
        return {'counts':c.tolist(),'probabilities':q.tolist(),'normalized_entropy':H}
    norm_ent=[v for q in p['sequences'] for v in q['step_normalized_entropies']]
    rows.append({
        'seed':s,'episodes_completed':int(st['next_episode']),
        'final_success_episodes':int(st['stats']['final_success_episodes']),
        'known_exact_hits':int(st['stats']['known_exact_hits']),
        'best_objective':float(st['stats']['best_objective']),
        'beta_final':float(p['beta']),
        'any_known_exact_probability':float(p['any_known_exact_probability']),
        'exact_mass_ratio_to_uniform':float(p['any_known_exact_probability']/UNIFORM),
        'best_known_exact_probability':float(p['best_known_exact_probability']),
        'probe_normalized_entropy_mean':float(np.mean(norm_ent)),
        'probe_normalized_entropy_min':float(np.min(norm_ent)),
        'initial_action_probabilities':list(ev.probabilities),
        'initial_h_values':list(ev.h_values),
        'initial_h_range':float(max(ev.h_values)-min(ev.h_values)),
        'initial_exact_first_action_mass':float(ev.probabilities[2]+ev.probabilities[3]),
        'replay_size':len(st['agent_state']['replay']['items']),
        'gradient_updates':int(st['agent_state']['gradient_updates']),
        'target_syncs':int(st['agent_state']['target_syncs']),
        'early_action_distribution':action_entropy(0,20),
        'late_action_distribution':action_entropy(100,120),
    })

def qstats(xs):
    a=np.asarray(xs,float); return {'mean':float(a.mean()),'median':float(np.median(a)),'min':float(a.min()),'max':float(a.max()),'q25':float(np.quantile(a,.25)),'q75':float(np.quantile(a,.75))}
summary={
    'milestone':'S4.4_CONVERGENCE_TRACE_COMPLETE',
    'status':'NO_STABLE_CONVERGENCE_OBSERVED',
    'n_diagnostic_seeds':len(SEEDS),'episodes_per_seed':120,
    'uniform_any_known_exact_probability':UNIFORM,
    'rows':rows,
    'aggregate':{
        'seed_success_rate':sum(r['final_success_episodes']>0 for r in rows)/len(rows),
        'known_exact_hits_total':sum(r['known_exact_hits'] for r in rows),
        'best_objective':qstats([r['best_objective'] for r in rows]),
        'any_known_exact_probability':qstats([r['any_known_exact_probability'] for r in rows]),
        'exact_mass_ratio_to_uniform':qstats([r['exact_mass_ratio_to_uniform'] for r in rows]),
        'probe_normalized_entropy_mean':qstats([r['probe_normalized_entropy_mean'] for r in rows]),
        'probe_normalized_entropy_min':qstats([r['probe_normalized_entropy_min'] for r in rows]),
        'initial_exact_first_action_mass':qstats([r['initial_exact_first_action_mass'] for r in rows]),
        'late_empirical_action_entropy':qstats([r['late_action_distribution']['normalized_entropy'] for r in rows]),
    },
    'interpretation':[
        'All four seeds reached beta=1.0 and completed 119 gradient updates, but no final success or known exact topology was found.',
        'Final probability mass on the two known exact sequences remained close to the uniform baseline 2/1024.',
        'Policy entropy remained high; completing the beta anneal alone did not cause stable policy concentration.',
        'The bottleneck is therefore not simply the 50-episode truncation of S4.3; credit/replay dynamics remain the leading suspect.'
    ]
}
(ROOT/'S4_4_TRACE_RESULTS.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
# CSV
import csv
with (ROOT/'S4_4_TRACE_SEED_SUMMARY.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['seed','episodes_completed','final_success_episodes','known_exact_hits','best_objective','beta_final','any_known_exact_probability','exact_mass_ratio_to_uniform','probe_normalized_entropy_mean','probe_normalized_entropy_min','initial_exact_first_action_mass','replay_size','gradient_updates','target_syncs'])
    w.writeheader();
    for r in rows: w.writerow({k:r[k] for k in w.fieldnames})
print(json.dumps(summary['aggregate'],indent=2))
