from __future__ import annotations
import argparse, json, sys, os, tempfile
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from tools.resumable_campaign import initialize_state, validate_state, execute_one_episode
from tools.convergence_probe import probe_agent_state


def atomic_torch(obj,path):
    fd,tmp=tempfile.mkstemp(dir=path.parent,prefix=path.name+'.',suffix='.tmp'); os.close(fd); tmp=Path(tmp)
    try: torch.save(obj,tmp); os.replace(tmp,path)
    finally: tmp.unlink(missing_ok=True)

def atomic_json(obj,path):
    fd,tmp=tempfile.mkstemp(dir=path.parent,prefix=path.name+'.',suffix='.tmp'); os.close(fd); tmp=Path(tmp)
    try: tmp.write_text(json.dumps(obj,indent=2,sort_keys=True)); os.replace(tmp,path)
    finally: tmp.unlink(missing_ok=True)

def stats(st):
    s=st['stats']; a=st['agent_state']
    return {'episodes_completed':s['episodes_completed'],'interactions':s['interactions'],'final_success_episodes':s['final_success_episodes'],'first_final_success_episode':s['first_final_success_episode'],'best_objective':s['best_objective'],'known_exact_hits':s['known_exact_hits'],'action_counts':s['action_counts'],'replay_size':len(a['replay']['items']),'gradient_updates':a['gradient_updates'],'target_syncs':a['target_syncs']}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seed',type=int,required=True); ap.add_argument('--out-dir',type=Path,required=True); ap.add_argument('--episodes',type=int,default=120); ap.add_argument('--chunk',type=int,default=10); a=ap.parse_args()
    a.out_dir.mkdir(parents=True,exist_ok=True)
    ck=a.out_dir/f'ps_lstm_toc_{a.seed}.pt'; trace=a.out_dir/f'convergence_trace_{a.seed}.json'
    if ck.exists(): st=torch.load(ck,map_location='cpu',weights_only=False); validate_state(ROOT,st)
    else: st=initialize_state(ROOT,policy='ps_lstm_toc',seed=a.seed,episodes_total=a.episodes); atomic_torch(st,ck)
    recs=json.loads(trace.read_text())['records'] if trace.exists() else []
    recorded={int(x['episode']) for x in recs}
    if int(st['next_episode'])==0 and 0 not in recorded:
        recs.append({'episode':0,'probe':probe_agent_state(st['agent_state']),'stats':stats(st)})
    while int(st['next_episode'])<a.episodes:
        st=execute_one_episode(ROOT,st); atomic_torch(st,ck)
        e=int(st['next_episode'])
        if (e%a.chunk==0 or e==a.episodes) and e not in recorded:
            recs.append({'episode':e,'probe':probe_agent_state(st['agent_state']),'stats':stats(st)}); recorded.add(e); recs.sort(key=lambda x:x['episode']); atomic_json({'seed':a.seed,'episodes_total':a.episodes,'records':recs},trace)
    atomic_json({'seed':a.seed,'episodes_total':a.episodes,'records':recs},trace)
    print(trace)
if __name__=='__main__': main()
