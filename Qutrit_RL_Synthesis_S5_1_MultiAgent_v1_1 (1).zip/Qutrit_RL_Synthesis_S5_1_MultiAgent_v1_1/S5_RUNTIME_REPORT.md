# S5 runtime report

Validation environment:

- Python 3.13.5
- NumPy 2.3.5
- SciPy 1.17.0
- PyTorch 2.10.0+cpu
- pytest 9.0.2
- Linux x86_64
- CUDA unavailable in the validation container

The final runner is CPU-deterministic by design and defaults to one BLAS/PyTorch thread per seed worker.  CUDA is not required.  The package declares Python >=3.10, NumPy >=1.24, SciPy >=1.10 and PyTorch >=2.0; the full campaign should record the exact runtime versions in its output archive.
