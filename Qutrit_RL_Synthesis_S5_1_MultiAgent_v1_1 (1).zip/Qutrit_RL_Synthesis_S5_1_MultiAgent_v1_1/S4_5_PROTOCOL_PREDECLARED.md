# S4.5 predeclared replay ablation

Diagnostic question: does terminal-quality-prioritized replay reduce replay dilution and improve stable policy concentration relative to the frozen uniform-replay PS-LSTM+TOC baseline?

Frozen factors: qutrit physics, action space, robust family objective, 9 train / 73 held-out xi grid, L-BFGS-B maxiter=4, curriculum, TOC, PS-LSTM architecture, optimizer, beta schedule, episode horizon=120.

Only changed factor: replay sampling.

- Baseline: `uniform`.
- Intervention: `terminal_priority`, sampling weight `(terminal_reward + 0.05)^1.0`.
- The stored fitted target/glow reward is unchanged. `sampling_priority` equals the episode terminal reward for every prefix from that episode, so prioritization is by trajectory terminal quality rather than prefix position.
- Six new paired seeds: 2892904734, 2849884710, 4148499779, 2290485830, 1883404877, 1474418994.
- 120 episodes/seed/policy.
- Primary diagnostic endpoints: seed final success, known-exact hits, final probability mass on the two known exact sequences, normalized policy entropy, best held-out family fidelity.
- Diagnostic only; no superiority p-value claim from six seeds.
