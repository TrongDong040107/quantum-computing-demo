# S5.1 Multi-Agent Validation Report

**Status:** `PASS_FOR_CONTROLLED_PILOT`

## Added algorithms

- categorical PPO;
- categorical PPO-TrXL with detached episodic temporal memory;
- categorical CAD-SF-TrPPO with residual-conditioned entropy and actor-head Soft-Fisher shaping.

The original corrected PS-LSTM remains available and unchanged.

## Regression

Final source-tree tests were executed in three deterministic CPU partitions with one BLAS thread:

- partition A: 56/56 PASS;
- partition B: 30/30 PASS;
- partition C: 18/18 PASS;
- total: **104/104 PASS**.

The new PPO-family-specific suite contributes 7 tests covering probability validity, seeded action reproducibility, finite PPO updates, temporal-memory reset, CAD Fisher/residual updates, exact learner-state continuation, and non-mutating exact-sequence probing.

## Real qutrit-environment smoke

For `ppo`, `ppo_trxl`, and `cad_sf_trppo`, a two-episode real-environment run was executed using the S5 qutrit physics/objective/optimizer. The run exercised:

- discrete action sampling;
- real topology append;
- L-BFGS-B inner optimization;
- curriculum reward;
- PPO buffer and update;
- policy probe;
- result serialization.

All three algorithms remained finite. With the intentionally tiny two-episode smoke, each PPO-family learner performed one forced final rollout flush and 16 minibatch gradient updates.

## Exact resume validation

For each new algorithm, the following two paths were compared:

1. uninterrupted two-episode execution;
2. one episode -> checkpoint -> process reconstruction -> resume episode two.

The final scientific JSON objects were exactly equal for all three algorithms:

- PPO: `exact_resume=True`;
- PPO-TrXL: `exact_resume=True`;
- CAD-SF-TrPPO: `exact_resume=True`.

This validates the saved local RNG, optimizer, rollout and temporal/CAD state on CPU.

## Interpretation limits

This validation establishes implementation and resume correctness. It does **not** establish that any of PPO, PPO-TrXL or CAD-SF-TrPPO outperforms PS-LSTM, random search, or one another on the qutrit synthesis task. That requires the planned common-seed training campaign.
