# S4 changelog

- Added a matched uniform-random baseline using the exact same environment, optimizer, curriculum, xi grids and episode budget as PS-LSTM.
- Added controlled-pilot metrics: final-success rate, first final success, best objective, shortest successful circuit, known-oracle exact hits, action counts, interactions and wall time.
- Added a frozen compute-constrained pilot entry point and regression tests for random-baseline reproducibility and aggregation.
- No changes were made to the S0 physics, S1 optimizer, S2 environment semantics or S3 corrected PS-LSTM mathematics.
