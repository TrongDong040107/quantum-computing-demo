# S4 Validation Report

- Status: **S4_DIAGNOSTIC_PASS_NOT_READY_FOR_LONG_TRAINING**
- New/learner regression subset: **20/20 PASS**.
- Controlled pilot: **2 seeds × 20 episodes per policy** completed.
- Oracle reachability guard: **PASS** (train 0.0030728967; worst test 0.0073629021).
- Exact known-oracle hits during matched pilot: **0 random / 0 PS-LSTM**.
- Final threshold successes: **0 random / 0 PS-LSTM**.
- Main blockers: delayed/non-monotone credit assignment and sparse xi training support.

See `S4_PILOT_REPORT.md` for interpretation.
