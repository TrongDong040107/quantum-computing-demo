# S4 Controlled Pilot Report — v0.5

## Status

**S4 PILOT COMPLETED — LEARNING CONVERGENCE NOT DEMONSTRATED.**

This is a compute-constrained diagnostic pilot, not a paper-scale result. The first planned 3-seed × 40-episode matched campaign exceeded the 180 s execution window before producing a result file. The frozen pilot was therefore reduced to **2 seeds × 20 episodes per policy** while keeping all scientific semantics unchanged.

## Frozen pilot configuration

- Policies: corrected PS-LSTM vs matched uniform random search.
- Seeds: [11, 29].
- Episodes per seed: 20.
- Maximum logical gates per episode: 5.
- Train xi points: 3.
- Disjoint test xi points: 17.
- Inner L-BFGS-B iterations per environment step: 5.
- Inner random restarts: 0.
- Curriculum: initial threshold 0.55, final threshold 1e-2, update window 8.
- PS-LSTM: 2 layers, hidden size 128, batch size 8, target/update clocks every 20 interactions, beta anneal horizon 120 episodes.

The reduced batch/cadence settings are pilot settings chosen so learning updates actually occur within 20 episodes. They are not claimed to reproduce the manuscript's final hyperparameter campaign.

## Matched results

| Metric | Uniform random | Corrected PS-LSTM |
|---|---:|---:|
| Independent seeds | 2 | 2 |
| Seeds with final success | 0% | 0% |
| Total final-success episodes | 0 | 0 |
| Exact known-oracle sequence hits | 0 | 0 |
| Best train objective across seeds | 0.412027480378 | 0.420875212427 |
| Median seed-best train objective | 0.428810324822 | 0.432659828435 |
| Mean interactions / seed | 98.5 | 97.5 |
| Mean wall time / seed | 4.279 s | 5.366 s |

### Interpretation

There is **no evidence in this pilot that PS-LSTM outperforms uniform random search**. Neither policy reached the final threshold 1e-2, and the median best training objective was slightly lower for random search (0.428810) than PS-LSTM (0.432660). With only two seeds and twenty episodes, this difference has no statistical meaning.

The PS-LSTM was nevertheless active rather than frozen: seed 11 accumulated 26 replay items and 7 gradient updates; seed 29 accumulated 14 replay items and 4 gradient updates. Both runs performed four target-network synchronizations. Thus the lack of final success is not a training-plumbing failure.

## Critical diagnostic 1 — the exact solution is reachable under the pilot optimizer

The known exact topology

`CX† -> U3(q1) -> CX† -> U3(q1) -> CX†`

was replayed under the same 3-point train grid, 17-point test grid, and only five L-BFGS-B iterations per step. The final result was:

- mean training infidelity: **0.0030728967305243176**;
- worst unseen-test infidelity: **0.007362902117417969**;
- final curriculum success: **PASS**.

Therefore S4 failure to discover the solution is a **search/credit-assignment issue**, not an unreachable optimizer threshold.

## Critical diagnostic 2 — oracle-prefix reward is extremely sparse and non-monotone

Along the exact five-action oracle trajectory, the optimized training objectives were:

1. `CX†`: 0.962962963
2. `CX† -> U3(q1)`: 0.877579155
3. `CX† -> U3(q1) -> CX†`: 0.902711039
4. `CX† -> U3(q1) -> CX† -> U3(q1)`: 0.584608421
5. final `CX†`: **0.003072897**

With the pilot curriculum threshold 0.55, the exact trajectory receives no positive reward until the final action. More importantly, the cost becomes *worse* from step 2 to step 3 even though step 3 is part of the globally exact topology. Therefore local fidelity improvement is not a reliable shaped reward for this problem.

This is the main scientific blocker revealed by S4: the outer learner faces a delayed-reward topology problem in which good prefixes can look poor to the inner optimizer.

## Critical diagnostic 3 — the final action is decisive

Holding the first four oracle actions fixed, the fifth action gives:

| Fifth action | Train objective | Worst test infidelity | Final success |
|---|---:|---:|---|
| U3(q0) | 0.420875212 | 0.873620105 | no |
| U3(q1) | 0.412027480 | 0.867048484 | no |
| CX | 0.811195323 | 0.905887217 | no |
| **CX†** | **0.003072897** | **0.007362902** | **yes** |

The best-looking wrong fifth action on the training objective is still catastrophically poor over the unseen parameter grid. This shows that the task is both combinatorial and strongly family-generalization sensitive.

## Critical diagnostic 4 — the current 3-point train grid is too sparse for scientific claims

The best non-exact topologies found by both policies had train objectives around 0.41–0.44 while their worst test infidelities were around 0.87–0.89. Thus a small mean-cost training grid can substantially understate failure between sampled xi values.

This does **not** invalidate the exact oracle, which generalizes across the full family. It does mean that a final DRL campaign should not use a three-point train grid as its scientific objective.

## Why zero oracle hits are unsurprising

For one specified five-action sequence and four equiprobable actions, uniform random sampling has probability 1/4^5 = 1/1024 per full five-step episode. Even if all forty random episodes across both seeds reached length five, the probability of seeing that one sequence at least once is only about **3.83%**. Therefore zero exact-oracle hits in this pilot are expected and cannot by themselves be used to judge the learner.

## S4 release decision

**PASS as a controlled diagnostic pilot. NOT READY for a long training campaign.**

The next milestone should not simply increase episode count. It should first address two issues exposed here:

1. **family-generalization objective** — increase and/or resample xi support during inner optimization and report worst-case/quantile error, not only three-point mean error;
2. **credit assignment** — preserve the exact terminal objective but introduce a scientifically controlled exploration/credit mechanism that does not assume monotonic prefix fidelity. Candidate baselines include elite-sequence replay, beam/MCTS-assisted exploration, or a curriculum over topology depth/known family difficulty. Any shaped reward must be validated against the exact oracle and must not change the optimum.

A fair next experiment should keep the current corrected PS-LSTM as a baseline and compare it with uniform random plus at least one structured search baseline before claiming a DRL advantage.
