# S5 validation report — Final Training Candidate v1.0

## Decision

**READY_FOR_FULL_TRAINING** after final package integrity verification.

S5 intentionally makes no new claim that PS-LSTM has converged.  It freezes the candidate selected after S4.5 and closes the engineering gates required before a paper-scale training campaign.

## Frozen scientific candidate

The proposed arm is corrected 2-layer PS-LSTM + terminal objective credit + terminal-quality-prioritized replay.  Its matched learner control is mathematically identical except for uniform replay sampling.  The environment remains the two-qutrit parameterized target family with four discrete gate actions, maximum length five, the 9-point robust training family objective, 73-point held-out evaluation and deterministic L-BFGS-B (`maxiter=4`) with parent + zero starts.

The S5 campaign freezes 32 previously unused seeds and 300 episodes per seed per arm.  Beta anneals from 1e-3 to 1 over the first 120 episodes and remains at 1 for the final 180 episodes.  Read-only policy probes are taken every 10 episodes; exact episode checkpoints are committed after every episode and archival snapshots every 25 episodes.

## Scientific isolation checks

The 9-point training grid does not overlap the 73-point held-out grid.  A separate 721-point periodic audit grid is also disjoint from the training grid and is not passed to the optimizer, curriculum, replay priority or training policy.

Both independently validated exact depth-5 topologies remain reachable under the frozen production inner-optimizer budget.  With the same four-iteration L-BFGS-B budget used during training, both reach robust objective about `4.47846e-4`, 73-point held-out worst infidelity about `1.27342e-3`, and 721-point dense-audit worst infidelity about `1.30539e-3`, all below the `1e-2` final-success threshold.

## Resume / reproducibility gate

A real supervisor run was paused after one episode, reconstructed from disk, and resumed to three episodes.  Its complete scientific result was exactly identical to an uninterrupted three-episode state-machine execution for the same seed.  Checkpoints embed both the frozen protocol SHA-256 and the scientific Python-tree SHA-256; a mismatch blocks resume rather than silently changing campaign identity.

## Regression

The S5 source passed 97/97 tests in three partitions: 44 physics/objective/protocol tests, 35 environment/learner/resume tests, and 18 campaign/optimizer/structured-search tests.  `compileall` also passed.

## Remaining scientific uncertainty

S4.5 showed prioritized replay is promising but can still converge to a wrong attractor.  S5 therefore freezes the candidate rather than declaring convergence.  The full S5 campaign must report all 32 seeds and use the predeclared convergence endpoints; failures may not be discarded.
