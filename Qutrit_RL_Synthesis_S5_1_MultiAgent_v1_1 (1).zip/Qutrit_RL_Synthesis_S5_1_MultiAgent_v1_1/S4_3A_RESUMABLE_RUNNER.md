# S4.3a — deterministic resumable campaign runner

This layer is **execution infrastructure only**. It does not change the frozen S4.3 scientific protocol or the Python files under `qutrit_synthesis/` and `examples/`.

## Transaction semantics

Each campaign episode is executed in an isolated child process. The authoritative checkpoint is advanced atomically only after the child writes a complete candidate state. If the child crashes or exceeds an external wall-clock watchdog, the candidate is discarded and the exact same episode is retried from the same environment, curriculum, learner, replay buffer, NumPy RNG and Torch-local RNG state.

No seed/topology is skipped after a timeout. If the retry budget is exhausted the run is marked blocked instead of fabricating or dropping a datapoint.

## Execution thread cap

The supervisor may set `OMP_NUM_THREADS`, `MKL_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `NUMEXPR_NUM_THREADS` and `TORCH_NUM_THREADS` for child processes. This is an execution/runtime control; it does not alter L-BFGS-B `maxiter`, starts, objective, rewards, policy or frozen seeds.

## Example

```bash
python tools/resumable_campaign.py run \
  --root . \
  --checkpoint runs/ps_1108934464.pt \
  --result-json runs/ps_1108934464.json \
  --policy ps_lstm_toc \
  --seed 1108934464 \
  --episodes 50 \
  --episode-timeout-s 120 \
  --max-retries 3 \
  --thread-cap 1
```

Re-run the same command after interruption. The runner resumes the checkpoint instead of restarting completed episodes.
