# S4.3 Predeclared Frozen Multi-Seed Protocol

Status: **FROZEN BEFORE CAMPAIGN RESULTS**.

- 20 independent confirmatory seeds generated from master seed `20260911`; pilot seeds 11, 29, 47 are excluded.
- 50 episodes per seed and policy; max depth 5.
- Policies: matched uniform random and corrected PS-LSTM + Terminal Objective Credit.
- Physics, target family, action set, robust objective, L-BFGS-B budget, curriculum, PS-LSTM hyperparameters and TOC hyperparameters are unchanged from S4.2.
- Primary endpoint: seed-level probability of at least one validated final success.
- Secondary endpoints: first-success episode, best train robust objective, held-out worst infidelity, exact-topology hits, interactions.
- No post-hoc hyperparameter/seed changes are permitted after inspecting campaign results.
- All 20 seeds must be reported.

Seed list:

`[1108934464, 3314893829, 364727931, 3856418359, 1355935353, 1012132659, 1876820008, 3763605151, 864451966, 41162820, 3524185320, 514679046, 3957404201, 2514720355, 342410622, 2873527757, 935287719, 1848980069, 3782681457, 2795366262]`
