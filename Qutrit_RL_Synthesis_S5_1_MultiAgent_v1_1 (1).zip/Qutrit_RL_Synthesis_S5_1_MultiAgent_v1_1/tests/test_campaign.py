import numpy as np
from qutrit_synthesis.campaign import aggregate_runs, run_random_pilot
from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, QutritSynthesisEnv
from qutrit_synthesis.optimizer import OptimizerConfig

def make_env():
    return QutritSynthesisEnv(
        np.linspace(-np.pi,np.pi,3,endpoint=False),
        test_xis=np.linspace(-np.pi,np.pi,5,endpoint=False)+0.07,
        config=EnvironmentConfig(
            max_steps=2,
            optimizer=OptimizerConfig(maxiter=2,n_random_starts=0,seed=9),
            curriculum=CurriculumConfig(min_threshold=1e-2,initial_threshold=0.1,update_window=20),
        ),
    )

def test_random_pilot_reproducible():
    a=run_random_pilot(make_env(),seed=7,episodes=3)
    b=run_random_pilot(make_env(),seed=7,episodes=3)
    assert a.action_counts==b.action_counts
    assert a.best_actions==b.best_actions
    assert a.best_objective==b.best_objective
    assert a.interactions==b.interactions

def test_aggregate():
    a=run_random_pilot(make_env(),seed=1,episodes=2)
    b=run_random_pilot(make_env(),seed=2,episodes=2)
    d=aggregate_runs([a,b])
    assert d['policy']=='random'
    assert d['n_seeds']==2
    assert 0 <= d['seed_final_success_rate'] <= 1

def test_known_exact_registry_contains_canonical_and_dual():
    from qutrit_synthesis.campaign import KNOWN_EXACT_ACTIONS, ORACLE_ACTIONS, DUAL_ORACLE_ACTIONS
    assert ORACLE_ACTIONS == (3,1,3,1,3)
    assert DUAL_ORACLE_ACTIONS == (2,1,2,1,2)
    assert KNOWN_EXACT_ACTIONS == (ORACLE_ACTIONS, DUAL_ORACLE_ACTIONS)
