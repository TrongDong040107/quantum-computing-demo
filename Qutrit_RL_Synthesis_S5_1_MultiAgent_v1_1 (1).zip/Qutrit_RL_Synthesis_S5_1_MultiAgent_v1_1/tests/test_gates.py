import numpy as np

from qutrit_synthesis.gates import (
    F3, I3, X3, Z3, cx3, cx3_dagger, cz3,
    p0, p2, r01, r12, rx01, rx12, u3,
)


def assert_unitary(u, atol=1e-12):
    np.testing.assert_allclose(u.conj().T @ u, np.eye(u.shape[0]), atol=atol, rtol=0)


def test_single_qutrit_gates_are_unitary():
    for theta in [0.0, 0.13, -0.7, np.pi]:
        for phi in [0.0, 0.21, -1.2]:
            for gate in [p0(phi), p2(phi), rx01(theta), rx12(theta), r01(theta, phi), r12(theta, phi)]:
                assert_unitary(gate)


def test_u3_is_unitary_and_identity_at_zero_xi():
    rng = np.random.default_rng(1)
    for _ in range(100):
        p = rng.normal(size=8)
        xi = rng.uniform(-np.pi, np.pi)
        assert_unitary(u3(xi, p))
        np.testing.assert_allclose(u3(0.0, p), I3, atol=1e-13, rtol=0)


def test_cx_group_and_fourier_mapping():
    c = cx3()
    cd = cx3_dagger()
    assert_unitary(c)
    np.testing.assert_allclose(c @ cd, np.eye(9), atol=1e-13, rtol=0)
    np.testing.assert_allclose(np.linalg.matrix_power(c, 3), np.eye(9), atol=1e-13, rtol=0)
    np.testing.assert_allclose(F3.conj().T @ Z3 @ F3, X3, atol=1e-12, rtol=0)
    mapped = np.kron(I3, F3.conj().T) @ cz3() @ np.kron(I3, F3)
    np.testing.assert_allclose(mapped, c, atol=2e-12, rtol=0)


def test_input_validation_rejects_bad_u3_parameters():
    import pytest
    with pytest.raises(ValueError):
        u3(0.5, [0.0] * 7)
    with pytest.raises(ValueError):
        u3(0.5, [0.0] * 7 + [np.nan])
