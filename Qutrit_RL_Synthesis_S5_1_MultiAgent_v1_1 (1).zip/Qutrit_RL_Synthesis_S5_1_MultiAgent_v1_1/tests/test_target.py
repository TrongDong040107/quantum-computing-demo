import numpy as np

from qutrit_synthesis.target import H_TARGET, target_unitary


def test_target_generator_is_hermitian():
    np.testing.assert_allclose(H_TARGET, H_TARGET.conj().T, atol=0, rtol=0)


def test_target_symmetries_and_periodicity():
    rng = np.random.default_rng(2)
    np.testing.assert_allclose(target_unitary(0.0), np.eye(9), atol=0, rtol=0)
    for xi in rng.uniform(-5.0, 5.0, 100):
        u = target_unitary(float(xi))
        np.testing.assert_allclose(u.conj().T @ u, np.eye(9), atol=1e-13, rtol=0)
        np.testing.assert_allclose(target_unitary(-float(xi)), u.conj().T, atol=1e-13, rtol=0)
        np.testing.assert_allclose(target_unitary(float(xi) + 2*np.pi), u, atol=3e-15, rtol=0)
