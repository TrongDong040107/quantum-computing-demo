from pathlib import Path
import copy
import numpy as np
import torch

from qutrit_synthesis.final_runner import initialize_state, execute_one_episode, scientific_result
from qutrit_synthesis.final_training import FINAL_SEEDS

ROOT = Path(__file__).resolve().parents[1]


def _strip_wall(state):
    x = copy.deepcopy(state)
    x["execution_audit"]["successful_episode_wall_seconds"] = 0.0
    return x

def _assert_equal(a, b):
    if isinstance(a, torch.Tensor):
        assert isinstance(b, torch.Tensor)
        assert torch.equal(a, b)
    elif isinstance(a, np.ndarray):
        assert isinstance(b, np.ndarray)
        assert np.array_equal(a, b)
    elif isinstance(a, dict):
        assert set(a) == set(b)
        for k in a:
            _assert_equal(a[k], b[k])
    elif isinstance(a, (list, tuple)):
        assert type(a) is type(b) and len(a) == len(b)
        for x, y in zip(a, b):
            _assert_equal(x, y)
    elif isinstance(a, float):
        assert float(a) == float(b)
    else:
        assert a == b


def test_s5_episode_transaction_exact_resume_equivalence():
    seed = FINAL_SEEDS[0]
    a = initialize_state(ROOT, arm="terminal_priority", seed=seed, episodes_total=3)
    a1 = execute_one_episode(ROOT, a)
    # Simulate serialization boundary by deep-copying exact state.
    resumed = copy.deepcopy(a1)
    a2 = execute_one_episode(ROOT, resumed)

    b = initialize_state(ROOT, arm="terminal_priority", seed=seed, episodes_total=3)
    b = execute_one_episode(ROOT, b)
    b = execute_one_episode(ROOT, b)
    _assert_equal(_strip_wall(a2), _strip_wall(b))


def test_s5_priority_and_uniform_runner_identity_differs_only_learning_mode_initially():
    seed = FINAL_SEEDS[1]
    p = initialize_state(ROOT, arm="terminal_priority", seed=seed, episodes_total=1)
    u = initialize_state(ROOT, arm="uniform", seed=seed, episodes_total=1)
    assert p["env_state"] == u["env_state"]
    assert p["agent_state"]["config"]["replay_sampling"] == "terminal_priority"
    assert u["agent_state"]["config"]["replay_sampling"] == "uniform"


def test_s5_random_runner_smoke():
    seed = FINAL_SEEDS[2]
    s = initialize_state(ROOT, arm="random", seed=seed, episodes_total=1)
    s = execute_one_episode(ROOT, s)
    r = scientific_result(s)
    assert r["episodes_completed"] == 1
    assert 1 <= r["interactions"] <= 5
    assert r["final_policy_probe"] is None
