import numpy as np
from dataclasses import asdict

from qutrit_synthesis.final_training import (
    FINAL_SEEDS, FINAL_EPISODES_PER_SEED, PROTOCOL, agent_for, environment_for,
    protocol_sha256, train_xis, heldout_xis, dense_audit_xis, validate_final_protocol,
)


def test_s5_protocol_is_frozen_and_valid():
    r = validate_final_protocol()
    assert r["n_seeds"] == 32
    assert r["episodes_per_seed"] == 300
    assert len(protocol_sha256()) == 64


def test_s5_seed_list_unique_uint32():
    assert len(FINAL_SEEDS) == len(set(FINAL_SEEDS)) == 32
    assert all(0 < x < 2**32 for x in FINAL_SEEDS)


def test_s5_family_grids_disjoint_and_expected_sizes():
    a,b,c = train_xis(), heldout_xis(), dense_audit_xis()
    assert a.shape == (9,)
    assert b.shape == (73,)
    assert c.shape == (721,)
    assert not any(np.isclose(x, y, atol=1e-12, rtol=0) for x in a for y in b)
    assert not any(np.isclose(x, y, atol=1e-12, rtol=0) for x in a for y in c)


def test_s5_primary_and_control_differ_only_in_replay_sampling():
    seed = FINAL_SEEDS[0]
    p = agent_for(seed, replay_sampling="terminal_priority").config
    u = agent_for(seed, replay_sampling="uniform").config
    dp, du = asdict(p), asdict(u)
    assert dp.pop("replay_sampling") == "terminal_priority"
    assert du.pop("replay_sampling") == "uniform"
    assert dp == du


def test_s5_environment_lock():
    e = environment_for(FINAL_SEEDS[0])
    assert e.config.max_steps == 5
    assert e.config.optimizer.maxiter == 4
    assert e.config.optimizer.n_random_starts == 0
    assert e.config.defer_test_evaluation is True
    assert e.config.include_zero_restart is True
    assert e.curriculum.config.min_threshold == 1e-2


def test_s5_readonly_policy_probe_preserves_rng_state():
    import copy
    import torch
    from qutrit_synthesis.policy_probe import probe_agent_state
    a = agent_for(FINAL_SEEDS[0], replay_sampling="terminal_priority")
    before = a.state_dict()
    _ = probe_agent_state(before)
    after = a.state_dict()
    assert before["np_rng_state"] == after["np_rng_state"]
    assert torch.equal(before["torch_rng_state"], after["torch_rng_state"])
    assert before["interactions"] == after["interactions"]
    assert before["episodes"] == after["episodes"]
