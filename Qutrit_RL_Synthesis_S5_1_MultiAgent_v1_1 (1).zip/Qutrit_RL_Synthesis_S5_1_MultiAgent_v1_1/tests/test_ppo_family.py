import copy
import numpy as np
import torch

from qutrit_synthesis.ppo_family import DiscretePPOAgent, PPOFamilyConfig
from qutrit_synthesis.ppo_probe import probe_ppo_agent_state


def cfg(algo: str, seed: int = 123) -> PPOFamilyConfig:
    return PPOFamilyConfig(
        algorithm=algo,
        hidden_dim=32,
        encoder_dim=32,
        trxl_num_layers=2,
        trxl_num_heads=4,
        trxl_memory_length=5,
        rollout_steps=4,
        update_epochs=2,
        num_minibatches=2,
        lr_anneal_interactions=100,
        entropy_anneal_interactions=100,
        seed=seed,
        device="cpu",
    )


def synthetic_episode(agent: DiscretePPOAgent, length: int = 5) -> None:
    agent.reset_episode()
    obs = np.zeros(4, dtype=np.float64)
    for t in range(length):
        action, ev = agent.act(obs)
        nxt = np.zeros(4, dtype=np.float64)
        nxt[action] = 1.0
        done = t == length - 1
        agent.observe(obs, action, 1.0 if done else 0.0, nxt, terminated=done, truncated=False, evaluation=ev)
        obs = nxt


def test_action_probabilities_are_valid_all_algorithms():
    for algo in ("ppo", "ppo_trxl", "cad_sf_trppo"):
        agent = DiscretePPOAgent(cfg(algo))
        action, ev = agent.act(np.zeros(4))
        assert 0 <= action < 4
        assert np.isclose(sum(ev.probabilities), 1.0)
        assert all(np.isfinite(ev.probabilities))
        assert np.isfinite(ev.logprob)
        assert np.isfinite(ev.value)


def test_seeded_action_sampling_is_exactly_reproducible():
    for algo in ("ppo", "ppo_trxl", "cad_sf_trppo"):
        a = DiscretePPOAgent(cfg(algo, 44))
        b = DiscretePPOAgent(cfg(algo, 44))
        obs = np.zeros(4)
        seq_a, seq_b = [], []
        for _ in range(5):
            aa, _ = a.act(obs)
            bb, _ = b.act(obs)
            seq_a.append(aa); seq_b.append(bb)
            obs = np.eye(4)[aa]
        assert seq_a == seq_b


def test_ppo_updates_are_finite():
    for algo in ("ppo", "ppo_trxl", "cad_sf_trppo"):
        agent = DiscretePPOAgent(cfg(algo, 7))
        synthetic_episode(agent, 5)
        agent.flush()
        assert agent.gradient_updates > 0
        assert agent.ppo_updates > 0
        assert agent.last_metrics
        assert all(np.isfinite(v) for v in agent.last_metrics.values())
        for p in agent.model.parameters():
            assert torch.isfinite(p).all()


def test_trxl_memory_is_episode_scoped():
    agent = DiscretePPOAgent(cfg("ppo_trxl"))
    assert len(agent._episode_memory) == 0
    a, ev = agent.act(np.zeros(4))
    assert ev.memory is not None
    assert sum(ev.memory.mask) == 0
    assert len(agent._episode_memory) == 1
    nxt = np.eye(4)[a]
    agent.observe(np.zeros(4), a, 0.0, nxt, terminated=True, truncated=False, evaluation=ev)
    assert len(agent._episode_memory) == 0


def test_cad_has_fisher_and_residual_training_signal():
    agent = DiscretePPOAgent(cfg("cad_sf_trppo", 19))
    before = [x.clone() for x in agent._fisher_diag]
    synthetic_episode(agent, 5)
    agent.flush()
    assert agent.last_metrics["fisher_weight"] >= 0.0
    assert agent.last_metrics["entropy_coefficient"] >= 0.0
    assert agent.last_metrics["residual_loss"] >= 0.0
    assert any(not torch.equal(x, y) for x, y in zip(before, agent._fisher_diag))


def test_state_resume_preserves_next_stochastic_action():
    for algo in ("ppo", "ppo_trxl", "cad_sf_trppo"):
        a = DiscretePPOAgent(cfg(algo, 91))
        synthetic_episode(a, 3)
        state = copy.deepcopy(a.state_dict())
        b = DiscretePPOAgent(cfg(algo, 91))
        b.load_state_dict(state)
        obs = np.zeros(4)
        aa, eva = a.act(obs)
        bb, evb = b.act(obs)
        assert aa == bb
        assert np.allclose(eva.probabilities, evb.probabilities, atol=0.0, rtol=0.0)


def test_read_only_probe_is_deterministic_and_nonmutating():
    agent = DiscretePPOAgent(cfg("ppo_trxl", 5))
    synthetic_episode(agent, 5)
    state = copy.deepcopy(agent.state_dict())
    p1 = probe_ppo_agent_state(state)
    p2 = probe_ppo_agent_state(state)
    assert p1 == p2
    assert p1["uniform_any_known_probability"] == 2 / (4 ** 5)
    assert p1["any_known_exact_probability"] > 0.0
