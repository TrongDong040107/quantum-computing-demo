import numpy as np
import pytest

from qutrit_synthesis.gradients import pack_local_parameters
from qutrit_synthesis.topology import (
    number_of_entanglers,
    number_of_local_blocks,
    operations_from_kinds,
    warm_start_after_append,
)


def test_topology_template_and_counts():
    ops = operations_from_kinds(("cx_dg", "u3_q1", "cx", "u3_q0"))
    assert number_of_entanglers(ops) == 2
    assert number_of_local_blocks(ops) == 2
    np.testing.assert_array_equal(pack_local_parameters(ops), np.zeros(16))


def test_warm_start_after_append_preserves_parent_coefficients():
    parent = operations_from_kinds(("u3_q0", "cx"))
    x = np.arange(8, dtype=float) / 10.0
    child, x_child = warm_start_after_append(parent, x, "u3_q1")
    assert len(child) == 3
    np.testing.assert_allclose(x_child[:8], x, atol=0, rtol=0)
    np.testing.assert_allclose(x_child[8:], 0.0, atol=0, rtol=0)

    child2, x_child2 = warm_start_after_append(child, x_child, "cx_dg")
    assert len(child2) == 4
    np.testing.assert_allclose(x_child2, x_child, atol=0, rtol=0)


def test_invalid_fixed_append_rejects_local_initial():
    with pytest.raises(ValueError):
        warm_start_after_append((), np.zeros(0), "cx", new_local_initial=np.zeros(8))
