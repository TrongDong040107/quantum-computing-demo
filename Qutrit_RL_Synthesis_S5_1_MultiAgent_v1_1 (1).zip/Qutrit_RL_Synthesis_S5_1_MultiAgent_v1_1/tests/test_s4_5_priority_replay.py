import numpy as np
from qutrit_synthesis.ps_lstm import ReplayBuffer, ReplayItem, PSLSTMConfig

def item(p):
    return ReplayItem(observations=((0.,0.,0.,0.),), actions=(0,), glow_reward=1., sampling_priority=p)

def test_priority_fields_validate():
    PSLSTMConfig(replay_sampling='terminal_priority').validate()

def test_priority_sampling_favors_high_quality():
    b=ReplayBuffer(20)
    for _ in range(9): b.add(item(0.05))
    b.add(item(10.0))
    rng=np.random.default_rng(1)
    hits=0
    for _ in range(300):
        x=b.sample(1,rng,mode='terminal_priority',alpha=1.,epsilon=.05)[0]
        hits += x.sampling_priority > 1
    assert hits > 200

def test_uniform_sampling_not_priority_biased():
    b=ReplayBuffer(20)
    for _ in range(9): b.add(item(0.05))
    b.add(item(10.0))
    rng=np.random.default_rng(2)
    hits=sum(b.sample(1,rng,mode='uniform')[0].sampling_priority>1 for _ in range(500))
    assert 20 < hits < 100
