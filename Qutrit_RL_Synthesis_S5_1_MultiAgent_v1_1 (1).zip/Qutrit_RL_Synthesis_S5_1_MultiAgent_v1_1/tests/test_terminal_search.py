import numpy as np
from qutrit_synthesis.family_grid import periodic_uniform_grid
from qutrit_synthesis.family_objective import FamilyObjectiveConfig
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.terminal_search import (
    coarse_terminal_search, enumerate_terminal_topologies, refine_terminal_candidates,
    terminal_topology_count,
)


def cfg(mi=1):
    return OptimizerConfig(maxiter=mi,n_random_starts=0,seed=9,
        family_objective=FamilyObjectiveConfig(mode='mean_softmax',robust_weight=.6,temperature=.08))


def test_terminal_count_and_partition_enumeration():
    assert terminal_topology_count(5)==1024
    x=list(enumerate_terminal_topologies(2,start_index=3,end_index=7))
    assert [i for i,_ in x]==[3,4,5,6]
    assert len(x)==4


def test_coarse_terminal_search_deterministic():
    train=periodic_uniform_grid(3)
    a=coarse_terminal_search(2,train,optimizer_config=cfg(),start_index=0,end_index=8)
    b=coarse_terminal_search(2,train,optimizer_config=cfg(),start_index=0,end_index=8)
    assert [x.index for x in a]==[x.index for x in b]
    assert [x.objective for x in a]==[x.objective for x in b]


def test_refine_preserves_discrete_topology_and_test_is_heldout():
    train=periodic_uniform_grid(3)
    test=periodic_uniform_grid(5,phase_fraction=.5)
    coarse=coarse_terminal_search(2,train,optimizer_config=cfg(),start_index=0,end_index=8)
    refined=refine_terminal_candidates(coarse,train,test_xis=test,optimizer_config=cfg(2),top_k=3)
    assert len(refined)==3
    assert all(len(c.actions)==2 for c in refined)

from qutrit_synthesis.terminal_search import terminal_sequence_from_index

def test_index_decoder_matches_lexicographic_order():
    seqs=[s for _,s in enumerate_terminal_topologies(3,start_index=0,end_index=64)]
    for i,s in enumerate(seqs):
        assert terminal_sequence_from_index(i,3)==s
