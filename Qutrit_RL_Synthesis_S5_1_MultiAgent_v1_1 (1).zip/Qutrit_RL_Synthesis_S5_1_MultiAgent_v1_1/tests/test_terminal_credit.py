from qutrit_synthesis.terminal_credit import TerminalCreditConfig, terminal_objective_credit


def test_terminal_credit_is_strictly_monotone_in_cost():
    cfg=TerminalCreditConfig(enabled=True,temperature=0.2,scale=1.0)
    vals=[terminal_objective_credit(x,cfg) for x in (0.0,0.1,0.4,0.9)]
    assert vals[0] > vals[1] > vals[2] > vals[3] > 0
    assert abs(vals[0]-1.0)<1e-15


def test_minimum_credit_can_filter_very_bad_episodes():
    cfg=TerminalCreditConfig(enabled=True,temperature=0.1,scale=1.0,minimum_credit=0.01)
    assert terminal_objective_credit(1.0,cfg)==0.0
