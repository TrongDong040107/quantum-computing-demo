import numpy as np

from qutrit_synthesis.gradients import pack_local_parameters
from qutrit_synthesis.optimizer import OptimizerConfig, optimize_topology
from qutrit_synthesis.oracle import oracle_operations
from qutrit_synthesis.topology import operations_from_kinds


def grids():
    # Periodic domain [-pi, pi), with a disjoint half-step test grid.
    n = 13
    train = np.linspace(-np.pi, np.pi, n, endpoint=False)
    step = 2*np.pi/n
    test = train + 0.5*step
    test = ((test + np.pi) % (2*np.pi)) - np.pi
    return train, test


def oracle_topology_zero_initialized():
    return operations_from_kinds(("cx_dg", "u3_q1", "cx_dg", "u3_q1", "cx_dg"))


def test_lbfgsb_recovers_exact_family_from_zero_start():
    train, test = grids()
    result = optimize_topology(
        oracle_topology_zero_initialized(),
        train,
        test_xis=test,
        config=OptimizerConfig(maxiter=100, n_random_starts=0, seed=123),
    )
    assert result.objective_reported < 1e-12
    assert result.train_metrics.worst_infidelity < 1e-10
    assert result.test_metrics is not None
    assert result.test_metrics.worst_infidelity < 1e-10
    assert result.starts[0].final_cost_raw < result.starts[0].initial_cost


def test_optimizer_reproducible_with_seeded_random_starts():
    train, test = grids()
    cfg = OptimizerConfig(maxiter=80, n_random_starts=2, random_start_scale=0.4, seed=2026)
    a = optimize_topology(oracle_topology_zero_initialized(), train, test_xis=test, config=cfg)
    b = optimize_topology(oracle_topology_zero_initialized(), train, test_xis=test, config=cfg)
    np.testing.assert_allclose(a.parameters, b.parameters, atol=0, rtol=0)
    assert a.objective_raw == b.objective_raw
    assert a.best_start_index == b.best_start_index


def test_explicit_oracle_warm_start_is_accepted_and_exact():
    train, test = grids()
    oracle_x = pack_local_parameters(oracle_operations())
    result = optimize_topology(
        oracle_topology_zero_initialized(), train, test_xis=test,
        initial_parameters=oracle_x,
        config=OptimizerConfig(maxiter=30, coefficient_bound=4.0),
    )
    assert result.train_metrics.worst_infidelity < 1e-12
    assert result.test_metrics is not None and result.test_metrics.worst_infidelity < 1e-12


def test_fixed_only_topology_returns_without_scipy_iterations():
    train, test = grids()
    ops = operations_from_kinds(("cx", "cx_dg"))
    result = optimize_topology(ops, train, test_xis=test)
    assert result.parameters == ()
    assert result.starts[0].nit == 0
    assert result.starts[0].start_kind == "fixed_only"
