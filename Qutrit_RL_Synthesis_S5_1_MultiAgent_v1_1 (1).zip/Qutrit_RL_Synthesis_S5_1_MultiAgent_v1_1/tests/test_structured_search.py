import numpy as np

from qutrit_synthesis.family_grid import periodic_uniform_grid
from qutrit_synthesis.family_objective import FamilyObjectiveConfig
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.structured_search import BeamSearchConfig, beam_search


def small_opt():
    return OptimizerConfig(
        maxiter=1,
        n_random_starts=0,
        seed=7,
        family_objective=FamilyObjectiveConfig(mode="mean_softmax", robust_weight=0.6, temperature=0.08),
    )


def test_beam_search_is_reproducible_and_budgeted():
    train = periodic_uniform_grid(3)
    a = beam_search(train, optimizer_config=small_opt(), search_config=BeamSearchConfig(max_depth=2, beam_width=2, max_node_evaluations=8, seed=10))
    b = beam_search(train, optimizer_config=small_opt(), search_config=BeamSearchConfig(max_depth=2, beam_width=2, max_node_evaluations=8, seed=10))
    assert a.node_evaluations == b.node_evaluations == 8
    assert a.best_candidate.actions == b.best_candidate.actions
    assert a.best_candidate.objective == b.best_candidate.objective


def test_beam_never_uses_heldout_for_inner_optimization_semantics():
    train = periodic_uniform_grid(3)
    test = periodic_uniform_grid(7, phase_fraction=0.5)
    r = beam_search(train, test_xis=test, optimizer_config=small_opt(), search_config=BeamSearchConfig(max_depth=1, beam_width=4, seed=4))
    # Test metrics are intentionally computed only for train-success candidates.
    for rec in r.depth_records:
        assert rec.cumulative_node_evaluations <= 4
    if r.first_validated_success is not None:
        assert r.first_validated_success.worst_test_infidelity is not None


def test_oracle_diagnostic_does_not_change_search_result():
    train = periodic_uniform_grid(3)
    cfg = BeamSearchConfig(max_depth=2, beam_width=4, seed=3)
    a = beam_search(train, optimizer_config=small_opt(), search_config=cfg)
    b = beam_search(train, optimizer_config=small_opt(), search_config=cfg, oracle_actions_for_diagnostics=(3,1,3,1,3))
    assert a.best_candidate.actions == b.best_candidate.actions
    assert a.best_candidate.objective == b.best_candidate.objective

from qutrit_synthesis.structured_search import StratifiedBeamSearchConfig, stratified_beam_search


def test_stratified_search_reproducible_small_case():
    train = periodic_uniform_grid(3)
    cfg = StratifiedBeamSearchConfig(max_depth=2, per_stratum=1, max_beam_width=8, max_node_evaluations=12, seed=12)
    a = stratified_beam_search(train, optimizer_config=small_opt(), search_config=cfg)
    b = stratified_beam_search(train, optimizer_config=small_opt(), search_config=cfg)
    assert a.node_evaluations == b.node_evaluations == 12
    assert a.best_candidate.actions == b.best_candidate.actions
    assert a.best_candidate.objective == b.best_candidate.objective
