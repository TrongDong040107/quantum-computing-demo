import copy
import numpy as np
import pytest

from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import (
    ACTION_KINDS,
    ACTION_TO_KIND,
    KIND_TO_ACTION,
    EnvironmentConfig,
    QutritSynthesisEnv,
)
from qutrit_synthesis.optimizer import OptimizerConfig


def grids(n=7):
    train = np.linspace(-np.pi, np.pi, n, endpoint=False)
    step = 2*np.pi/n
    test = ((train + 0.5*step + np.pi) % (2*np.pi)) - np.pi
    return train, test


def strict_cfg(max_steps=6, observation_mode="last_action", random_starts=0):
    return EnvironmentConfig(
        max_steps=max_steps,
        observation_mode=observation_mode,
        optimizer=OptimizerConfig(maxiter=100, n_random_starts=random_starts, seed=999),
        curriculum=CurriculumConfig(
            min_threshold=1e-10,
            initial_threshold=1e-10,
            update_window=100,
        ),
    )


def test_action_mapping_is_canonical_and_bijective():
    assert ACTION_KINDS == ("u3_q0", "u3_q1", "cx", "cx_dg")
    for i, kind in enumerate(ACTION_KINDS):
        assert ACTION_TO_KIND[i] == kind
        assert KIND_TO_ACTION[kind] == i


def test_reset_last_action_observation_is_zero_vector():
    train, test = grids()
    env = QutritSynthesisEnv(train, test_xis=test, config=strict_cfg())
    obs, info = env.reset(seed=123)
    assert obs.shape == (4,)
    np.testing.assert_array_equal(obs, np.zeros(4))
    assert info["topology"] == []
    assert info["episode_seed"] == 123


def test_one_action_appends_exactly_one_gate_and_no_merge():
    train, test = grids(5)
    env = QutritSynthesisEnv(train, test_xis=test, config=strict_cfg(max_steps=4))
    env.reset(seed=1)
    a = KIND_TO_ACTION["cx_dg"]
    obs, _, term, trunc, info = env.step(a)
    assert not term and not trunc
    assert info["topology"] == ["cx_dg"]
    assert obs[a] == 1.0 and obs.sum() == 1.0
    obs, _, term, trunc, info = env.step(a)
    assert info["topology"] == ["cx_dg", "cx_dg"]
    # Deliberately no source-style automatic same-type gate merging.
    assert env.step_count == 2


def test_local_action_adds_eight_parameters_and_warm_start_ownership():
    train, test = grids(5)
    env = QutritSynthesisEnv(train, test_xis=test, config=strict_cfg(max_steps=3))
    env.reset(seed=10)
    env.step(KIND_TO_ACTION["u3_q0"])
    p1 = env.parameters
    assert p1.shape == (8,)
    env.step(KIND_TO_ACTION["cx"])
    p2 = env.parameters
    assert p2.shape == (8,)
    # A fixed entangler creates no continuous coefficients; the optimizer may
    # refine the existing block, but parameter ownership/count cannot change.
    assert env.operation_kinds == ("u3_q0", "cx")


def test_history_padded_observation():
    train, test = grids(5)
    env = QutritSynthesisEnv(train, test_xis=test, config=strict_cfg(max_steps=4, observation_mode="history_padded"))
    obs, _ = env.reset(seed=2)
    assert obs.shape == (4, 4)
    assert obs.sum() == 0
    env.step(2)
    obs, *_ = env.step(1)
    assert obs[0,2] == 1 and obs[1,1] == 1
    assert obs[2:].sum() == 0


def test_invalid_actions_rejected():
    train, _ = grids(5)
    env = QutritSynthesisEnv(train, config=strict_cfg())
    env.reset(seed=0)
    for bad in (-1, 4, 1.5, "1"):
        with pytest.raises(ValueError):
            env.step(bad)  # type: ignore[arg-type]


def test_truncation_at_max_steps_when_threshold_not_reached():
    train, test = grids(5)
    cfg = EnvironmentConfig(
        max_steps=2,
        optimizer=OptimizerConfig(maxiter=20),
        curriculum=CurriculumConfig(min_threshold=1e-14, initial_threshold=1e-14, update_window=50),
    )
    env = QutritSynthesisEnv(train, test_xis=test, config=cfg)
    env.reset(seed=3)
    _, _, t1, tr1, _ = env.step(KIND_TO_ACTION["cx"])
    assert not t1 and not tr1
    _, _, t2, tr2, _ = env.step(KIND_TO_ACTION["cx"])
    assert not t2 and tr2
    with pytest.raises(RuntimeError):
        env.step(0)


def test_oracle_action_sequence_reaches_machine_precision_family_solution():
    train, test = grids(13)
    env = QutritSynthesisEnv(train, test_xis=test, config=strict_cfg(max_steps=5))
    env.reset(seed=20260910)
    seq = ["cx_dg", "u3_q1", "cx_dg", "u3_q1", "cx_dg"]
    terminal_info = None
    for i, kind in enumerate(seq):
        obs, reward, terminated, truncated, info = env.step(KIND_TO_ACTION[kind])
        if i < len(seq)-1:
            assert not terminated
            assert not truncated
        terminal_info = info
    assert terminal_info is not None
    assert terminated and not truncated
    assert reward == 10.0
    assert terminal_info["train_metrics"]["worst_infidelity"] < 1e-10
    assert terminal_info["test_metrics"]["worst_infidelity"] < 1e-10
    assert env.operation_kinds == tuple(seq)


def test_same_seed_same_actions_exact_reproducibility():
    train, test = grids(7)
    cfg = strict_cfg(max_steps=5, random_starts=1)
    seq = [3,1,3]
    traces = []
    for _ in range(2):
        env = QutritSynthesisEnv(train, test_xis=test, config=cfg)
        env.reset(seed=77)
        t=[]
        for a in seq:
            out=env.step(a)
            t.append((out[1], out[2], out[3], out[4]["objective"], tuple(env.parameters)))
        traces.append(t)
    assert traces[0] == traces[1]


def test_environment_state_roundtrip_continuation_exact():
    train, test = grids(7)
    cfg = strict_cfg(max_steps=5, random_starts=1)
    a = QutritSynthesisEnv(train, test_xis=test, config=cfg)
    a.reset(seed=31415)
    a.step(3)
    a.step(1)
    state = copy.deepcopy(a.state_dict())

    b = QutritSynthesisEnv(train, test_xis=test, config=cfg)
    b.load_state_dict(state)
    out_a = a.step(3)
    out_b = b.step(3)
    np.testing.assert_array_equal(out_a[0], out_b[0])
    assert out_a[1:4] == out_b[1:4]
    assert out_a[4]["objective"] == out_b[4]["objective"]
    np.testing.assert_array_equal(a.parameters, b.parameters)
    assert a.state_dict()["rng_state"] == b.state_dict()["rng_state"]


def test_reset_curriculum_option_is_explicit():
    train, _ = grids(5)
    cfg = EnvironmentConfig(
        max_steps=1,
        optimizer=OptimizerConfig(maxiter=10),
        curriculum=CurriculumConfig(min_threshold=.01, initial_threshold=1.0, update_window=1),
    )
    env = QutritSynthesisEnv(train, config=cfg)
    env.reset(seed=0)
    env.step(2)
    assert env.curriculum.total_episodes == 1
    env.reset(seed=1)
    assert env.curriculum.total_episodes == 1
    env.reset(seed=1, options={"reset_curriculum": True})
    assert env.curriculum.total_episodes == 0


def test_oracle_final_step_uses_zero_restart_safeguard():
    train, test = grids(9)
    env = QutritSynthesisEnv(train, test_xis=test, config=strict_cfg(max_steps=5))
    env.reset(seed=909)
    info = None
    for kind in ("cx_dg", "u3_q1", "cx_dg", "u3_q1", "cx_dg"):
        *_, info = env.step(KIND_TO_ACTION[kind])
    assert info is not None
    assert info["zero_restart_used"] is True
    assert info["optimizer_n_starts"] == 2
    assert info["train_metrics"]["worst_infidelity"] < 1e-10


def test_deferred_test_evaluation_only_reports_at_episode_end():
    train=np.linspace(-np.pi,np.pi,3,endpoint=False)
    test=np.linspace(-np.pi,np.pi,7,endpoint=False)+0.013
    cfg=EnvironmentConfig(
        max_steps=2,
        optimizer=OptimizerConfig(maxiter=2,n_random_starts=0,seed=3),
        curriculum=CurriculumConfig(min_threshold=1e-12,initial_threshold=1e-12,update_window=100),
        defer_test_evaluation=True,
    )
    env=QutritSynthesisEnv(train,test_xis=test,config=cfg)
    env.reset(seed=5)
    _,_,term,trunc,info1=env.step(2)
    assert not (term or trunc)
    assert info1['test_metrics'] is None
    _,_,term,trunc,info2=env.step(2)
    assert term or trunc
    assert info2['test_metrics'] is not None
    assert info2['test_metrics']['n_points']==7
