import copy
import numpy as np
import torch
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig
from tools.convergence_probe import probe_agent_state


def test_probe_uniform_at_initialization():
    a=CorrectedPSLSTMAgent(PSLSTMConfig(hidden_size=8,num_layers=2,batch_size=2,min_replay_size=2,seed=123))
    r=probe_agent_state(a.state_dict())
    assert np.isclose(r['any_known_exact_probability'],2/1024,atol=1e-12)
    for s in r['sequences']:
        assert np.allclose(s['step_probabilities'],[0.25]*5,atol=1e-12)


def test_probe_does_not_mutate_serialized_state():
    a=CorrectedPSLSTMAgent(PSLSTMConfig(hidden_size=8,num_layers=2,batch_size=2,min_replay_size=2,seed=321))
    before=a.state_dict()
    _=probe_agent_state(before)
    after=a.state_dict()
    assert before['interactions']==after['interactions']
    assert before['episodes']==after['episodes']
    assert before['torch_rng_state'].equal(after['torch_rng_state'])
    assert before['np_rng_state']==after['np_rng_state']
