import numpy as np
import pytest

from qutrit_synthesis.circuit import Operation, circuit_parameter_derivative, circuit_unitary


def test_empty_circuit_is_identity():
    np.testing.assert_allclose(circuit_unitary([], 0.5), np.eye(9), atol=0, rtol=0)


def test_circuit_parameter_derivative_matches_matrix_finite_difference():
    rng = np.random.default_rng(7)
    p0 = rng.normal(scale=0.2, size=8)
    p1 = rng.normal(scale=0.2, size=8)
    ops = (
        Operation.local("u3_q0", p0),
        Operation.fixed("cx"),
        Operation.local("u3_q1", p1),
    )
    xi = 0.83
    eps = 1e-7
    for op_index in [0, 2]:
        for k in range(8):
            analytic = circuit_parameter_derivative(ops, xi, op_index, k)
            base = np.array(ops[op_index].params, dtype=float)
            plus = base.copy(); plus[k] += eps
            minus = base.copy(); minus[k] -= eps
            ops_plus = list(ops); ops_plus[op_index] = Operation.local(ops[op_index].kind, plus)
            ops_minus = list(ops); ops_minus[op_index] = Operation.local(ops[op_index].kind, minus)
            numeric = (circuit_unitary(ops_plus, xi) - circuit_unitary(ops_minus, xi)) / (2*eps)
            np.testing.assert_allclose(analytic, numeric, atol=3e-8, rtol=3e-7)


def test_fixed_gate_has_no_trainable_derivative():
    ops = (Operation.fixed("cx"),)
    with pytest.raises(ValueError):
        circuit_parameter_derivative(ops, 0.4, 0, 0)
