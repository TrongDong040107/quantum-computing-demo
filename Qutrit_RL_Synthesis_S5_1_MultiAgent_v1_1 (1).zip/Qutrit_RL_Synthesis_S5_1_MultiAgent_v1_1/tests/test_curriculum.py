import numpy as np
import pytest

from qutrit_synthesis.curriculum import Curriculum, CurriculumConfig


def test_sparse_reward_boundaries():
    c = Curriculum(CurriculumConfig(min_threshold=0.01, initial_threshold=0.2, update_window=3))
    assert c.reward(0.3) == 0.0
    assert c.reward(0.2) == 2.0
    assert c.reward(0.0100001) == 2.0
    assert c.reward(0.01) == 10.0
    assert c.reward(0.0) == 10.0


def test_curriculum_convex_update_matches_source_semantics():
    c = Curriculum(CurriculumConfig(min_threshold=0.01, initial_threshold=1.0, delta=0.5, update_window=3))
    assert not c.observe_episode(0.8)
    assert not c.observe_episode(0.4)
    assert c.observe_episode(0.2)
    assert c.threshold == pytest.approx(0.6)  # 0.2 + .5*(1-.2)
    assert c.total_updates == 1


def test_curriculum_never_goes_below_min_threshold():
    c = Curriculum(CurriculumConfig(min_threshold=0.01, initial_threshold=0.02, delta=0.0, update_window=1))
    c.observe_episode(0.0)
    assert c.threshold == pytest.approx(0.01)


def test_curriculum_roundtrip_state():
    cfg = CurriculumConfig(min_threshold=0.01, initial_threshold=0.4, update_window=3)
    a = Curriculum(cfg)
    a.observe_episode(0.3)
    a.observe_episode(0.25)
    state = a.state_dict()
    b = Curriculum(cfg)
    b.load_state_dict(state)
    assert b.state_dict() == state


def test_curriculum_rejects_nonfinite_cost():
    c = Curriculum()
    with pytest.raises(ValueError):
        c.reward(np.nan)
