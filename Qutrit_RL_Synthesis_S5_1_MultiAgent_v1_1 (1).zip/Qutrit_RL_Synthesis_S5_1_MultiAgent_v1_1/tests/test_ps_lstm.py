import copy
from pathlib import Path

import numpy as np
import torch

from qutrit_synthesis.ps_lstm import (
    CorrectedPSLSTMAgent,
    PSLSTMConfig,
    PSLSTMNetwork,
    ReplayBuffer,
    ReplayItem,
)


def tiny_cfg(**kw):
    base = dict(
        obs_dim=4,
        action_dim=4,
        hidden_size=16,
        num_layers=2,
        learning_rate=1e-2,
        batch_size=4,
        replay_capacity=32,
        min_replay_size=4,
        train_every_interactions=100,
        target_update_interactions=50,
        gamma_damping=1e-3,
        eta_glow=0.1,
        beta_start=1e-3,
        beta_end=1.0,
        beta_anneal_episodes=10,
        seed=1234,
        device="cpu",
    )
    base.update(kw)
    return PSLSTMConfig(**base)


def obs_for_prev(prev=None):
    x=np.zeros(4,dtype=float)
    if prev is not None:
        x[int(prev)] = 1.0
    return x


def add_success_episode(agent, actions=(3,1,3,1), reward=10.0):
    prev=None
    for i,a in enumerate(actions):
        obs=obs_for_prev(prev)
        done=i==len(actions)-1
        agent.observe(obs,a,reward if done else 0.0,terminated=done,truncated=False,success=done)
        prev=a


def test_default_architecture_matches_reported_two_layer_lstm():
    cfg=PSLSTMConfig()
    assert cfg.num_layers == 2
    assert cfg.hidden_size == 128
    assert cfg.batch_size == 64
    assert cfg.learning_rate == 1e-2
    net=PSLSTMNetwork(cfg)
    assert net.lstm.num_layers == 2
    assert net.lstm.hidden_size == 128


def test_initial_h_values_are_exactly_one_and_policy_uniform():
    a=CorrectedPSLSTMAgent(tiny_cfg())
    ev=a.evaluate_actions(np.zeros(4))
    np.testing.assert_allclose(ev.h_values, np.ones(4), atol=0, rtol=0)
    np.testing.assert_allclose(ev.probabilities, np.full(4,.25), atol=1e-7)


def test_beta_linear_schedule_uses_episode_counter():
    a=CorrectedPSLSTMAgent(tiny_cfg(beta_anneal_episodes=10))
    assert a.beta == 1e-3
    a.episodes=5
    assert np.isclose(a.beta, 1e-3 + .5*(1-1e-3))
    a.episodes=10
    assert a.beta == 1.0
    a.episodes=999
    assert a.beta == 1.0


def test_only_sampled_candidate_state_is_propagated():
    a=CorrectedPSLSTMAgent(tiny_cfg(seed=55))
    obs=np.array([0.,0.,0.,0.])
    scores, next_state = a._candidate_scores_and_states(obs)
    action,_=a.act(obs, deterministic=False)
    h,c=a._hidden
    np.testing.assert_allclose(h.detach().numpy(), next_state[0][:,action:action+1,:].detach().numpy())
    np.testing.assert_allclose(c.detach().numpy(), next_state[1][:,action:action+1,:].detach().numpy())


def test_glow_backward_credit_formula():
    got=CorrectedPSLSTMAgent.glow_rewards(4,10.0,.1)
    expected=10*np.array([.9**3,.9**2,.9,1.0])
    np.testing.assert_allclose(got,expected)


def test_gamma_damping_is_present_in_fitted_target():
    old=torch.tensor([3.0, .5])
    glow=torch.tensor([2.0, 0.0])
    got=CorrectedPSLSTMAgent.fitted_ps_target(old,glow,.1)
    expected=old-.1*(old-1)+glow
    torch.testing.assert_close(got,expected)


def test_replay_roundtrip_and_deterministic_sample():
    buf=ReplayBuffer(4)
    for k in range(4):
        buf.add(ReplayItem((tuple(obs_for_prev(None)),),(k,),float(k)))
    state=buf.state_dict()
    b=ReplayBuffer(4)
    b.load_state_dict(state,obs_dim=4,action_dim=4)
    assert b.state_dict()==state
    r1=np.random.default_rng(9); r2=np.random.default_rng(9)
    assert [x.actions for x in buf.sample(3,r1)] == [x.actions for x in b.sample(3,r2)]


def test_target_sync_is_counted_by_interactions_not_gradient_updates():
    a=CorrectedPSLSTMAgent(tiny_cfg(target_update_interactions=3,min_replay_size=30))
    for i in range(2):
        info=a.observe(obs_for_prev(None),0,0.0,terminated=False,truncated=False,success=False)
        assert not info["target_synced"]
    info=a.observe(obs_for_prev(None),1,0.0,terminated=False,truncated=False,success=False)
    assert info["target_synced"]
    assert a.target_syncs == 1
    assert a.interactions == 3
    assert a.gradient_updates == 0


def test_success_episode_populates_prefix_replay_and_trains_when_ready():
    a=CorrectedPSLSTMAgent(tiny_cfg(min_replay_size=4,batch_size=4))
    add_success_episode(a,actions=(3,1,3,1),reward=10.0)
    assert len(a.replay)==4
    assert a.successful_episodes==1
    assert a.episodes==1
    assert a.gradient_updates==1
    assert np.isfinite(a.last_train_loss)


def test_failed_episode_not_stored_by_default():
    a=CorrectedPSLSTMAgent(tiny_cfg())
    a.observe(obs_for_prev(None),2,0.0,terminated=False,truncated=False,success=False)
    a.observe(obs_for_prev(2),2,0.0,terminated=False,truncated=True,success=False)
    assert len(a.replay)==0
    assert a.episodes==1


def test_model_parameters_change_after_positive_replay_training():
    a=CorrectedPSLSTMAgent(tiny_cfg(min_replay_size=4,batch_size=4))
    before={k:v.detach().clone() for k,v in a.network.state_dict().items()}
    add_success_episode(a,actions=(3,1,3,1),reward=10.0)
    assert any(not torch.equal(before[k],v) for k,v in a.network.state_dict().items())


def test_local_rng_does_not_consume_torch_global_rng_during_sampling():
    torch.manual_seed(777)
    before=torch.random.get_rng_state().clone()
    a=CorrectedPSLSTMAgent(tiny_cfg(seed=999))
    _=a.act(np.zeros(4))
    after=torch.random.get_rng_state().clone()
    torch.testing.assert_close(before,after)


def test_state_dict_exact_resume_preserves_next_action_and_hidden_state():
    cfg=tiny_cfg(seed=81)
    a=CorrectedPSLSTMAgent(cfg)
    obs0=np.zeros(4)
    act0,_=a.act(obs0)
    a.observe(obs0,act0,0.0,terminated=False,truncated=False,success=False)
    state=copy.deepcopy(a.state_dict())

    b=CorrectedPSLSTMAgent(cfg)
    b.load_state_dict(state)
    obs1=obs_for_prev(act0)
    aa,_=a.act(obs1); bb,_=b.act(obs1)
    assert aa==bb
    ah,ac=a.hidden_state_numpy(); bh,bc=b.hidden_state_numpy()
    np.testing.assert_array_equal(ah,bh); np.testing.assert_array_equal(ac,bc)


def test_checkpoint_exact_resume_includes_optimizer_replay_and_rng(tmp_path: Path):
    cfg=tiny_cfg(seed=42,min_replay_size=4,batch_size=4)
    a=CorrectedPSLSTMAgent(cfg)
    add_success_episode(a,actions=(3,1,3,1),reward=10.0)
    path=tmp_path/'learner.pt'
    a.save_checkpoint(path)
    b=CorrectedPSLSTMAgent(cfg)
    b.load_checkpoint(path)
    assert a.interactions==b.interactions
    assert a.episodes==b.episodes
    assert a.gradient_updates==b.gradient_updates
    assert a.replay.state_dict()==b.replay.state_dict()
    # Next replay sample and Adam update must match exactly.
    la=a.train_step(); lb=b.train_step()
    assert la==lb
    for (ka,va),(kb,vb) in zip(a.network.state_dict().items(),b.network.state_dict().items()):
        assert ka==kb
        torch.testing.assert_close(va,vb,rtol=0,atol=0)


def test_config_mismatch_rejected_on_resume():
    a=CorrectedPSLSTMAgent(tiny_cfg(seed=1))
    state=a.state_dict()
    b=CorrectedPSLSTMAgent(tiny_cfg(seed=2))
    try:
        b.load_state_dict(state)
    except ValueError as e:
        assert "config mismatch" in str(e)
    else:
        raise AssertionError("expected config mismatch")

def test_mid_episode_periodic_update_recomputes_hidden_under_new_weights():
    # First create replay with a completed successful 4-step episode. The next
    # interaction is #5 and therefore triggers the periodic learner update in
    # the middle of a new episode.
    cfg=tiny_cfg(
        seed=101,
        min_replay_size=4,
        batch_size=4,
        train_every_interactions=5,
    )
    a=CorrectedPSLSTMAgent(cfg)
    add_success_episode(a,actions=(3,1,3,1),reward=10.0)
    assert a.interactions==4 and len(a.replay)==4
    obs=np.zeros(4)
    action,_=a.act(obs,deterministic=True)
    info=a.observe(obs,action,0.0,terminated=False,truncated=False,success=False)
    assert info["trained"]
    assert a.interactions==5
    # Independent replay of the chosen prefix under the UPDATED network.
    zero=a.network.zero_state(1,a.device)
    obs_t=torch.tensor(obs,dtype=torch.float32).view(1,1,-1)
    act_t=torch.zeros((1,1,4),dtype=torch.float32); act_t[0,0,action]=1
    x=torch.cat([obs_t,act_t],dim=-1)
    with torch.no_grad():
        _, expected=a.network(x,zero)
    torch.testing.assert_close(a._hidden[0],expected[0],rtol=0,atol=0)
    torch.testing.assert_close(a._hidden[1],expected[1],rtol=0,atol=0)
