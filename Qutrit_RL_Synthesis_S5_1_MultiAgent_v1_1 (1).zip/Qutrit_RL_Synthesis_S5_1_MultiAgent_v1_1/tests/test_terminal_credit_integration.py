import numpy as np
from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, QutritSynthesisEnv
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig
from qutrit_synthesis.terminal_credit import TerminalCreditConfig
from qutrit_synthesis.trainer import run_episode


def test_terminal_credit_populates_replay_without_changing_env_success():
    train=np.linspace(-np.pi,np.pi,3,endpoint=False)
    env=QutritSynthesisEnv(
        train,
        config=EnvironmentConfig(
            max_steps=1,
            optimizer=OptimizerConfig(maxiter=2,n_random_starts=0,seed=4),
            curriculum=CurriculumConfig(min_threshold=1e-12,initial_threshold=1e-12,update_window=100),
        ),
    )
    agent=CorrectedPSLSTMAgent(PSLSTMConfig(
        hidden_size=8,num_layers=2,batch_size=1,min_replay_size=1,replay_capacity=32,
        train_every_interactions=100,target_update_interactions=50,seed=9,
    ))
    rec=run_episode(
        env,agent,seed=123,deterministic_policy=True,
        terminal_credit=TerminalCreditConfig(enabled=True,temperature=0.2,scale=1.0),
    )
    assert not rec.final_success
    assert rec.rewards==(0.0,)
    assert rec.auxiliary_terminal_credit is not None and rec.auxiliary_terminal_credit > 0
    assert len(agent.replay)==1
    assert agent.gradient_updates==1
