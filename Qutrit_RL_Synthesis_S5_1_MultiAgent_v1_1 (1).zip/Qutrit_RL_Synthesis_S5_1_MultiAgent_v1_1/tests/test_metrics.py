import numpy as np

from qutrit_synthesis.metrics import evaluate_family, family_fidelities
from qutrit_synthesis.oracle import oracle_operations


def test_oracle_metrics_are_perfect_on_dense_grid():
    xis = np.linspace(-np.pi, np.pi, 101, endpoint=False)
    vals = family_fidelities(oracle_operations(), xis)
    assert vals.shape == (101,)
    assert np.min(vals) > 1.0 - 1e-12
    m = evaluate_family(oracle_operations(), xis)
    assert m.min_fidelity > 1.0 - 1e-12
    assert m.worst_infidelity < 1e-12
