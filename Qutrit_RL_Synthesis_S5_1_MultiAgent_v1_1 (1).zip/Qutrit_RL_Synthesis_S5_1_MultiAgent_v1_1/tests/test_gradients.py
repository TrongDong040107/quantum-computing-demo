import numpy as np

from qutrit_synthesis.circuit import Operation, circuit_unitary
from qutrit_synthesis.fidelity import gate_fidelity
from qutrit_synthesis.gates import u3, u3_parameter_derivative
from qutrit_synthesis.gradients import (
    family_mean_cost,
    family_mean_gradient,
    pack_local_parameters,
    with_packed_local_parameters,
)
from qutrit_synthesis.target import target_unitary


def central_difference_matrix(fun, x, eps=1e-7):
    return (fun(x + eps) - fun(x - eps)) / (2 * eps)


def test_u3_shift_gradient_matches_finite_difference():
    rng = np.random.default_rng(3)
    for _ in range(30):
        p = rng.normal(scale=0.7, size=8)
        xi = float(rng.uniform(-2.0, 2.0))
        for k in range(8):
            analytic = u3_parameter_derivative(xi, p, k)
            def f(value):
                q = p.copy(); q[k] = value
                return u3(xi, q)
            numeric = central_difference_matrix(f, p[k])
            np.testing.assert_allclose(analytic, numeric, atol=2e-8, rtol=2e-7)


def _example_ops(rng):
    return (
        Operation.local("u3_q0", rng.normal(scale=0.3, size=8)),
        Operation.fixed("cx"),
        Operation.local("u3_q1", rng.normal(scale=0.3, size=8)),
        Operation.fixed("cx_dg"),
    )


def test_family_gradient_matches_finite_difference():
    rng = np.random.default_rng(4)
    ops = _example_ops(rng)
    xis = np.array([-1.3, -0.4, 0.2, 0.9, 1.7])
    packed = pack_local_parameters(ops)
    analytic = family_mean_gradient(ops, xis)
    numeric = np.zeros_like(analytic)
    eps = 2e-7
    for i in range(packed.size):
        plus = packed.copy(); plus[i] += eps
        minus = packed.copy(); minus[i] -= eps
        numeric[i] = (
            family_mean_cost(with_packed_local_parameters(ops, plus), xis)
            - family_mean_cost(with_packed_local_parameters(ops, minus), xis)
        ) / (2*eps)
    np.testing.assert_allclose(analytic, numeric, atol=5e-8, rtol=3e-6)


def test_global_phase_invariance_of_fidelity():
    rng = np.random.default_rng(5)
    ops = _example_ops(rng)
    xi = 0.71
    v = circuit_unitary(ops, xi)
    u = target_unitary(xi)
    f0 = gate_fidelity(u, v)
    f1 = gate_fidelity(u, np.exp(1j*0.37) * v)
    assert abs(f0 - f1) < 1e-14


def test_all_local_parameter_gradients_vanish_at_xi_zero():
    rng = np.random.default_rng(8)
    p = rng.normal(size=8)
    for k in range(8):
        np.testing.assert_allclose(u3_parameter_derivative(0.0, p, k), np.zeros((3,3)), atol=0, rtol=0)


def test_cached_joint_gradient_matches_public_gradient_and_cost():
    from qutrit_synthesis.gradients import family_mean_cost_and_gradient
    rng = np.random.default_rng(44)
    ops = _example_ops(rng)
    xis = np.array([-1.7, -0.8, 0.0, 0.33, 1.1])
    cost_joint, grad_joint = family_mean_cost_and_gradient(ops, xis)
    np.testing.assert_allclose(cost_joint, family_mean_cost(ops, xis), atol=2e-16, rtol=0)
    np.testing.assert_allclose(grad_joint, family_mean_gradient(ops, xis), atol=0, rtol=0)
