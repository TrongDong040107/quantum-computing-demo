import numpy as np

from qutrit_synthesis.fidelity import gate_fidelity
from qutrit_synthesis.oracle import oracle_operations, oracle_unitary, dual_oracle_operations, dual_oracle_unitary
from qutrit_synthesis.target import target_unitary


def test_oracle_has_five_operations_and_three_entanglers():
    ops = oracle_operations()
    assert len(ops) == 5
    assert sum(op.kind == "cx_dg" for op in ops) == 3
    assert sum(op.kind.startswith("u3_") for op in ops) == 2


def test_oracle_exact_family_identity_up_to_global_phase():
    rng = np.random.default_rng(6)
    xis = np.concatenate([
        np.array([0.0, np.pi, -np.pi, 2*np.pi]),
        rng.uniform(-np.pi, np.pi, 1000),
    ])
    for xi in xis:
        trial = oracle_unitary(float(xi))
        target = target_unitary(float(xi))
        np.testing.assert_allclose(
            trial,
            np.exp(-1j * float(xi)) * target,
            atol=2e-12,
            rtol=0,
        )
        assert gate_fidelity(target, trial) > 1.0 - 1e-12


def test_dual_cx_oracle_exact_family_identity_up_to_global_phase():
    ops = dual_oracle_operations()
    assert [op.kind for op in ops] == ["cx","u3_q1","cx","u3_q1","cx"]
    rng=np.random.default_rng(20260911)
    for xi in np.concatenate([np.array([0.0,np.pi,-np.pi]),rng.uniform(-np.pi,np.pi,300)]):
        trial=dual_oracle_unitary(float(xi))
        target=target_unitary(float(xi))
        np.testing.assert_allclose(trial,np.exp(-1j*float(xi))*target,atol=2e-12,rtol=0)
        assert gate_fidelity(target,trial) > 1.0-1e-12
