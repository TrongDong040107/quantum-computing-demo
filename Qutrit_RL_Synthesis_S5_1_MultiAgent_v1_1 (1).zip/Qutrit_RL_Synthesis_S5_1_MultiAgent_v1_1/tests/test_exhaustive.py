import numpy as np

from qutrit_synthesis.environment import ACTION_KINDS
from qutrit_synthesis.exhaustive import enumerate_topologies, exhaustive_search
from qutrit_synthesis.optimizer import OptimizerConfig


def test_exhaustive_enumeration_counts_and_order():
    items = list(enumerate_topologies(3))
    assert len(items) == 4 + 16 + 64
    assert items[0] == (ACTION_KINDS[0],)
    assert items[3] == (ACTION_KINDS[3],)
    assert items[4] == (ACTION_KINDS[0], ACTION_KINDS[0])
    assert items[-1] == (ACTION_KINDS[-1],)*3


def test_exhaustive_no_implicit_pruning_or_merging():
    items = set(enumerate_topologies(2, min_depth=2))
    assert ("cx", "cx") in items
    assert ("u3_q0", "u3_q0") in items
    assert ("cx", "cx_dg") in items


def test_depth_one_search_is_deterministic_and_ranked():
    train = np.linspace(-np.pi, np.pi, 5, endpoint=False)
    cfg = OptimizerConfig(maxiter=20, n_random_starts=0, seed=9)
    a = exhaustive_search(1, train, optimizer_config=cfg)
    b = exhaustive_search(1, train, optimizer_config=cfg)
    assert [x.to_dict() for x in a] == [x.to_dict() for x in b]
    assert len(a) == 4
    keys = [(x.mean_infidelity, x.worst_train_infidelity, x.n_entanglers, len(x.kinds), x.kinds) for x in a]
    assert keys == sorted(keys)
