import copy
import numpy as np

from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, QutritSynthesisEnv
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig
from qutrit_synthesis.trainer import run_episode


def grids(n=3):
    train=np.linspace(-np.pi,np.pi,n,endpoint=False)
    test=train + np.pi/n
    return train,test


def env_cfg(max_steps=2):
    return EnvironmentConfig(
        max_steps=max_steps,
        optimizer=OptimizerConfig(maxiter=5,n_random_starts=0,seed=10),
        curriculum=CurriculumConfig(
            min_threshold=1e-12,
            initial_threshold=1e-12,
            update_window=100,
        ),
    )


def agent_cfg(seed=7):
    return PSLSTMConfig(
        hidden_size=8,
        num_layers=2,
        batch_size=4,
        replay_capacity=32,
        min_replay_size=4,
        train_every_interactions=100,
        target_update_interactions=50,
        seed=seed,
    )


def test_real_environment_policy_smoke_no_crash():
    train,test=grids()
    env=QutritSynthesisEnv(train,test_xis=test,config=env_cfg(max_steps=2))
    agent=CorrectedPSLSTMAgent(agent_cfg(seed=19))
    result=run_episode(env,agent,seed=123)
    assert len(result.actions) in (1,2)
    assert result.terminated or result.truncated
    assert np.isfinite(result.final_objective)
    assert agent.interactions==len(result.actions)


def test_env_plus_learner_mid_episode_exact_resume():
    train,test=grids()
    ecfg=env_cfg(max_steps=3)
    acfg=agent_cfg(seed=22)
    ea=QutritSynthesisEnv(train,test_xis=test,config=ecfg)
    aa=CorrectedPSLSTMAgent(acfg)
    obs,_=ea.reset(seed=456)
    aa.reset_recurrent_state()

    obs_before=obs.copy(); action,_=aa.act(obs_before)
    obs,reward,term,trunc,info=ea.step(action)
    assert not (term or trunc)
    aa.observe(obs_before,action,reward,terminated=term,truncated=trunc,success=False)

    env_state=copy.deepcopy(ea.state_dict())
    agent_state=copy.deepcopy(aa.state_dict())

    eb=QutritSynthesisEnv(train,test_xis=test,config=ecfg)
    eb.load_state_dict(env_state)
    ab=CorrectedPSLSTMAgent(acfg)
    ab.load_state_dict(agent_state)

    obs_a=ea._observation(); obs_b=eb._observation()
    np.testing.assert_array_equal(obs_a,obs_b)
    act_a,_=aa.act(obs_a); act_b,_=ab.act(obs_b)
    assert act_a==act_b
    out_a=ea.step(act_a); out_b=eb.step(act_b)
    np.testing.assert_array_equal(out_a[0],out_b[0])
    assert out_a[1:4]==out_b[1:4]
    assert out_a[4]["objective"]==out_b[4]["objective"]
