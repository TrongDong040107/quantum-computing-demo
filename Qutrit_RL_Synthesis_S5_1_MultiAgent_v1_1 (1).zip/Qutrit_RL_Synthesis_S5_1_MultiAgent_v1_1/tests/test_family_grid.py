import numpy as np
from qutrit_synthesis.family_grid import periodic_uniform_grid, minimum_periodic_separation


def test_periodic_grid_is_reproducible_and_in_interval():
    a=periodic_uniform_grid(9,phase_fraction=0.0)
    b=periodic_uniform_grid(9,phase_fraction=0.0)
    np.testing.assert_array_equal(a,b)
    assert np.all(a >= -np.pi) and np.all(a < np.pi)
    assert len(np.unique(a))==9


def test_shifted_dense_grid_is_disjoint():
    train=periodic_uniform_grid(9,phase_fraction=0.0)
    test=periodic_uniform_grid(73,phase_fraction=0.5)
    assert minimum_periodic_separation(train,test) > 1e-5
