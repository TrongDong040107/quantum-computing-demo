import numpy as np

from qutrit_synthesis.circuit import Operation
from qutrit_synthesis.family_objective import (
    FamilyObjectiveConfig,
    family_objective_cost_and_gradient,
)
from qutrit_synthesis.gradients import (
    family_mean_cost_and_gradient,
    pack_local_parameters,
    with_packed_local_parameters,
)


def ops():
    return (
        Operation.fixed("cx_dg"),
        Operation.local("u3_q1", np.linspace(-0.25, 0.35, 8)),
        Operation.fixed("cx_dg"),
        Operation.local("u3_q1", np.linspace(0.17, -0.19, 8)),
        Operation.fixed("cx_dg"),
    )


def test_mean_mode_is_backward_compatible():
    x = np.linspace(-np.pi, np.pi, 7, endpoint=False)
    a, ga, _ = family_objective_cost_and_gradient(ops(), x, FamilyObjectiveConfig(mode="mean"))
    b, gb = family_mean_cost_and_gradient(ops(), x)
    assert abs(a-b) < 1e-14
    np.testing.assert_allclose(ga, gb, atol=1e-13, rtol=1e-12)


def test_robust_objective_lies_between_mean_and_worst():
    x = np.linspace(-np.pi, np.pi, 9, endpoint=False)
    cfg = FamilyObjectiveConfig(mode="mean_softmax", robust_weight=0.6, temperature=0.08)
    value, _, comp = family_objective_cost_and_gradient(ops(), x, cfg)
    assert comp.mean_infidelity <= comp.smoothmax_infidelity <= comp.worst_infidelity + 1e-14
    assert comp.mean_infidelity <= value <= comp.worst_infidelity + 1e-14


def test_robust_gradient_matches_central_difference():
    x = np.linspace(-np.pi, np.pi, 7, endpoint=False) + 0.031
    cfg = FamilyObjectiveConfig(mode="mean_softmax", robust_weight=0.5, temperature=0.07)
    base = ops()
    vec = pack_local_parameters(base)
    value, grad, _ = family_objective_cost_and_gradient(base, x, cfg)
    assert np.isfinite(value)
    eps = 2e-6
    for k in (0, 3, 7, 8, 12, 15):
        vp = vec.copy(); vm = vec.copy()
        vp[k] += eps; vm[k] -= eps
        fp, _, _ = family_objective_cost_and_gradient(with_packed_local_parameters(base, vp), x, cfg)
        fm, _, _ = family_objective_cost_and_gradient(with_packed_local_parameters(base, vm), x, cfg)
        fd = (fp-fm)/(2*eps)
        assert abs(fd-grad[k]) < 3e-6
