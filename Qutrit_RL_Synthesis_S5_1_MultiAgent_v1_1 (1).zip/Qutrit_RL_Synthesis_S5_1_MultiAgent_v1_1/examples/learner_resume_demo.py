"""Demonstrate exact learner resume, including Adam/replay/RNG state."""
from pathlib import Path
import numpy as np

from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig

cfg=PSLSTMConfig(hidden_size=16,batch_size=4,min_replay_size=4,replay_capacity=64,seed=77)
a=CorrectedPSLSTMAgent(cfg)
actions=[3,1,3,1]
for i,act in enumerate(actions):
    obs=np.zeros(4)
    if i:
        obs[actions[i-1]]=1.0
    done=i==len(actions)-1
    a.observe(obs,act,10.0 if done else 0.0,terminated=done,truncated=False,success=done)
path=Path('ps_lstm_resume_demo.pt')
a.save_checkpoint(path)
b=CorrectedPSLSTMAgent(cfg)
b.load_checkpoint(path)
la=a.train_step(); lb=b.train_step()
print('loss_a',la)
print('loss_b',lb)
print('exact',la==lb)
path.unlink(missing_ok=True)
