"""Tiny deterministic exhaustive validation baseline."""
import numpy as np
from qutrit_synthesis.exhaustive import exhaustive_search
from qutrit_synthesis.optimizer import OptimizerConfig

xis=np.linspace(-np.pi,np.pi,5,endpoint=False)
results=exhaustive_search(1,xis,optimizer_config=OptimizerConfig(maxiter=20))
for r in results:
    print(r.kinds, f"mean_infidelity={r.mean_infidelity:.8f}", f"worst={r.worst_train_infidelity:.8f}")
