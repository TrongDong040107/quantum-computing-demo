import numpy as np

from qutrit_synthesis.fidelity import gate_fidelity
from qutrit_synthesis.oracle import oracle_unitary
from qutrit_synthesis.target import target_unitary

xis = np.linspace(-np.pi, np.pi, 101)
worst = min(gate_fidelity(target_unitary(x), oracle_unitary(x)) for x in xis)
print(f"minimum oracle fidelity on 101-point grid: {worst:.16f}")
