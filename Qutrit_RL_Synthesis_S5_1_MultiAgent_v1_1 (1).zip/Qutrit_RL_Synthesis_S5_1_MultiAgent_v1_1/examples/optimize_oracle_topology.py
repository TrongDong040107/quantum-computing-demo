"""Run the S1 continuous optimizer on the known 5-operation topology."""

from __future__ import annotations

import json
import numpy as np

from qutrit_synthesis.optimizer import OptimizerConfig, optimize_topology
from qutrit_synthesis.topology import operations_from_kinds


def main():
    n_train = 17
    train = np.linspace(-np.pi, np.pi, n_train, endpoint=False)
    step = 2*np.pi/n_train
    test = ((train + 0.5*step + np.pi) % (2*np.pi)) - np.pi

    topology = operations_from_kinds(
        ("cx_dg", "u3_q1", "cx_dg", "u3_q1", "cx_dg")
    )
    result = optimize_topology(
        topology,
        train,
        test_xis=test,
        config=OptimizerConfig(
            maxiter=100,
            n_random_starts=2,
            random_start_scale=0.5,
            seed=20260910,
        ),
    )
    print(json.dumps(result.to_dict(), indent=2))


if __name__ == "__main__":
    main()
