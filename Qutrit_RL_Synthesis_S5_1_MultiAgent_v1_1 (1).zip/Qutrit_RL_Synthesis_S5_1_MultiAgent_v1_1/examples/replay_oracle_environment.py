"""Replay the known 5-operation topology through the S2 RL environment."""
import json
import numpy as np

from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, KIND_TO_ACTION, QutritSynthesisEnv
from qutrit_synthesis.optimizer import OptimizerConfig

n=13
train=np.linspace(-np.pi,np.pi,n,endpoint=False)
step=2*np.pi/n
test=((train+0.5*step+np.pi)%(2*np.pi))-np.pi
cfg=EnvironmentConfig(
    max_steps=5,
    optimizer=OptimizerConfig(maxiter=100,n_random_starts=0),
    curriculum=CurriculumConfig(min_threshold=1e-10,initial_threshold=1e-10,update_window=100),
)
env=QutritSynthesisEnv(train,test_xis=test,config=cfg)
obs,info=env.reset(seed=20260910)
seq=("cx_dg","u3_q1","cx_dg","u3_q1","cx_dg")
trace=[]
for kind in seq:
    obs,reward,terminated,truncated,info=env.step(KIND_TO_ACTION[kind])
    trace.append({
        "kind":kind,
        "reward":reward,
        "terminated":terminated,
        "truncated":truncated,
        "mean_infidelity":info["train_metrics"]["mean_infidelity"],
        "worst_test_infidelity":info["test_metrics"]["worst_infidelity"],
    })
print(json.dumps({"trace":trace,"final":info},indent=2))
