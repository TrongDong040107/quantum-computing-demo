"""Run the frozen compute-constrained S4 pilot and write JSON results."""
import json
from pathlib import Path
import numpy as np

from qutrit_synthesis.campaign import aggregate_runs, run_ps_lstm_pilot, run_random_pilot
from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, QutritSynthesisEnv
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig

SEEDS=(11,29)
EPISODES=20
TRAIN_XIS=np.linspace(-np.pi,np.pi,3,endpoint=False)
TEST_XIS=np.linspace(-np.pi,np.pi,17,endpoint=False)+0.037

def env_for(seed):
    return QutritSynthesisEnv(
        TRAIN_XIS,
        test_xis=TEST_XIS,
        config=EnvironmentConfig(
            max_steps=5,
            optimizer=OptimizerConfig(maxiter=5,n_random_starts=0,seed=seed),
            curriculum=CurriculumConfig(
                min_threshold=1e-2,
                initial_threshold=0.55,
                delta=0.5,
                update_window=8,
                success_reward=2.0,
                final_reward=10.0,
            ),
            include_zero_restart=True,
        ),
    )

def agent_for(seed):
    return CorrectedPSLSTMAgent(PSLSTMConfig(
        hidden_size=128,
        num_layers=2,
        learning_rate=1e-2,
        batch_size=8,
        replay_capacity=5000,
        min_replay_size=8,
        train_every_interactions=20,
        target_update_interactions=20,
        gamma_damping=1e-3,
        eta_glow=0.1,
        beta_start=1e-3,
        beta_end=1.0,
        beta_anneal_episodes=120,
        store_successes_only=True,
        seed=seed,
        device='cpu',
    ))

random_runs=[]
ps_runs=[]
for seed in SEEDS:
    random_runs.append(run_random_pilot(env_for(seed),seed=seed,episodes=EPISODES))
    ps_runs.append(run_ps_lstm_pilot(env_for(seed),agent_for(seed),seed=seed,episodes=EPISODES))

result={
    'status':'S4_CONTROLLED_PILOT_COMPLETED',
    'scope_note':'Compute-constrained pilot; not a paper-scale convergence claim.',
    'config':{
        'seeds':list(SEEDS),'episodes_per_seed':EPISODES,'max_steps':5,
        'train_xis':TRAIN_XIS.tolist(),'test_xis':TEST_XIS.tolist(),
        'inner_optimizer_maxiter':5,'inner_random_starts':0,
        'curriculum_initial_threshold':0.55,'curriculum_min_threshold':1e-2,
        'curriculum_update_window':8,
        'ps_lstm_hidden_size':128,'ps_lstm_num_layers':2,'ps_lstm_batch_size':8,
        'ps_lstm_train_every_interactions':20,'ps_lstm_target_update_interactions':20,
        'ps_lstm_beta_anneal_episodes':120,
    },
    'random':aggregate_runs(random_runs),
    'ps_lstm':aggregate_runs(ps_runs),
}
path=Path(__file__).resolve().parents[1]/'S4_CONTROLLED_PILOT_RESULTS.json'
path.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
