"""Tiny end-to-end learner/environment smoke test (not a convergence benchmark)."""
import json
import numpy as np

from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, QutritSynthesisEnv
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig
from qutrit_synthesis.trainer import run_episode

train=np.linspace(-np.pi,np.pi,3,endpoint=False)
test=train+np.pi/3
env=QutritSynthesisEnv(
    train,
    test_xis=test,
    config=EnvironmentConfig(
        max_steps=3,
        optimizer=OptimizerConfig(maxiter=10,seed=17),
        curriculum=CurriculumConfig(min_threshold=1e-10,initial_threshold=1e-10,update_window=100),
    ),
)
agent=CorrectedPSLSTMAgent(
    PSLSTMConfig(hidden_size=32,num_layers=2,batch_size=8,min_replay_size=8,replay_capacity=128,seed=17)
)
results=[]
for episode in range(3):
    results.append(run_episode(env,agent,seed=100+episode).to_dict())
print(json.dumps({
    "note":"smoke only; no convergence claim",
    "episodes":results,
    "learner":{
        "interactions":agent.interactions,
        "episodes":agent.episodes,
        "replay_size":len(agent.replay),
        "gradient_updates":agent.gradient_updates,
        "target_syncs":agent.target_syncs,
    }
},indent=2))
