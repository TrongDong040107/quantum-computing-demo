from __future__ import annotations
import argparse,json,time
from pathlib import Path
from qutrit_synthesis.campaign import run_ps_lstm_pilot, run_random_pilot
from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig,QutritSynthesisEnv
from qutrit_synthesis.family_grid import periodic_uniform_grid
from qutrit_synthesis.family_objective import FamilyObjectiveConfig
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent,PSLSTMConfig
from qutrit_synthesis.terminal_credit import TerminalCreditConfig

TRAIN=periodic_uniform_grid(9)
TEST=periodic_uniform_grid(73,phase_fraction=.5)
ROBUST=FamilyObjectiveConfig(mode='mean_softmax',robust_weight=.6,temperature=.08)
TOC=TerminalCreditConfig(enabled=True,temperature=.25,scale=2.0,minimum_credit=.05)

def env_for(seed):
 return QutritSynthesisEnv(TRAIN,test_xis=TEST,config=EnvironmentConfig(
  max_steps=5,optimizer=OptimizerConfig(maxiter=4,n_random_starts=0,seed=seed,family_objective=ROBUST),
  curriculum=CurriculumConfig(min_threshold=1e-2,initial_threshold=.55,delta=.5,update_window=8,success_reward=2.,final_reward=10.),
  include_zero_restart=True,defer_test_evaluation=True))

def agent_for(seed):
 return CorrectedPSLSTMAgent(PSLSTMConfig(hidden_size=128,num_layers=2,learning_rate=1e-2,batch_size=8,
  replay_capacity=5000,min_replay_size=8,train_every_interactions=20,target_update_interactions=20,
  gamma_damping=1e-3,eta_glow=.1,beta_start=1e-3,beta_end=1.,beta_anneal_episodes=120,
  store_successes_only=True,seed=seed,device='cpu'))

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--seed',type=int,required=True); ap.add_argument('--episodes',type=int,default=20); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
 t=time.perf_counter(); rr=run_random_pilot(env_for(a.seed),seed=a.seed,episodes=a.episodes); t1=time.perf_counter();
 pr=run_ps_lstm_pilot(env_for(a.seed),agent_for(a.seed),seed=a.seed,episodes=a.episodes,terminal_credit=TOC); t2=time.perf_counter()
 payload={'seed':a.seed,'episodes':a.episodes,'random':rr.to_dict(),'ps_lstm_toc':pr.to_dict(),'wall_random':t1-t,'wall_ps':t2-t1,'wall_total':t2-t}
 a.out.write_text(json.dumps(payload,indent=2),encoding='utf-8'); print(json.dumps(payload,indent=2))
if __name__=='__main__': main()
