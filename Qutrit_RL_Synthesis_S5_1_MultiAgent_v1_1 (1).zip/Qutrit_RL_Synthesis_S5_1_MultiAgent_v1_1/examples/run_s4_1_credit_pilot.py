"""Compute-bounded S4.1 comparison: random vs PS-LSTM vs terminal-credit PS-LSTM."""
import json
from pathlib import Path

from qutrit_synthesis.campaign import aggregate_runs, run_ps_lstm_pilot, run_random_pilot
from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, QutritSynthesisEnv
from qutrit_synthesis.family_grid import periodic_uniform_grid
from qutrit_synthesis.family_objective import FamilyObjectiveConfig
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig
from qutrit_synthesis.terminal_credit import TerminalCreditConfig

ROOT=Path(__file__).resolve().parents[1]
SEEDS=(11,29,47)
EPISODES=4
TRAIN_XIS=periodic_uniform_grid(9)
TEST_XIS=periodic_uniform_grid(73,phase_fraction=0.5)
ROBUST=FamilyObjectiveConfig(mode='mean_softmax',robust_weight=0.6,temperature=0.08)
TOC=TerminalCreditConfig(enabled=True,temperature=0.25,scale=2.0,minimum_credit=0.05)


def env_for(seed):
    return QutritSynthesisEnv(
        TRAIN_XIS,test_xis=TEST_XIS,
        config=EnvironmentConfig(
            max_steps=5,
            optimizer=OptimizerConfig(maxiter=4,n_random_starts=0,seed=seed,family_objective=ROBUST),
            curriculum=CurriculumConfig(
                min_threshold=1e-2,initial_threshold=0.55,delta=0.5,update_window=8,
                success_reward=2.0,final_reward=10.0,
            ),
            include_zero_restart=True,
            defer_test_evaluation=True,
        ),
    )


def agent_for(seed):
    return CorrectedPSLSTMAgent(PSLSTMConfig(
        hidden_size=128,num_layers=2,learning_rate=1e-2,batch_size=8,
        replay_capacity=5000,min_replay_size=8,train_every_interactions=20,
        target_update_interactions=20,gamma_damping=1e-3,eta_glow=0.1,
        beta_start=1e-3,beta_end=1.0,beta_anneal_episodes=120,
        store_successes_only=True,seed=seed,device='cpu',
    ))

def main():
    random_runs=[]; ps_runs=[]; toc_runs=[]
    for seed in SEEDS:
        random_runs.append(run_random_pilot(env_for(seed),seed=seed,episodes=EPISODES))
        ps_runs.append(run_ps_lstm_pilot(env_for(seed),agent_for(seed),seed=seed,episodes=EPISODES))
        toc_runs.append(run_ps_lstm_pilot(env_for(seed),agent_for(seed),seed=seed,episodes=EPISODES,terminal_credit=TOC))

    result={
        'status':'S4_1_CREDIT_PILOT_COMPLETED',
        'scope_note':'Three-seed four-episode diagnostic only; not a convergence or statistical superiority claim.',
        'config':{
            'seeds':list(SEEDS),'episodes_per_seed':EPISODES,'max_steps':5,
            'train_xi_points':len(TRAIN_XIS),'test_xi_points':len(TEST_XIS),
            'family_objective':ROBUST.to_dict(),'inner_optimizer_maxiter':4,
            'curriculum_initial_threshold':0.55,'curriculum_min_threshold':1e-2,
            'terminal_credit':TOC.to_dict(),
            'ps_lstm_hidden_size':128,'ps_lstm_num_layers':2,'ps_lstm_batch_size':8,
        },
        'random':aggregate_runs(random_runs),
        'ps_lstm_success_only':aggregate_runs(ps_runs),
        'ps_lstm_terminal_credit':aggregate_runs(toc_runs),
    }
    path=ROOT/'S4_1_CREDIT_PILOT_RESULTS.json'
    path.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
