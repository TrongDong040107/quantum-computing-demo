"""Exercise the complete env->reward->replay->Adam->target-sync path.

The curriculum threshold is intentionally loose (1.0), so this is only a
software-plumbing test and must not be interpreted as a synthesis result.
"""
import json
import numpy as np

from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, QutritSynthesisEnv
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.ps_lstm import CorrectedPSLSTMAgent, PSLSTMConfig
from qutrit_synthesis.trainer import run_episode

train=np.linspace(-np.pi,np.pi,3,endpoint=False)
test=train+np.pi/3
env=QutritSynthesisEnv(
    train,
    test_xis=test,
    config=EnvironmentConfig(
        max_steps=2,
        optimizer=OptimizerConfig(maxiter=5,seed=5),
        curriculum=CurriculumConfig(
            min_threshold=1e-12,
            initial_threshold=1.0,
            update_window=500,
        ),
    ),
)
agent=CorrectedPSLSTMAgent(
    PSLSTMConfig(
        hidden_size=16,
        num_layers=2,
        batch_size=1,
        min_replay_size=1,
        replay_capacity=32,
        target_update_interactions=2,
        train_every_interactions=100,
        seed=5,
    )
)
rows=[]
for ep in range(3):
    rows.append(run_episode(env,agent,seed=500+ep).to_dict())
print(json.dumps({
    "note":"PLUMBING SMOKE ONLY. initial curriculum threshold=1.0 intentionally forces easy successes; no convergence claim.",
    "episodes":rows,
    "learner":{
        "interactions":agent.interactions,
        "episodes":agent.episodes,
        "successful_episodes":agent.successful_episodes,
        "replay_size":len(agent.replay),
        "gradient_updates":agent.gradient_updates,
        "target_syncs":agent.target_syncs,
        "last_train_loss":agent.last_train_loss,
    }
},indent=2))
