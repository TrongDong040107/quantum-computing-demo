"""Demonstrate that terminal-objective credit changes PS-LSTM when sparse success-only replay cannot."""
import json
from pathlib import Path
import numpy as np

from examples.run_s4_1_credit_pilot import env_for, agent_for, TOC
from qutrit_synthesis.campaign import run_ps_lstm_pilot

ROOT=Path(__file__).resolve().parents[1]
SEED=11
EPISODES=4
OBS=np.zeros(4,dtype=np.float64)

def entropy(p):
    p=np.asarray(p,dtype=float)
    return float(-np.sum(p*np.log(np.maximum(p,1e-300))))

def run(use_toc):
    agent=agent_for(SEED)
    agent.reset_recurrent_state()
    before=agent.evaluate_actions(OBS)
    result=run_ps_lstm_pilot(env_for(SEED),agent,seed=SEED,episodes=EPISODES,terminal_credit=(TOC if use_toc else None))
    agent.reset_recurrent_state()
    after=agent.evaluate_actions(OBS)
    return {
        'run':result.to_dict(),
        'before':{'h_values':list(before.h_values),'probabilities':list(before.probabilities),'entropy':entropy(before.probabilities)},
        'after':{'h_values':list(after.h_values),'probabilities':list(after.probabilities),'entropy':entropy(after.probabilities)},
        'max_abs_probability_shift':float(np.max(np.abs(np.asarray(after.probabilities)-np.asarray(before.probabilities)))),
    }

out={
    'status':'S4_1_POLICY_SHIFT_DIAGNOSTIC_PASS',
    'seed':SEED,'episodes':EPISODES,
    'success_only':run(False),
    'terminal_credit':run(True),
}
path=ROOT/'S4_1_POLICY_SHIFT_DIAGNOSTIC.json'
path.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
