"""S4.1 diagnostics: robust family objective, oracle preservation, and overfit reduction."""
import json
from pathlib import Path
import numpy as np

from qutrit_synthesis.curriculum import CurriculumConfig
from qutrit_synthesis.environment import EnvironmentConfig, KIND_TO_ACTION, QutritSynthesisEnv
from qutrit_synthesis.family_grid import periodic_uniform_grid, minimum_periodic_separation
from qutrit_synthesis.family_objective import FamilyObjectiveConfig
from qutrit_synthesis.optimizer import OptimizerConfig, optimize_topology
from qutrit_synthesis.topology import operations_from_kinds

ROOT=Path(__file__).resolve().parents[1]
TRAIN3=periodic_uniform_grid(3)
TRAIN9=periodic_uniform_grid(9)
TEST257=periodic_uniform_grid(257,phase_fraction=0.5)
TEST73=periodic_uniform_grid(73,phase_fraction=0.5)
ORACLE=('cx_dg','u3_q1','cx_dg','u3_q1','cx_dg')
WRONG=('cx_dg','u3_q1','cx_dg','u3_q1','u3_q1')

mean3=optimize_topology(
    operations_from_kinds(WRONG),TRAIN3,test_xis=TEST257,
    config=OptimizerConfig(maxiter=30,seed=17,family_objective=FamilyObjectiveConfig(mode='mean')),
)
rob9=optimize_topology(
    operations_from_kinds(WRONG),TRAIN9,test_xis=TEST257,
    config=OptimizerConfig(maxiter=30,seed=17,family_objective=FamilyObjectiveConfig(mode='mean_softmax',robust_weight=0.6,temperature=0.08)),
)

# Replay oracle through the real sequential environment under pilot-scale maxiter=4.
env=QutritSynthesisEnv(
    TRAIN9,test_xis=TEST73,
    config=EnvironmentConfig(
        max_steps=5,
        optimizer=OptimizerConfig(maxiter=4,seed=23,n_random_starts=0,
            family_objective=FamilyObjectiveConfig(mode='mean_softmax',robust_weight=0.6,temperature=0.08)),
        curriculum=CurriculumConfig(min_threshold=1e-2,initial_threshold=0.55,delta=0.5,update_window=8),
        include_zero_restart=True,
    ),
)
env.reset(seed=20260911)
prefix=[]
for kind in ORACLE:
    _,reward,terminated,truncated,info=env.step(KIND_TO_ACTION[kind])
    prefix.append({
        'step':info['step_count'],'kind':kind,'objective':info['objective'],
        'mean_train_infidelity':info['train_metrics']['mean_infidelity'],
        'worst_train_infidelity':info['train_metrics']['worst_infidelity'],
        'worst_test_infidelity':info['test_metrics']['worst_infidelity'],
        'reward':reward,'terminated':terminated,'truncated':truncated,
    })
    if terminated or truncated:
        break

result={
    'status':'S4_1_OBJECTIVE_DIAGNOSTICS_PASS',
    'grids':{
        'train3_n':len(TRAIN3),'train9_n':len(TRAIN9),'test257_n':len(TEST257),'test73_n':len(TEST73),
        'train9_test73_min_periodic_separation':minimum_periodic_separation(TRAIN9,TEST73),
    },
    'wrong_topology':list(WRONG),
    'sparse_mean3':{
        'objective':mean3.objective_reported,
        'train_mean_infidelity':mean3.train_metrics.mean_infidelity,
        'train_worst_infidelity':mean3.train_metrics.worst_infidelity,
        'test_mean_infidelity':mean3.test_metrics.mean_infidelity,
        'test_worst_infidelity':mean3.test_metrics.worst_infidelity,
        'train_test_mean_gap':mean3.test_metrics.mean_infidelity-mean3.train_metrics.mean_infidelity,
    },
    'robust9':{
        'objective':rob9.objective_reported,
        'components':rob9.objective_components.to_dict(),
        'train_mean_infidelity':rob9.train_metrics.mean_infidelity,
        'train_worst_infidelity':rob9.train_metrics.worst_infidelity,
        'test_mean_infidelity':rob9.test_metrics.mean_infidelity,
        'test_worst_infidelity':rob9.test_metrics.worst_infidelity,
        'train_test_mean_gap':rob9.test_metrics.mean_infidelity-rob9.train_metrics.mean_infidelity,
    },
    'oracle_environment_prefix':prefix,
    'oracle_final_success':bool(prefix[-1]['objective'] <= 1e-2),
}
path=ROOT/'S4_1_OBJECTIVE_DIAGNOSTICS.json'
path.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
