from __future__ import annotations
import argparse, json, time
from pathlib import Path

from qutrit_synthesis.family_grid import periodic_uniform_grid
from qutrit_synthesis.family_objective import FamilyObjectiveConfig
from qutrit_synthesis.optimizer import OptimizerConfig
from qutrit_synthesis.terminal_search import coarse_terminal_search


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--start',type=int,required=True)
    ap.add_argument('--end',type=int,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    train=periodic_uniform_grid(9)
    opt=OptimizerConfig(maxiter=3,n_random_starts=0,seed=20260911,
        family_objective=FamilyObjectiveConfig(mode='mean_softmax',robust_weight=.6,temperature=.08))
    t=time.perf_counter()
    res=coarse_terminal_search(5,train,optimizer_config=opt,start_index=args.start,end_index=args.end)
    payload={
        'start':args.start,'end':args.end,'n':len(res),'wall_seconds':time.perf_counter()-t,
        'optimizer':{'maxiter':3,'n_random_starts':0,'robust_weight':.6,'temperature':.08},
        'candidates':[x.to_dict() for x in res],
    }
    args.out.write_text(json.dumps(payload,indent=2),encoding='utf-8')
    print(json.dumps({'start':args.start,'end':args.end,'n':len(res),'wall_seconds':payload['wall_seconds'],
                      'best_actions':res[0].actions,'best_objective':res[0].objective},indent=2))

if __name__=='__main__': main()
