# S4.5 Replay/Credit Ablation Report

Status: **PRIORITIZED_REPLAY_PROMISING_BUT_NOT_STABLE**.

## Frozen comparison
Six new paired seeds, 120 episodes per arm. Physics, target family, action space, robust objective, L-BFGS-B budget, curriculum, TOC, PS-LSTM architecture, beta schedule, and episode horizon were held fixed. The only changed factor was replay sampling.

- Uniform arm: replay items sampled uniformly.
- Terminal-priority arm: sample weight `(terminal_reward + 0.05)^1.0`. Every prefix from an episode receives the same sampling priority, so prioritization is by final trajectory quality; the fitted glow target itself is unchanged.

## Main diagnostic result

| Metric | Uniform replay | Terminal-priority replay |
|---|---:|---:|
| Seed successes | 0/6 | **2/6** |
| Known-exact hits | 0 | **2** |
| Median best robust objective | 0.266279 | 0.266279 |
| Mean best robust objective | 0.34438 | **0.223569** |
| Median exact-sequence probability mass | 0.00213377 | **0.00317642** |
| Median exact-mass / uniform-policy baseline | 1.092x | **1.626x** |
| Median normalized probe entropy | 0.992142 | **0.813213** |

The two terminal-priority successes occurred at episodes 99 and 100 (zero-indexed first-success indices 98 and 99), and both were known exact depth-5 topologies. Their held-out worst infidelity was about `1.2734e-3` with the deliberately small four-iteration L-BFGS-B budget.

## Important failure mode
Prioritization increased concentration, but concentration was not always correct. For seed `2892904734`, exact-sequence probability mass fell from `0.0020896` under uniform replay to `3.61131e-06` under priority replay, while normalized probe entropy dropped from `0.9893` to `0.7787`. This is a wrong-attractor example: replay prioritization can amplify a suboptimal trajectory family.

## Interpretation
The replay-dilution hypothesis is **partially supported**. Prioritized replay changes the learner in the desired direction on aggregate and generated two exact discoveries where the matched uniform arm generated none, but it does not establish robust convergence across seeds. No superiority p-value is reported because S4.5 was predeclared as a six-seed diagnostic.

## Decision
Proceed to S5 final training-candidate gate with terminal-priority replay as the proposed learner variant, while retaining the frozen uniform-replay PS-LSTM+TOC as an explicit control/ablation in the eventual training campaign. Do not claim stable convergence yet.
