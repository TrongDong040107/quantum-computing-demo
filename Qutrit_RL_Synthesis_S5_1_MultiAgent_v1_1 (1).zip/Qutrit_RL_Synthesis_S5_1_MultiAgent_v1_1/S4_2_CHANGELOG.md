# S4.2 Changelog — v0.7

- Closed S4.1 fresh-extract verification: 73/73 inherited tests PASS.
- Added deterministic global beam-search baseline with matched inner-optimizer semantics.
- Added entangler/last-action stratified beam diagnostic.
- Added complete fixed-depth terminal topology search and parallel coarse screening.
- Added coarse-to-fine depth-five search over all 1024 discrete topologies.
- Discovered a second exact five-gate topology using `CX` rather than `CX†`.
- Added an exact dual-oracle implementation and regression test.
- Extended campaign bookkeeping to distinguish the original canonical oracle from all currently known exact discrete topologies.
- Ran a matched 3-seed × 20-episode, 100-interaction random-vs-TOC-PS-LSTM pilot.
- Added exhaustive depth-1-through-depth-4 search diagnostic.
- Added structured-search and terminal-search regression tests.
