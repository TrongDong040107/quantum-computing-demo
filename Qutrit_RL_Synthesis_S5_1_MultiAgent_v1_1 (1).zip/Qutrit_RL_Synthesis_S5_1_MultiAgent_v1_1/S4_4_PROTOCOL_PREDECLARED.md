# S4.4 predeclared convergence-trace protocol

Status: **diagnostic / exploratory, not a new superiority test**.

The scientific learner, physics model, action space, robust family objective,
L-BFGS-B configuration, curriculum, terminal-objective credit, and PS-LSTM
hyperparameters are unchanged from the frozen S4.3 construction.

## Question
Does PS-LSTM+TOC develop policy concentration toward either known exact depth-5
qutrit topology when it is allowed to run through the full pre-existing beta
annealing horizon (120 episodes)?

## Fixed diagnostic design

- Policy: PS-LSTM+TOC only.
- Episodes per seed: 120.
- New diagnostic seeds: `130883010, 2848563235, 3136500927, 1826782196`.
- Probe boundaries: episode 0, then 10,20,...,120.
- Known exact sequences (action IDs): `[2,1,2,1,2]` and `[3,1,3,1,3]`.
- Probe is read-only: it reconstructs a separate agent from the checkpoint and
  consumes no scientific RNG state.
- The resumable S4.3a episode-transaction runner remains the execution engine.

## Recorded endpoints

At each probe boundary record beta, the probability of each exact sequence under
forced-prefix evaluation, their summed probability mass, per-step policy entropy,
cumulative final successes, best-so-far robust objective, replay size, gradient
updates, and target syncs.

## Interpretation rule

This is a convergence diagnostic. No p-value or superiority claim will be made
from four seeds. Evidence of convergence requires a persistent, cross-seed
increase in exact-sequence probability mass and a corresponding reduction in
policy entropy; isolated exact hits without policy concentration are classified
as discovery without stable convergence.
