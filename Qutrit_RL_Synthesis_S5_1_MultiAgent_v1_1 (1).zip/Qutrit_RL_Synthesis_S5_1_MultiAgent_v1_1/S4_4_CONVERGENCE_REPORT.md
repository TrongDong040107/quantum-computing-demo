# S4.4 Convergence Trace Report

## Status

**S4.4 COMPLETE — NO STABLE CONVERGENCE OBSERVED**

This milestone is diagnostic, not a new superiority test. The scientific learner,
qutrit physics, action space, robust family objective, L-BFGS-B settings,
curriculum, TOC reward, and PS-LSTM hyperparameters are unchanged from S4.3.
The frozen scientific Python-tree SHA-256 remains:

`0b4aad67302ca4aa9bdc73e45d02f9d1d497d1ccd6547147fb380ba4ab215802`

Only read-only convergence probes and tracing tools were added.

## Why S4.4 was needed

S4.3 stopped each seed after 50 episodes. The PS-LSTM beta schedule is frozen as

- beta_start = 0.001
- beta_end = 1.0
- beta_anneal_episodes = 120

so episode 50 corresponds to beta = 0.41725, not the end of the exploration /
exploitation schedule. S4.4 therefore extends four **new diagnostic seeds** to
120 episodes so that beta reaches 1.0 without changing the learner.

Predeclared seeds:

`130883010, 2848563235, 3136500927, 1826782196`

## Non-invasive policy probe

At selected episode boundaries, a separate reconstructed agent is evaluated on
the two independently verified exact action sequences:

- `[2,1,2,1,2]` = `CX, U3(q1), CX, U3(q1), CX`
- `[3,1,3,1,3]` = `CX†, U3(q1), CX†, U3(q1), CX†`

The probe forces the prefix only inside a copied agent and records the policy
probability of the required next action. It does not consume the scientific RNG,
change recurrent state, or enter replay/training.

A uniform four-action policy assigns probability

`2*(1/4)^5 = 0.001953125`

to the union of these two exact sequences.

## Final 120-episode results

| Seed | Final success | Exact hits | Best robust objective | P(two known exact sequences) | Ratio to uniform |
|---:|---:|---:|---:|---:|---:|
| 130883010 | 0 | 0 | 0.266278744 | 0.002214303 | 1.134× |
| 2848563235 | 0 | 0 | 0.404062135 | 0.002328425 | 1.192× |
| 3136500927 | 0 | 0 | 0.266278744 | 0.002111823 | 1.081× |
| 1826782196 | 0 | 0 | 0.266278744 | 0.001803784 | 0.924× |

Aggregate:

- final-success seeds: **0/4**
- known exact topology hits: **0**
- beta at episode 120: **1.0 for all 4 seeds**
- median exact-sequence probability mass: **0.002163063**
- median ratio to uniform: **1.1075×**
- mean normalized entropy on exact-prefix probe states: **0.99439**
- median late empirical action entropy (episodes 101–120): **0.97809**
- median best robust objective: **0.266278744**, still far above the final-success threshold `1e-2`

Each seed completed 119 gradient updates, accumulated 600 replay prefix samples,
and completed the beta anneal. The absence of policy concentration is therefore
not explained by a missing learner update path.

## Key diagnosis

The 50-episode horizon of S4.3 was **not the main reason** for the lack of robust
convergence. Even after beta reaches 1.0, the policy remains close to uniform on
the exact-prefix states.

For example, at episode 120 the initial-state probabilities are approximately:

- seed 130883010: `[0.204, 0.298, 0.260, 0.239]`
- seed 2848563235: `[0.196, 0.323, 0.291, 0.189]`
- seed 3136500927: `[0.190, 0.396, 0.263, 0.151]`
- seed 1826782196: `[0.288, 0.250, 0.222, 0.239]`

The exact sequences must start with action 2 or 3. Their combined first-action
probability is below the uniform value 0.5 in three of four seeds and only
approximately equal to it in the fourth.

Thus the learner changes its h-values, but the learned preference is not
consistently aligned with the globally exact topology.

## Interpretation of TOC

TOC solved the S4 blocker where unsuccessful episodes created no replay and no
learning. In S4.4, however, essentially all episodes contribute positive terminal
credit. If no exact / near-exact trajectory is sampled, replay repeatedly
reinforces merely better-than-average but still suboptimal terminal circuits.
The learner therefore has a usable gradient signal, but not enough discrete
credit contrast to reliably identify the rare exact five-action structure.

This is consistent with the earlier observation that prefix fidelity is
non-monotone along the exact solution: a globally correct prefix can temporarily
look worse than competing prefixes. Consequently, simply increasing beta cannot
repair the credit-assignment ambiguity.

## Scientific conclusion

The correct statement after S4.4 is:

> PS-LSTM+TOC is capable of discovering exact qutrit synthesis topologies, as
> demonstrated in S4.3, but it has **not converged to a stable exact-topology
> policy**. Extending training through the complete beta-annealing horizon does
> not by itself produce robust convergence.

This rules out the simple explanation that S4.3 failed only because it stopped at
50 episodes before beta reached 1.0.

## Recommended next milestone

The next change should target **credit / replay discrimination**, not physics,
continuous optimization, or beta annealing. The safest next experiment is an
ablation that leaves environment reward and success definitions unchanged but
compares the current uniform replay sampling against a predeclared
credit-prioritized / elite replay rule. The exact-topology probability probe from
S4.4 should be retained as a diagnostic endpoint.
