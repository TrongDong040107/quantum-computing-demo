# S4.2 Structured Search Report — v0.7

## Decision

**S4.2 PASS — structured-search diagnosis complete.**

The main result is not that ordinary beam search solves the problem. It does not. The important result is that scoring only complete depth-five circuits removes the non-monotone-prefix failure mode and exposes two exact discrete solutions, one of which had not been inserted into the code as an oracle.

## Frozen scientific configuration

- action map: `0=U3(q0)`, `1=U3(q1)`, `2=CX`, `3=CX†`;
- target family: `exp[-i ξ (λ3⊗λ3)]`;
- 9 periodic training values of ξ;
- 73 shifted held-out values of ξ;
- robust family objective: mean + smoothmax with `rho=0.6`, `tau=0.08`;
- final threshold: `1e-2`;
- test values never enter the continuous optimizer.

## A. Prefix-ranked beam search

A deterministic width-4 beam was run using the same inner-optimization semantics as the RL environment: max four L-BFGS-B iterations, parent warm start, and canonical zero restart when applicable.

Results:

- node evaluations: **68**;
- validated successes: **0**;
- canonical exact prefix retained at depth 1: **yes**;
- canonical exact prefix retained at depth 2: **no**.

The best beam prefix remained a local-only sequence with robust objective about `0.76705`. This is a direct reproduction of the S4 scientific diagnosis: a prefix can look poor even when it belongs to an exact terminal solution. Therefore objective-ranked beam search is not a trustworthy solver for this problem unless substantial diversity/lookahead machinery is added.

## B. Complete depth-five coarse screen

There are exactly

`4^5 = 1024`

discrete length-five topologies. S4.2 evaluates each topology exactly once at low continuous-optimization fidelity: one L-BFGS-B iteration and no random restart. The held-out grid is not used.

The two best coarse candidates are tied:

1. `[2,1,2,1,2] = CX -> U3(q1) -> CX -> U3(q1) -> CX`
2. `[3,1,3,1,3] = CX† -> U3(q1) -> CX† -> U3(q1) -> CX†`

Both have coarse robust objective

`0.41320151513745`.

The previously known canonical `CX†` oracle ranks **#2**. The all-`CX` sequence ranks **#1** and was not provided to the structured search as a target sequence.

## C. Top-two refinement

Only the two best coarse candidates were then refined using max 10 L-BFGS-B iterations, with the coarse solution as primary initialization plus a zero restart safeguard.

Both converge to machine-precision family solutions:

- robust objective: **0.0**;
- training mean infidelity: **0.0**;
- training worst infidelity: **0.0**;
- 73-point held-out worst infidelity: **3.33e-16**.

The learned coefficients recover simple diagonal local blocks. For the all-`CX` topology the first local block is approximately `Ud(-ξ,-ξ)` and the second is approximately `Ud(-ξ,0)`. For the all-`CX†` topology the order is reversed.

Both exact circuits satisfy, numerically and by the added regression identities,

`V(ξ) = exp(-i ξ) U_target(ξ)`.

The factor `exp(-i ξ)` is a global phase and therefore both circuits have unit gate-overlap fidelity over the complete target family.

## D. Shorter-depth exhaustive diagnostic

Every topology at depths 1 through 4 was enumerated and optimized with max 10 L-BFGS-B iterations from the canonical zero initialization. The best robust objectives were:

| depth | number of topologies | best robust objective |
|---:|---:|---:|
| 1 | 4 | 0.7670509709 |
| 2 | 16 | 0.7670509709 |
| 3 | 64 | 0.6271737973 |
| 4 | 256 | 0.5703881031 |

None comes remotely close to the final threshold `1e-2`.

This is strong computational evidence that depth five is necessary for the present logical action model, but it is **not a mathematical proof of global minimality** because a nonconvex continuous optimizer cannot certify all continuous parameter spaces.

## E. Random-search combinatorics after the dual-oracle discovery

S4 previously knew one exact discrete sequence. S4.2 establishes at least two exact depth-five sequences. Therefore a uniformly random full-depth episode has at least

`2 / 4^5 = 1/512`

probability of sampling a currently known exact topology before continuous optimization is considered.

The corresponding lower-bound hit probabilities are approximately:

- 20 independent full-depth random episodes: **3.83%**;
- 60 episodes: **11.07%**;
- 1024 episodes: **86.49%**.

These are lower bounds because S4.2 has not proven that only two exact topologies exist.

## Scientific conclusion

The dominant obstacle is now clearer:

1. prefix fidelity/objective is non-monotone and can mislead beam-like search;
2. complete-circuit screening is robust to that failure mode;
3. the depth-five discrete search space is small enough here to provide a ground-truth diagnostic;
4. the exact solution is not unique at the topology level;
5. future RL evaluation must count both currently known exact sequences, not only the original `CX†` oracle.
