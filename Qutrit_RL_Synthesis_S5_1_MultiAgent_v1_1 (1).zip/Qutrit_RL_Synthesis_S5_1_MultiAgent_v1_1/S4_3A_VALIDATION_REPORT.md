# S4.3a — Deterministic Resumable Campaign Runner Validation

## Status

**PASS — READY TO RESUME THE FROZEN S4.3 20-SEED CAMPAIGN.**

S4.3a is an execution/reliability layer only.  The scientific Python tree under `qutrit_synthesis/` and `examples/` is byte-for-byte identical to the frozen S4.3 source: **35/35 Python files exact, 0 mismatches**.

## Why this layer was needed

A previous 50-episode confirmatory PS-LSTM run reached episode 45 and then stopped making progress inside a long inner-optimizer call.  Restarting the whole seed would risk losing exact learner/replay/RNG state, while skipping the topology or modifying L-BFGS-B would violate the predeclared protocol.

The S4.3a runner therefore treats each episode as an atomic transaction.  A persistent child process writes the authoritative checkpoint only after a complete episode.  The supervisor watches checkpoint progress; if the child stalls, it is killed and the same episode is restarted from the last complete checkpoint.  No seed or topology is silently skipped.

## Exact-resume validation

For seed 11 and 2 episodes:

- Uniform random uninterrupted vs pause-after-episode-1 + process reconstruction + resume: **exact scientific result match**.
- Corrected PS-LSTM+TOC uninterrupted vs pause/reconstruct/resume: **exact scientific result match**, including actions, objectives, replay size, gradient-update count, target-sync count, curriculum state and action counts.
- Resumable runner vs the original frozen one-shot S4.2/S4.3 campaign functions: **exact** for both policies after removing wall-clock fields.

## Watchdog transaction test

A deliberate one-time external timeout was injected before episode 0.  The supervisor recorded:

- watchdog timeouts: **1**
- retries: **1**

After retry, the complete scientific result was **exactly equal** to the no-timeout reference run.  This validates that a killed child cannot partially advance the scientific campaign state.

## Regression

Frozen source regression suite after adding the external runner:

- **83/83 tests PASS**
- no changes to frozen scientific-core Python files

## First confirmatory seed completed with the resumable runner

Predeclared S4.3 seed: **1012132659**, 50 episodes/policy, max depth 5.

### Uniform random

- final-success episodes: **0**
- best robust objective: **0.620808724582**
- known exact topology hits: **0**
- interactions: **250**

The resumable result is exactly equal to the earlier frozen one-shot random result for this same seed.

### Corrected PS-LSTM + TOC

- final-success episodes: **1**
- first final success: episode index **17** (episode 18)
- best topology: **[3, 1, 3, 1, 3]** = `CX†, U3(q1), CX†, U3(q1), CX†`
- best robust objective: **0.000447845743903**
- held-out worst infidelity: **0.00127341893629**
- known exact topology hits: **1**
- interactions: **250**
- gradient updates: **49**
- target syncs: **12**

The run was externally interrupted after 45 completed episodes.  Re-running the same resumable command restored the checkpoint and completed episodes 46–50 without changing the frozen scientific configuration.

## Scientific interpretation guard

This is **one** predeclared confirmatory seed pair.  It is encouraging that PS-LSTM+TOC found the exact canonical topology while random did not, but this is **not** sufficient to claim superiority.  The predeclared 20-seed campaign, Fisher exact test and Wilson confidence intervals must still be completed and reported in full.
