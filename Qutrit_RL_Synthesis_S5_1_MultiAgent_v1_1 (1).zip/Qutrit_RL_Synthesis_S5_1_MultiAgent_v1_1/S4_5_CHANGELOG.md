# S4.5 changelog

- Added replay sampling modes `uniform` and `terminal_priority`.
- Added per-replay-item `sampling_priority`, equal to the episode terminal reward for all prefixes in that episode.
- Priority sampling uses `(priority + epsilon)^alpha`, with frozen diagnostic values alpha=1 and epsilon=0.05.
- Continuous targets, glow propagation, TOC, environment reward, optimizer, physics, and action semantics are unchanged.
- Added paired six-seed 120-episode replay ablation and regression tests.
