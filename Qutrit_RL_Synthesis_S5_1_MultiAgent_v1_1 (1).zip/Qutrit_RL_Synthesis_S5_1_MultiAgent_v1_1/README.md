# Qutrit RL Synthesis — S5.1 Multi-Agent v1.1

This release extends the validated S5 two-qutrit synthesis environment without changing its quantum physics, target family, action semantics, continuous L-BFGS-B inner optimizer, robust family objective, or exact oracle definitions.

## Available learners

- `ps_lstm`: the existing corrected PS-LSTM + terminal objective credit + terminal-priority replay.
- `ppo`: memoryless categorical PPO/GAE.
- `ppo_trxl`: categorical PPO with detached episodic Transformer-XL-style memory.
- `cad_sf_trppo`: categorical temporal PPO with critic-return-residual-conditioned entropy and residual-gated diagonal Soft-Fisher shaping of the categorical actor head.

The discrete action set is unchanged:

`0=U3(q0), 1=U3(q1), 2=CX, 3=CX†`.

`CAD-SF-TrPPO` is **not TRPO**. `TrPPO` denotes temporal/Transformer PPO, consistent with the source method. Because the quantum synthesis action space is discrete, Gaussian-policy formulas from the PASS implementation are not reused. Log-likelihood, entropy and Fisher-score terms are computed from a categorical distribution over the four gate actions.

## Five-seed pilot

The S5.1 pilot uses five common seeds (the first five frozen S5 seeds) and defaults to 300 episodes per seed. This is a pilot/comparison protocol, not a replacement for the previously frozen S5 PS-LSTM paper-scale protocol.

Run one algorithm over all five seeds:

```bash
python tools/run_multi_agent_pilot5.py --algorithm ppo --episodes 300 --output-dir runs_s5_1
python tools/run_multi_agent_pilot5.py --algorithm ppo_trxl --episodes 300 --output-dir runs_s5_1
python tools/run_multi_agent_pilot5.py --algorithm cad_sf_trppo --episodes 300 --output-dir runs_s5_1
python tools/run_multi_agent_pilot5.py --algorithm ps_lstm --episodes 300 --output-dir runs_s5_1
```

Run or resume one seed:

```bash
python tools/run_multi_agent_qutrit.py \
  --algorithm cad_sf_trppo \
  --seed 2848563236 \
  --episodes 300 \
  --output-dir runs_s5_1
```

The one-seed runner saves an atomic episode-transaction checkpoint. Re-running the same command resumes exactly from the previous completed episode, provided the scientific Python tree and S5.1 protocol hashes are unchanged.

## Validation

The release was validated with 104/104 tests in three partitions, plus end-to-end real-environment smoke runs for PPO, PPO-TrXL and CAD-SF-TrPPO. Interrupted-after-one-episode → resume was compared against uninterrupted execution for each new PPO-family algorithm and produced identical final scientific JSON results.

See `S5_1_ALGORITHM_INTEGRATION.md` and `S5_1_VALIDATION_REPORT.md`.
