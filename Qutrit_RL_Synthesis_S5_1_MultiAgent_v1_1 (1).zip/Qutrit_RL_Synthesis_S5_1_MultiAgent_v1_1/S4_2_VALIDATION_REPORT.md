# S4.2 Validation Report — Structured Search & Matched Learning Pilot v0.7

## Release decision

**S4.2 PASS — READY FOR S4.3 MULTI-SEED LEARNING CAMPAIGN DESIGN.**

This release is not sufficient for a paper-level statement that PS-LSTM outperforms random search.

## 1. Inherited baseline closure

The previously pre-verified S4.1 archive was freshly extracted and its SHA tree checked. The inherited S4.1 source passes all **73/73** tests when run in partitions. This closes the packaging-only blocker left at the end of S4.1.

## 2. S4.2 structured-search implementation

New modules:

- `structured_search.py`: deterministic objective beam and diversity-stratified beam diagnostics;
- `terminal_search.py`: fixed-depth topology enumeration, parallel coarse screening, and coarse-to-fine refinement.

Both structured-search paths use the same qutrit gates, robust family objective, exact gradients, and L-BFGS-B implementation as the RL environment. Held-out ξ values are used only for validation after a train-side candidate crosses the final threshold.

## 3. Beam-search failure gate

Width-4 beam:

- 68 node evaluations;
- 0 validated solutions;
- canonical exact prefix pruned at depth 2.

This is expected from S4's non-monotone prefix-cost diagnosis and is now explicitly regression-documented rather than treated as an implementation failure.

## 4. Depth-five terminal search

All **1024** depth-five topologies were coarse-screened with one L-BFGS-B iteration. The original exact sequence ranks second. A previously unknown symmetric all-`CX` sequence ranks first. Refining only these two candidates with max 10 iterations gives for each:

- robust objective: `0.0`;
- held-out worst infidelity: `3.3306690738754696e-16`;
- validated success: PASS.

The second exact circuit is now included in `oracle.py` and has an independent 300-random-ξ plus special-point regression test.

## 5. Shorter-depth evidence

Complete discrete enumeration at depths 1–4 with max 10 optimizer iterations finds best robust objectives `0.76705`, `0.76705`, `0.62717`, and `0.57039`, respectively. No topology at depth <=4 approaches the `1e-2` final threshold.

Status: **strong numerical minimal-depth evidence, not proof**.

## 6. Matched 100-interaction pilot

Frozen comparison:

- seeds: `11,29,47`;
- episodes per seed: 20;
- maximum depth: 5;
- approximately 100 environment/inner-optimizer interactions per seed;
- inner L-BFGS-B maximum iterations per step: 4;
- train ξ points: 9;
- held-out ξ points: 73;
- PS learner: corrected 2-layer PS-LSTM + Terminal Objective Credit (TOC).

### Uniform random

- seed final-success rate: **0/3**;
- total final-success episodes: **0**;
- known exact topology hits: **0**;
- best robust objective across seeds: **0.2662787439**;
- median seed-best objective: **0.5971021313**.

### TOC PS-LSTM

- seed final-success rate: **1/3**;
- total final-success episodes: **1**;
- known exact topology hits: **1**;
- best robust objective across seeds: **4.478457439e-4**;
- median seed-best objective: **0.3076063132**.

At seed 11, the learner discovers on episode index 19 the newly identified exact discrete topology

`CX -> U3(q1) -> CX -> U3(q1) -> CX`.

With the intentionally restricted four-iteration inner optimizer it reaches held-out worst infidelity `1.273418936e-3`, below the `1e-2` final threshold.

This is the first end-to-end pilot in the project where a learning agent independently reaches a currently known exact discrete topology under the scientific environment. It is **promising evidence only**. Three seeds cannot establish superiority.

## 7. Regression suite

Final collected S4.2 suite: **83 tests**.

Verified:

- core/physics/learner/objective: 49/49 PASS;
- optimizer + legacy exhaustive: 7/7 PASS;
- new structured + terminal search: 8/8 PASS;
- environment: 13/13 PASS;
- glue/campaign/trainer/integration including final exact-topology registry test: 6/6 PASS.

Total: **83/83 PASS**.

## 8. Claims explicitly not authorized

S4.2 does not establish that:

- PS-LSTM statistically outperforms random search;
- five gates are mathematically globally minimal;
- exactly two depth-five exact topologies exist;
- the current ideal logical model captures pulse-level superconducting noise or calibration constraints.

## 9. Next milestone

S4.3 should freeze the current code before running a larger multi-seed campaign. The recommended next experiment is at least 10–20 independent seeds for random and TOC PS-LSTM, with a predeclared episode budget and no hyperparameter changes after results are inspected. Primary endpoints should be seed-level final-success rate, interactions-to-first-validated-success, held-out worst infidelity, and exact-topology discovery rate.
