# S5 notice

Research software for simulation-only parameterized two-qutrit circuit synthesis.  S5 is a **pre-training candidate gate**, not a completed full-training result.  S4.5 motivated terminal-quality-prioritized replay, but stable multi-seed convergence has not yet been established.  The frozen S5 campaign must report failed and wrong-attractor seeds as well as successes.
