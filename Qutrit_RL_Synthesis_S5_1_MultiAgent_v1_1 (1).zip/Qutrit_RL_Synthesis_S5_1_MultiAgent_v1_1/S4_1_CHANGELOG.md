# S4.1 Changelog — v0.6

- Added `FamilyObjectiveConfig` and a differentiable mean+smoothmax robust family objective.
- Preserved `mode="mean"` as backward-compatible optimizer default.
- Added exact analytic gradient for the robust objective through softmax point weights.
- Added deterministic periodic train/test grid utilities.
- Added terminal-objective credit `scale*exp(-cost/temperature)` as an auxiliary replay signal only.
- Extended corrected PS-LSTM `observe()` with an explicit auxiliary terminal reward path; true environment success semantics are unchanged.
- Added optional deferred held-out test evaluation at episode end to avoid repeated test-grid computation during every inner optimization step.
- Fixed exhaustive-search optimizer-config cloning to preserve nested family-objective configuration via `dataclasses.replace`.
- Expanded regression coverage for robust objectives, deterministic family grids, terminal credit, and deferred held-out evaluation; the current collected suite is 73/73 PASS.
- Added objective-overfit, robust-oracle, credit-pilot, and policy-shift diagnostics.
- Preserved previous S4 v0.5 reports under `evidence/s4_v0_5/`.
